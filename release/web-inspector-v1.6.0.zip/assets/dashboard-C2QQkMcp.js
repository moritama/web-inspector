import{d as Y,a as K}from"./json-Dmi7KCmo.js";function X(t,e){const n=[],r=Z(t,e),a=new Map(t.technologies.map(o=>[o.technology,o])),m=new Map(e.technologies.map(o=>[o.technology,o]));for(const[o,u]of m)a.has(o)||n.push({id:`tech:add:${o}`,category:"technology",target:o,diffType:"Added",diffCause:r?"unknown":"site-change",causeExplanation:r?"調査範囲の違い、またはサイト側の技術追加による可能性があります。":`サイト側で ${o} (${u.version?`v${u.version}`:"バージョン不明"}) が新たに導入されました。`,before:null,after:u.version?`v${u.version}`:"検出"});for(const[o,u]of a)m.has(o)||n.push({id:`tech:rem:${o}`,category:"technology",target:o,diffType:"Removed",diffCause:r?"inspection-difference":"site-change",causeExplanation:r?"調査権限または取得対象範囲の違いにより検出されなかった可能性があります。":`サイト側で ${o} の使用が停止または別技術へ移行されました。`,before:u.version?`v${u.version}`:"検出",after:null});for(const[o,u]of m){const f=a.get(o);if(f)if(f.version!==u.version)n.push({id:`tech:ver:${o}`,category:"technology",target:o,diffType:"Changed",diffCause:"site-change",causeExplanation:`サイト側でバージョンが ${f.version||"不明"} から ${u.version||"不明"} へ更新されました。`,before:f.version||"不明",after:u.version||"不明"});else{const C=f.advisories?.length??0,S=u.advisories?.length??0;if(C!==S){const W=S>C;n.push({id:`advisory:${o}`,category:"security",target:`${o} 既知脆弱性情報`,diffType:W?"Regressed":"Resolved",diffCause:"advisory-update",causeExplanation:`サイトのバージョンは不変ですが、オフライン脆弱性DBの更新により該当アドバイザリが ${C}件 から ${S}件 へ変化しました。`,before:`${C} 件`,after:`${S} 件`})}}}const d=new Map(t.securityChecks.map(o=>[o.checkId||o.name,o])),c=new Map(e.securityChecks.map(o=>[o.checkId||o.name,o]));for(const[o,u]of c){const f=d.get(o);if(!f)continue;const C=f.status==="warning"||f.status==="fail",S=u.status==="warning"||u.status==="fail";!C&&S?n.push({id:`sec:reg:${o}`,category:"security",target:u.name,diffType:"Regressed",diffCause:r?"unknown":"site-change",causeExplanation:r?"調査範囲の違い、またはサイト設定の変更により警告が検出されました。":"サイトの設定変更またはヘッダーの変更により、新たに指摘項目が発生しました。",before:f.observed,after:u.observed}):C&&!S&&n.push({id:`sec:res:${o}`,category:"security",target:u.name,diffType:"Resolved",diffCause:"site-change",causeExplanation:"セキュリティヘッダーまたは属性設定が修正され、問題が解消されました。",before:f.observed,after:u.observed})}let l=0,h=0,y=0,s=0,g=0;const $={"site-change":0,"advisory-update":0,"rule-update":0,"inspection-difference":0,unknown:0};for(const o of n)o.diffType==="Added"?l++:o.diffType==="Removed"?h++:o.diffType==="Changed"?y++:o.diffType==="Resolved"?s++:o.diffType==="Regressed"&&g++,$[o.diffCause]=($[o.diffCause]||0)+1;const E=new Set(t.technologies.map(o=>o.technology)),T=new Set(e.technologies.map(o=>o.technology)),x=Array.from(T).filter(o=>!E.has(o)),J=Array.from(E).filter(o=>!T.has(o)),M=[];for(const o of e.technologies){const u=a.get(o.technology);u&&u.version!==o.version&&M.push({technology:o.technology,before:u.version,after:o.version})}const A=new Set(t.securityChecks.filter(o=>o.status==="warning"||o.status==="fail").map(o=>o.name)),P=new Set(e.securityChecks.filter(o=>o.status==="warning"||o.status==="fail").map(o=>o.name)),G=Array.from(P).filter(o=>!A.has(o)),q=Array.from(A).filter(o=>!P.has(o));return{reportA:t,reportB:e,diffItems:n,summary:{addedCount:l,removedCount:h,changedCount:y,resolvedCount:s,regressedCount:g,causes:$},addedTechnologies:x,removedTechnologies:J,versionChanges:M,newSecurityIssues:G,resolvedSecurityIssues:q}}function Z(t,e){return t.coverage?.completeness!==e.coverage?.completeness||t.coverage?.sources?.dom!==e.coverage?.sources?.dom}function Q(t){try{const e=new URL(t),n=["token","key","auth","secret","password","passwd","sig","signature","access_token","api_key"];for(const r of Array.from(e.searchParams.keys()))n.some(a=>r.toLowerCase().includes(a))&&e.searchParams.set(r,"***MASKED***");return e.username="",e.password="",e.toString()}catch{return t}}function p(t){return t?t.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/\*/g,"\\*").replace(/_/g,"\\_").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/</g,"&lt;").replace(/>/g,"&gt;"):""}function ee(t,e,n=[]){const r=Q(t.url),a=t.hostname,m=new Date(t.inspectedAt).toLocaleString("ja-JP",{timeZone:"Asia/Tokyo"}),d=t.extensionVersion||"1.3.3",c=[];c.push(`# Web Technology & Security Inspection Report

**対象ホスト:** \`${a}\`  
**調査実施日時:** ${m} (JST)  
**Inspector バージョン:** v${d} (Manifest V3)  
**解析方式:** 受動的解析 (Passive Inspection) / 完全ローカル突合  

---`),c.push(`## 1. 調査概要

| 項目 | 内容 |
|---|---|
| 対象URL | \`${r}\` |
| ホスト名 | \`${a}\` |
| プロトコル | ${t.summary.isHttps?"HTTPS (暗号化通信)":"HTTP (非暗号化)"} |
| 診断ルールバージョン | ${p(t.rulesVersion)} |
| オフライン脆弱性DBバージョン | ${p(t.advisoryDatabaseVersion||"2026.10")} |
| 要確認項目数 | **${t.summary.requiresAttentionCount} 件** |
| 検出技術スタック数 | **${t.summary.totalTechnologies} 件** |
`);const l=t.coverage,h=l?.completeness==="complete"?"完全 (Complete)":l?.completeness==="partial"?"一部制限あり (Partial)":"未取得 (Failed)";c.push(`## 2. 調査範囲・完全性 (Coverage)

- **完全性ステータス:** **${h}** (調査スコア: ${l?.score??100} / 100)
- **DOM / HTML解析:** ${l?.sources?.dom?"✅ 取得成功":"⚠️ 未取得"}
- **HTTPレスポンスヘッダー:** ${l?.sources?.responseHeaders?"✅ 取得成功":"⚠️ 未取得 (キャッシュ/事前スキャンなし)"}
- **Cookie属性情報:** ${l?.sources?.cookies?`✅ 取得成功 (${t.cookies.length} 個観測)`:"⚠️ 権限なし/未取得"}
- **JavaScript実行時情報 (MAIN World):** ${l?.sources?.runtime?"✅ 取得成功":"⚠️ 未取得"}
${l?.unobservedSignals&&l.unobservedSignals.length>0?`
> [!NOTE]
> **未観測・制限項目:** ${l.unobservedSignals.map(s=>`\`${s}\``).join(", ")}
`:""}
`),c.push(`## 3. 調査結果サマリー

### セキュリティ指摘レベル内訳
| 重大度 | 指摘件数 | 説明 |
|:---:|:---:|---|
| **HIGH (危険)** | **${t.summary.securityFindings.high}** | 直ちに対応・修正が推奨される設定不備・脆弱性 |
| **MEDIUM (警告)** | **${t.summary.securityFindings.medium}** | セキュリティ基準に抵触、またはサポート終了の技術 |
| **LOW (注意)** | **${t.summary.securityFindings.low}** | 改善が望ましい設定上の軽微な不備 |
| **INFO (情報)** | **${t.summary.securityFindings.info}** | 参考情報・セキュリティ良好な項目 |
`),c.push(`## 4. 検出技術スタック

> [!NOTE]
> **受動的調査の原則と推定関係:** 固有シグナルから直接検出された技術と、依存関係から連動検知された技術を明確に区分しています。外部からの受動観測ではサーバー内部の実行状態を直接観測できない技術は「稼働未確認」として記録しています。

| 技術名 | カテゴリ | バージョン | 検出方式 | 連動元 / 種別 | ランタイム状態 | 確信度 | 整合性 |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
${t.technologies.length>0?t.technologies.map(s=>{const g=s.isCandidateGroup?"いずれかの可能性":s.version?`v${s.version}`:"不明",$=s.isCandidateGroup||s.detectionMethod==="associated"?"候補・関連":s.detectionMethod==="inferred"?"連動検知":"直接検出",E=s.inferredFrom?`${s.inferredFrom} (${s.implicationType||"連動"})`:"-",T=s.runtimeStatus==="confirmed"?"稼働確認済":s.runtimeStatus==="possible"?"稼働可能性あり":s.runtimeStatus==="unknown"?"稼働未確認":"-",x=s.versionIntegrity?.status==="mismatch"?"⚠️ 不一致":s.versionIntegrity?.status==="match"?"一致":"-";return`| **${p(s.technology)}** | ${p(s.category)} | \`${p(g)}\` | ${$} | ${p(E)} | ${T} | ${s.confidenceLevel} (${s.confidence}%) | ${x} |`}).join(`
`):"| なし | - | - | - | - | - | - | - |"}
`),c.push(`## 5. セキュリティ診断結果

| 診断項目 | ステータス | 重大度 | 観測値 | 許容状態 |
|---|:---:|:---:|---|:---:|
${t.securityChecks.length>0?t.securityChecks.map(s=>{const g=s.status==="pass"?"PASS":s.status==="fail"?"**FAIL**":"**WARN**",$=s.exceptionStatus==="accepted"?"🛡️ 許容済":s.exceptionStatus==="false-positive"?"❌ 誤検知除外":"-";return`| ${p(s.name)} | ${g} | ${s.severity.toUpperCase()} | \`${p(s.observed.substring(0,60))}\` | ${$} |`}).join(`
`):"| なし | - | - | - | - |"}
`),c.push(`## 6. EOL・既知脆弱性情報 (ライブラリセキュリティ)

> [!IMPORTANT]
> オフライン脆弱性DBスナップショット (Rev.2.1) とのローカル突合結果です。未登録の技術は「安全」を意味するものではありません。

| 対象技術 | バージョン | サポート状況 (EOL) | 照合ステータス | 該当CVE | 推奨対応 |
|---|:---:|:---:|:---:|---|---|
${t.technologies.map(s=>{const g=s.supportStatus==="EOL"?`**EOL (${s.eolDate||"終了"})**`:s.supportStatus||"Unknown",$=s.offlineMatchStatus||"Not Covered",E=s.advisories&&s.advisories.length>0?s.advisories.map(x=>`[${x.id}](https://nvd.nist.gov/vuln/detail/${x.id}) (${x.severity})`).join(", "):"該当なし",T=s.advisories&&s.advisories.length>0?`修正版 (v${s.advisories[0].fixedVersion||"最新"}) への更新`:s.supportStatus==="EOL"?"最新LTS系列への移行":"現状維持";return`| **${p(s.technology)}** | \`${p(s.version||"不明")}\` | ${g} | \`${$}\` | ${E} | ${T} |`}).join(`
`)}
`),c.push(`## 7. Cookie属性診断

※ **セキュリティ保護:** Cookieの値（Value）および認証シークレットは一切収集・出力していません。

| Cookie名 | ドメイン | パス | 用途分類 | Secure | HttpOnly | SameSite | CHIPS (Partitioned) |
|---|---|---|:---:|:---:|:---:|:---:|:---:|
${t.cookies.length>0?t.cookies.map(s=>`| \`${p(s.name)}\` | \`${p(s.domain)}\` | \`${p(s.path)}\` | ${p(s.purposeCategory||"general")} | ${s.secure?"Yes":"**No**"} | ${s.httpOnly?"Yes":"**No**"} | \`${s.sameSite}\` | ${s.partitioned?"Yes":"No"} |`).join(`
`):"| なし | - | - | - | - | - | - | - |"}
`),c.push(`## 8. CSP（Content Security Policy）診断

- **CSPポリシー保持件数:** ${t.cspPolicies?.length??0} 件
${t.cspPolicies&&t.cspPolicies.length>0?t.cspPolicies.map((s,g)=>`
#### ポリシー #${g+1} [取得元: ${s.source}, モード: ${s.disposition}]
\`\`\`text
${s.rawPolicy}
\`\`\`
`).join(`
`):"> CSPヘッダーまたはmetaタグによるCSPは設定されていません。"}
`);const y=t.externalConnections;return c.push(`## 9. 外部通信先・サードパーティ分析 (Public Suffix List / eTLD+1)

- **総通信先ホスト数:** ${y?.totalConnections??0} 件
- **First-Party (同一組織・自社ドメイン):** ${y?.firstPartyCount??0} 件
- **Third-Party (外部サービス通信先):** ${y?.thirdPartyCount??0} 件

| 接続先ホスト名 | 登録可能ドメイン (eTLD+1) | 所属種別 | 推定カテゴリ | 観測リソース数 |
|---|---|:---:|:---:|:---:|
${y&&y.connections.length>0?y.connections.map(s=>{const g=s.partyType==="first-party"?"First-Party":s.partyType==="third-party"?"**Third-Party**":"Local";return`| \`${p(s.hostname)}\` | \`${p(s.registrableDomain)}\` | ${g} | \`${s.category}\` | ${s.resourceCount} |`}).join(`
`):"| 外部通信先は観測されませんでした | - | - | - | - |"}
`),c.push(`## 10. 前回調査との差分 (Diff)

> 前回調査レポートとの比較は実行されていません（初回調査または単一レポート出力）。
`),c.push(`## 11. 差分発生原因の推定分析

> 分析対象の有意な差分変化はありません。
`),c.push(`## 12. 診断項目の許容・除外設定 (Finding Exceptions)

${n.length>0?`
| 状態 | 対象安定ID (FindingId) | 適用スコープ | 許容理由 | 登録日 |
|:---:|---|---|---|:---:|
${n.map(s=>`| **${s.status==="accepted"?"リスク許容":s.status==="false-positive"?"誤検知":"通知抑制"}** | \`${p(s.findingId)}\` | \`${p(s.targetUrl||"全体適用")}\` | ${p(s.reason)} | ${s.createdAt?s.createdAt.slice(0,10):"-"} |`).join(`
`)}
`:"> 現在適用されている許容・除外設定はありません。"}
`),c.push("## 13. 推奨対応ロードマップ\n\n1. **至急対応 (High Severity):**\n   - 既知脆弱性（CVE）が特定されたライブラリを修正済みバージョン以降へ更新する。\n   - 暗号化通信（HTTPS）および混在コンテンツ（Mixed Content）の解消。\n2. **計画的対応 (Medium Severity):**\n   - サポート終了（EOL）を迎えたミドルウェア・ライブラリの次世代LTS系列への移行計画策定。\n   - セッションCookieに対する `Secure`、`HttpOnly`、適切な `SameSite` 属性の付与。\n   - Content-Security-Policy (CSP) の導入および `unsafe-inline` の排除。\n3. **継続的改善 (Low / Best Practices):**\n   - HSTS (`Strict-Transport-Security`) ヘッダーの `max-age=31536000; includeSubDomains` 適用。\n   - 外部サードパーティスクリプトの棚卸しと整合性検証 (SRI) の導入。\n"),c.push(`## 14. 検出根拠 (エビデンス詳細)

${t.technologies.map(s=>`
### ${s.technology} (確信度: ${s.confidenceLevel} - ${s.confidence}%)
${s.evidence.map(g=>`- **[${g.type}]** \`${p(g.name)}\`: \`${p(g.value)}\` ${g.detail?`(${p(g.detail)})`:""}`).join(`
`)}
`).join(`
`)}
`),c.push(`## 15. 調査上の制限事項・免責事項

1. **受動的解析のスコープ:**
   本拡張機能は、ブラウザが通常のWeb閲覧時に受信したHTML、CSS、JavaScript、HTTPヘッダー、Cookie属性のみを受動的に解析（Passive Inspection）しています。外部サーバーへの攻撃的なリクエスト送信や内部ソースコードの監査は行っていません。
2. **脆弱性DBの網羅性:**
   オフライン脆弱性DBに未収録のライブラリや独自フレームワークについて「脆弱性なし」と判定されていても、安全性を完全に保証するものではありません。
3. **認証後ページの扱い:**
   ログインや特定セッションを必要とする深層ページは、閲覧した範囲に限定して診断されます。
4. **機密情報の非保持:**
   Cookieの値、認証トークン、Authorizationヘッダーなどのシークレット情報はメモリ保持およびレポート出力から完全に除外されています。
`),c.join(`

`)}function te(t,e,n=[]){const r=ee(t,e,n),a=new Blob([r],{type:"text/markdown;charset=utf-8"}),m=URL.createObjectURL(a),d=t.hostname.replace(/[^a-zA-Z0-9.-]/g,"_"),c=new Date(t.inspectedAt).toISOString().slice(0,10),l=`web-inspector-report-${d}-${c}.md`;if(typeof chrome<"u"&&chrome.downloads)chrome.downloads.download({url:m,filename:l,saveAs:!0});else{const h=document.createElement("a");h.href=m,h.download=l,document.body.appendChild(h),h.click(),document.body.removeChild(h),URL.revokeObjectURL(m)}}let v=null,b=[];const ne=document.getElementById("currentHostname"),se=document.getElementById("inspectedAtTime"),H=document.getElementById("dashAdvisoryDbDate"),oe=document.getElementById("dashTotalTechs"),ae=document.getElementById("dashAttentionCount"),ie=document.getElementById("dashEolCount"),re=document.getElementById("dashVulnCount"),de=document.getElementById("dashHttpsStatus"),ce=document.getElementById("dashMixedStatus"),D=document.getElementById("overviewLibrarySecList"),R=document.getElementById("overviewSecurityList"),j=document.getElementById("librarySecurityTableContainer"),O=document.getElementById("fullTechsContainer"),le=document.getElementById("fullSecurityContainer"),V=document.getElementById("cookiesTableBody"),z=document.getElementById("historyListContainer"),L=document.getElementById("exceptionsTableContainer"),I=document.getElementById("compareSelectA"),B=document.getElementById("compareSelectB"),ue=document.getElementById("executeCompareBtn"),pe=document.getElementById("compareResultContainer"),k=document.getElementById("domainsContainer"),ge=document.getElementById("themeToggleBtn"),F=document.getElementById("exportMdBtn"),me=document.getElementById("exportJsonBtn"),ve=document.getElementById("exportCsvBtn"),fe=document.getElementById("refreshBtn"),he=document.getElementById("clearHistoryBtn");document.addEventListener("DOMContentLoaded",async()=>{$e(),ye(),xe(),Ce(),await w()});function ye(){const t=document.getElementById("dashboardVersion");if(t){const e=chrome.runtime?.getManifest?.()?.version||"1.6.0";t.textContent=`v${e}`}}function $e(){const t=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=t==="light"?"theme-light":"theme-dark"}function be(){const t=document.body.classList.contains("theme-dark"),e=t?"theme-light":"theme-dark";document.body.className=e,localStorage.setItem("web_inspector_theme",t?"light":"dark")}function xe(){document.querySelectorAll(".nav-item").forEach(t=>{t.addEventListener("click",()=>{document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active")),document.querySelectorAll(".view-panel").forEach(n=>n.classList.remove("active")),t.classList.add("active");const e=t.getAttribute("data-view");e&&(document.getElementById(e)?.classList.add("active"),e==="exceptionsView"?N():e==="domainsView"&&_(v?.externalConnections))})})}function Ce(){ge.addEventListener("click",be),fe.addEventListener("click",w),F&&F.addEventListener("click",()=>{v&&te(v)}),me.addEventListener("click",()=>{v&&Y(v)}),ve.addEventListener("click",()=>{v&&K(v)}),he.addEventListener("click",async()=>{confirm("すべての調査履歴を完全に削除しますか？")&&(await chrome.runtime.sendMessage({type:"CLEAR_HISTORY"}),await w())}),ue.addEventListener("click",Me)}async function w(){try{const t=await chrome.runtime.sendMessage({type:"GET_ALL_REPORTS"});if(t&&t.success&&t.reports.length>0)b=t.reports,v=b[0];else{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});e&&e.success&&(v=e.report,b=[v])}v&&(U(v),Be(b),Ie(b))}catch(t){console.error("Failed to load dashboard data:",t)}}function U(t){ne.textContent=t.hostname,se.textContent=`調査日時: ${new Date(t.inspectedAt).toLocaleString("ja-JP")}`,H&&(H.textContent=`🛡️ 脆弱性DB: ${t.advisoryDatabaseVersion||"2026-10-23"}`),oe.textContent=String(t.technologies.length),ae.textContent=String(t.summary.requiresAttentionCount);const e=t.summary.librarySecurity?.eolCount??0,n=t.summary.librarySecurity?.vulnerableLibraryCount??0;ie.textContent=String(e),re.textContent=`既知脆弱性: ${n}件 / 不一致: ${t.summary.librarySecurity?.mismatchCount??0}件`,de.textContent=t.summary.isHttps?"HTTPS (暗号化)":"HTTP (非暗号化)",ce.textContent=`混在コンテンツ: ${t.summary.mixedContentCount}件`,Se(t.technologies),Ee(t.securityChecks),Te(t.technologies),we(t.technologies),Le(t.securityChecks),ke(t.cookies),_(t.externalConnections)}function Se(t){const e=t.filter(n=>n.supportStatus==="EOL"||n.advisories&&n.advisories.length>0||n.versionIntegrity?.status==="mismatch");if(e.length===0){D.innerHTML='<div style="color:var(--success-color);padding:12px 0;">ライブラリのサポート終了や既知脆弱性は検出されませんでした。</div>';return}D.innerHTML=e.map(n=>{let r=[];return n.supportStatus==="EOL"&&r.push(`EOL (${n.eolDate||"サポート終了"})`),n.advisories&&n.advisories.length>0&&r.push(`CVE ${n.advisories.length}件`),n.versionIntegrity?.status==="mismatch"&&r.push("CSS/JS不一致"),`
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border-color);">
          <div>
            <strong>${i(n.technology)}</strong>
            <span style="color:var(--text-muted);font-size:12px;margin-left:6px;">${n.version?`v${i(n.version)}`:""}</span>
            <div style="font-size:11px;color:var(--text-sub);">${i(r.join(" / "))}</div>
          </div>
          <span class="badge ${n.supportStatus==="EOL"?"badge-eol":"badge-cve"}">要確認</span>
        </div>
      `}).join("")}function Ee(t){const e=t.filter(n=>n.status==="warning"||n.status==="fail");if(e.length===0){R.innerHTML='<div style="color:var(--success-color);padding:12px 0;">重大なセキュリティ設定不備は検出されませんでした。</div>';return}R.innerHTML=e.slice(0,5).map(n=>`
    <div style="padding:8px 0;border-bottom:1px solid var(--border-color);">
      <div style="display:flex;justify-content:space-between;">
        <strong>${i(n.name)}</strong>
        <span class="badge ${n.severity==="high"?"sev-high":"sev-medium"}">${n.severity.toUpperCase()}</span>
      </div>
      <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">${i(n.description)}</div>
    </div>
  `).join("")}function Te(t){if(t.length===0){j.innerHTML='<div class="empty-state">技術情報がありません</div>';return}const e=t.map(n=>{const r=n.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':n.supportStatus==="Maintenance"?'<span class="badge badge-medium">保守</span>':n.supportStatus==="Supported"?'<span class="badge badge-high">Supported</span>':'<span class="badge" style="background:var(--bg-hover);">Unknown</span>';let a='<span class="badge sev-pass">該当なし</span>';n.offlineMatchStatus==="Matched"||n.advisories&&n.advisories.length>0?a=`<span class="badge badge-cve">該当 ${n.advisories?.length??0}件 (CVSS ${n.maxCvss||"6.1"})</span>`:n.offlineMatchStatus==="Not Covered"?a='<span style="color:var(--text-muted);font-size:11px;">未登録</span>':n.offlineMatchStatus==="Unknown Version"&&(a='<span class="badge badge-medium">要確認</span>'),n.isStale&&(a+=' <span style="font-size:10px;color:var(--warning-color);">[DB古]</span>');const m=n.versionIntegrity?n.versionIntegrity.status==="match"?'<span class="badge badge-high">一致</span>':n.versionIntegrity.status==="mismatch"?'<span class="badge badge-medium">不一致</span>':'<span style="color:var(--text-muted);font-size:11px;">判定不能</span>':'<span style="color:var(--text-muted);font-size:11px;">-</span>';let d="現状維持";n.isCandidateGroup?d="稼働しているバックエンド環境の特定を推奨":n.advisories&&n.advisories.length>0?d=`脆弱性修正版（v${n.advisories[0].fixedVersion||"最新"}以上）への更新推奨`:n.supportStatus==="EOL"?d="EOLのため最新LTS系列への移行推奨":n.offlineMatchStatus==="Unknown Version"&&n.version&&(d="パッケージ固有版のため個別セキュリティ情報の確認を推奨");const c=n.isCandidateGroup?'<span class="badge" style="background:var(--bg-hover);font-size:11px;">いずれかの可能性</span>':n.version?`v${i(n.version)}`:'<span style="color:var(--text-muted);">不明</span>';return`
        <tr>
          <td><strong>${i(n.technology)}</strong></td>
          <td>${c}</td>
          <td>${i(n.isCandidateGroup?"推定候補":n.versionSource||"-")}</td>
          <td>${m}</td>
          <td>${r} ${n.eolDate?`<span style="font-size:11px;color:var(--text-muted);">(${n.eolDate})</span>`:""}</td>
          <td>${a}</td>
          <td style="font-size:12px;color:var(--accent-color);">${i(d)}</td>
        </tr>
      `}).join("");j.innerHTML=`
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>技術・ライブラリ名</th>
            <th>代表バージョン</th>
            <th>取得元</th>
            <th>CSS/JS整合性</th>
            <th>サポート状態 (EOL)</th>
            <th>既知脆弱性 (CVE)</th>
            <th>推奨対応</th>
          </tr>
        </thead>
        <tbody>
          ${e}
        </tbody>
      </table>
    </div>
  `}function we(t){if(t.length===0){O.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}O.innerHTML=t.map(e=>{let n="";e.isCandidateGroup||e.detectionMethod==="associated"?n='<span class="badge badge-associated">候補</span>':e.detectionMethod==="inferred"?n=`<span class="badge badge-inferred">連動${e.inferredFrom?` · ${i(e.inferredFrom)}`:""}</span>`:n='<span class="badge badge-direct">直接</span>';let r="";return e.runtimeStatus==="unknown"?r='<span class="badge badge-runtime-unknown">稼働未確認</span>':e.runtimeStatus==="possible"&&(r='<span class="badge badge-runtime-possible">稼働可能性</span>'),`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:15px;">${i(e.technology)}</span>
          ${n}
          ${r}
          ${e.isCandidateGroup?'<span class="badge" style="background:var(--bg-hover);font-size:11px;">いずれかの可能性</span>':e.version?`<span class="badge" style="background:var(--bg-hover);">v${i(e.version)}</span>`:'<span style="font-size:11px;color:var(--text-muted);">バージョン不明</span>'}
          <span style="font-size:12px;color:var(--text-muted);">${i(e.isCandidateGroup?"言語・FW候補":Ae(e.category))}</span>
        </div>
        <div style="display:flex;gap:6px;">
          ${e.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':""}
          ${e.advisories&&e.advisories.length>0?`<span class="badge badge-cve">CVE ${e.advisories.length}件</span>`:""}
          <span class="badge ${e.confidenceLevel==="high"?"badge-high":"badge-medium"}">確信度 ${e.confidence}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div style="margin-bottom:8px;padding:8px 12px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
          <div style="font-size:12px;margin-bottom:4px;">
            <strong>検出方式:</strong> ${Pe(e.detectionMethod,e.isCandidateGroup)}
            ${e.inferredFrom?` / <strong>推論元:</strong> ${i(e.inferredFrom)} (${He(e.implicationType)})`:""}
          </div>
          ${e.inferencePath&&e.inferencePath.length>1?`<div style="font-size:12px;margin-bottom:4px;"><strong>推論経路:</strong> <code>${i(e.inferencePath.join(" → "))}</code></div>`:""}
          <div style="font-size:12px;">
            <strong>ランタイム状態:</strong> ${De(e.runtimeStatus)}
            ${e.runtimeStatus==="unknown"?'<span style="font-size:11px;color:var(--text-muted);margin-left:6px;">(※サーバー内部の稼働状態を観測できないため断定を保留)</span>':""}
          </div>
        </div>
        ${e.isCandidateGroup&&e.candidateTechnologies?`
          <div style="margin-bottom:8px;padding:8px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
            <strong>推定候補フレームワーク:</strong>
            <div style="display:flex;gap:6px;margin-top:4px;flex-wrap:wrap;">
              ${e.candidateTechnologies.map(a=>`<span class="badge" style="background:var(--bg-hover);">${i(a)}</span>`).join("")}
            </div>
          </div>
        `:""}
        <div>${i(e.description||"")}</div>
        ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" style="color:var(--accent-color);">${e.website}</a></div>`:""}
        
        ${e.versionIntegrity?`
          <div style="margin-top:8px;padding:8px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
            <strong>CSS / JS バージョン整合性:</strong>
            <div>JavaScript: ${i(e.versionIntegrity.jsVersion||"未検出")} / CSS: ${i(e.versionIntegrity.cssVersion||"未検出")}</div>
            <div style="color:${e.versionIntegrity.status==="match"?"var(--success-color)":"var(--warning-color)"};">${i(e.versionIntegrity.detail)}</div>
          </div>
        `:""}

        ${e.advisories&&e.advisories.length>0?`
          <div style="margin-top:8px;">
            <strong style="color:var(--danger-color);">該当する既知脆弱性 (CVE / GHSA):</strong>
            <ul style="padding-left:18px;margin-top:4px;">
              ${e.advisories.map(a=>`
                <li style="margin-bottom:6px;">
                  <strong>${i(a.id)}</strong> (${a.title}) - 影響範囲: <code>${i(a.affectedRange)}</code>
                  ${a.fixedVersion?`<span style="color:var(--success-color);margin-left:6px;">修正版: v${i(a.fixedVersion)}</span>`:""}
                </li>
              `).join("")}
            </ul>
          </div>
        `:""}

        <div style="font-weight:700;margin-top:8px;">判定根拠 (Evidence):</div>
        <ul style="padding-left:18px;">
          ${e.evidence.map(a=>`
            <li>
              <strong>[${a.type}] ${i(a.name)}:</strong>
              <code>${i(a.value)}</code>
              ${a.detail?`<span style="color:var(--text-muted);margin-left:6px;">(${i(a.detail)})</span>`:""}
            </li>
          `).join("")}
        </ul>
      </div>
    </div>
  `}).join("")}function Le(t){le.innerHTML=t.map(e=>{const r=e.exceptionStatus==="accepted"||e.exceptionStatus==="false-positive"||e.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:6px;">許容済</span>':"";return`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:14px;">${i(e.name)}</span>
          <span style="font-size:11px;color:var(--text-muted);">${i(e.checkId)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${r}
          <span class="badge ${e.status==="pass"?"sev-pass":e.severity==="high"?"sev-high":"sev-medium"}">${e.status==="pass"?"PASS":e.severity.toUpperCase()}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div><strong>観測値:</strong> <code>${i(e.observed)}</code></div>
        <div><strong>セキュリティ上の影響:</strong> ${i(e.description)}</div>
        <div style="color:var(--accent-color);"><strong>推奨対応:</strong> ${i(e.recommendation)}</div>
        ${e.exceptionReason?`<div style="background:rgba(59,130,246,0.1);padding:6px 10px;border-radius:4px;margin-top:6px;font-size:12px;color:var(--accent-color);"><strong>許容理由:</strong> ${i(e.exceptionReason)}</div>`:""}
        ${e.referenceUrls.length>0?`
          <div><strong>参考資料:</strong>
            ${e.referenceUrls.map(a=>`<a href="${a}" target="_blank" style="color:var(--accent-color);margin-left:8px;">${a}</a>`).join(", ")}
          </div>
        `:""}
      </div>
    </div>
  `}).join("")}function ke(t){if(!t||t.length===0){V.innerHTML='<tr><td colspan="8" class="empty-state">Cookieは検出されませんでした</td></tr>';return}V.innerHTML=t.map(e=>`
    <tr>
      <td><strong>${i(e.name)}</strong></td>
      <td>${i(e.domain)}</td>
      <td>${i(e.path)}</td>
      <td>${e.secure?"✅":"❌"}</td>
      <td>${e.httpOnly?"✅":"❌"}</td>
      <td>${i(e.sameSite)}</td>
      <td>${e.session?"セッション":"永続"}</td>
      <td style="color:${e.issues.length>0?"var(--warning-color)":"var(--text-muted)"};">${e.issues.length>0?i(e.issues.join(", ")):"なし"}</td>
    </tr>
  `).join("")}function Ie(t){if(t.length===0){z.innerHTML='<div class="empty-state">保存された履歴はありません</div>';return}z.innerHTML=t.map(e=>`
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;border:1px solid var(--border-color);border-radius:var(--radius-sm);margin-bottom:8px;background:var(--bg-surface);">
      <div>
        <strong>${i(e.hostname)}</strong>
        <span style="font-size:12px;color:var(--text-muted);margin-left:8px;">${new Date(e.inspectedAt).toLocaleString("ja-JP")}</span>
        <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">
          技術: ${e.technologies.length}件 / 要確認: ${e.summary.requiresAttentionCount}件 / EOL: ${e.summary.librarySecurity?.eolCount??0}件 / ${e.summary.isHttps?"HTTPS":"HTTP"}
        </div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-secondary btn-sm" onclick="window.viewReport('${e.id}')">表示</button>
        <button class="btn btn-danger btn-sm" onclick="window.deleteReport('${e.id}')">削除</button>
      </div>
    </div>
  `).join("")}window.viewReport=t=>{const e=b.find(n=>n.id===t);e&&(v=e,U(e),document.querySelector('.nav-item[data-view="overviewView"]')?.dispatchEvent(new Event("click")))};window.deleteReport=async t=>{confirm("この調査レポートを削除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_HISTORY_ITEM",id:t}),await w())};function Be(t){I.innerHTML="",B.innerHTML="",t.forEach((e,n)=>{const r=document.createElement("option");r.value=e.id,r.textContent=`${e.hostname} (${new Date(e.inspectedAt).toLocaleString("ja-JP")})`,I.appendChild(r);const a=document.createElement("option");a.value=e.id,a.textContent=`${e.hostname} (${new Date(e.inspectedAt).toLocaleString("ja-JP")})`,(n===1||n===0&&t.length===1)&&(a.selected=!0),B.appendChild(a)})}function Me(){const t=I.value,e=B.value,n=b.find(d=>d.id===t),r=b.find(d=>d.id===e);if(!n||!r)return;const a=X(n,r),m=Object.entries(a.summary.causes).filter(([d,c])=>c>0).map(([d,c])=>{let l=d;return d==="site-change"?l="Site Change (サイト側変更)":d==="advisory-update"?l="Advisory Update (脆弱性DB更新)":d==="inspection-difference"?l="Inspection Diff (調査権限差)":d==="rule-update"?l="Rule Update (診断ルール更新)":d==="unknown"&&(l="Unknown (複数/不明)"),`<span class="badge badge-medium" style="margin-right:6px;display:inline-block;margin-top:4px;">${i(l)}: ${c}件</span>`}).join("");pe.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">差分分析サマリー (Rev.2.1 IMP-09)</div>
      <div style="margin-bottom:8px;">
        検出された変化: <strong>${a.diffItems.length} 件</strong>
        (新規: ${a.summary.addedCount}, 消失: ${a.summary.removedCount}, 変更: ${a.summary.changedCount}, 解消: ${a.summary.resolvedCount}, 新規警告: ${a.summary.regressedCount})
      </div>
      <div>推定要因: ${m||'<span style="color:var(--text-muted);">差分なし</span>'}</div>
    </div>

    <div class="diff-box">
      <div class="diff-title">詳細な変化と原因分析</div>
      ${a.diffItems.length===0?'<div style="color:var(--text-muted);padding:8px 0;">2つの調査結果に変化はありませんでした。</div>':`
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>種別</th>
                <th>対象</th>
                <th>推定原因</th>
                <th>Before &rarr; After</th>
                <th>解説</th>
              </tr>
            </thead>
            <tbody>
              ${a.diffItems.map(d=>{let c="badge-medium";return(d.diffType==="Resolved"||d.diffType==="Added")&&(c="badge-high"),d.diffType==="Regressed"&&(c="badge-eol"),`
                    <tr>
                      <td><span class="badge ${c}">${d.diffType}</span></td>
                      <td><strong>${i(d.target)}</strong></td>
                      <td><span class="badge" style="background:var(--bg-hover);">${i(d.diffCause)}</span></td>
                      <td>${i(d.before||"-")} &rarr; <strong>${i(d.after||"-")}</strong></td>
                      <td style="font-size:12px;color:var(--text-sub);">${i(d.causeExplanation)}</td>
                    </tr>
                  `}).join("")}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `}async function N(){if(L)try{const e=(await chrome.runtime.sendMessage({type:"GET_FINDING_EXCEPTIONS"}))?.exceptions||[];if(e.length===0){L.innerHTML='<div class="empty-state">登録されている許容・除外設定はありません。</div>';return}L.innerHTML=`
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>状態</th>
              <th>対象安定ID (FindingId)</th>
              <th>対象URL</th>
              <th>許容理由</th>
              <th>登録日</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            ${e.map(n=>`
              <tr>
                <td><span class="badge ${n.status==="accepted"?"badge-high":"badge-medium"}">${n.status==="accepted"?"リスク許容":n.status==="false-positive"?"誤検知":"通知抑制"}</span></td>
                <td><code>${i(n.findingId)}</code></td>
                <td>${i(n.targetUrl||"全体適用")}</td>
                <td>${i(n.reason)}</td>
                <td>${n.createdAt?new Date(n.createdAt).toLocaleString("ja-JP"):"-"}</td>
                <td><button class="btn btn-secondary revoke-ex-btn" data-id="${i(n.id)}" style="font-size:11px;padding:3px 8px;">解除</button></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `,document.querySelectorAll(".revoke-ex-btn").forEach(n=>{n.addEventListener("click",async r=>{const a=r.currentTarget.getAttribute("data-id");a&&confirm("この許容設定を解除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:a}),await N(),await w())})})}catch(t){L.innerHTML=`<div class="empty-state" style="color:var(--danger-color);">許容設定の取得に失敗しました: ${t}</div>`}}function _(t){if(!k)return;if(!t||!t.connections||t.connections.length===0){k.innerHTML='<div class="empty-state">外部通信先情報はまだ解析されていません。</div>';return}const e={cdn:"CDN・静的配信",analytics:"アクセス解析",advertising:"広告・マーケティング",fonts:"Webフォント",social:"SNSウィジェット",api:"外部API",other:"その他"},n=Object.entries(t.categoryBreakdown).filter(([r,a])=>a>0).map(([r,a])=>`<span class="badge badge-medium" style="margin-right:6px;display:inline-block;margin-top:4px;">${i(e[r]||r)}: ${a}件</span>`).join("");k.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">通信先ドメイン集計 (eTLD+1 / Public Suffix List 判定)</div>
      <div style="margin-bottom:8px;">
        検出ホスト数: <strong>${t.totalConnections} 件</strong>
        (自社/First-Party: <strong>${t.firstPartyCount}</strong>, 外部/Third-Party: <strong>${t.thirdPartyCount}</strong>)
      </div>
      <div>推定用途別内訳: ${n||'<span style="color:var(--text-muted);">-</span>'}</div>
    </div>

    <div class="diff-box">
      <div class="diff-title">通信先ホスト一覧</div>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>ホスト名</th>
              <th>eTLD+1 (組織ドメイン)</th>
              <th>分類</th>
              <th>用途カテゴリ</th>
              <th>リソース数</th>
              <th>サンプルURL</th>
            </tr>
          </thead>
          <tbody>
            ${t.connections.map(r=>{let a="badge-medium",m="Third-Party";r.partyType==="first-party"?(a="badge-high",m="First-Party (自社)"):r.partyType==="local"?(a="badge-low",m="Local (内部)"):(a="badge-medium",m="Third-Party (外部)");const d=r.sampleUrls.length>0?r.sampleUrls[0]:"";return`
                  <tr>
                    <td><strong>${i(r.hostname)}</strong></td>
                    <td><code>${i(r.registrableDomain||"-")}</code></td>
                    <td><span class="badge ${a}">${m}</span></td>
                    <td><span class="badge" style="background:var(--bg-hover);">${i(e[r.category]||r.category)}</span></td>
                    <td>${r.resourceCount}</td>
                    <td style="font-size:11px;color:var(--text-sub);max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${i(d)}">${i(d||"-")}</td>
                  </tr>
                `}).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `}function Ae(t){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF","hosting-cloud":"ホスティング / クラウド基盤","analytics-tracking":"アクセス解析 / タグ管理","security-service":"セキュリティ / 監視サービス"}[t]||t}function Pe(t,e){return e||t==="associated"?"実行環境候補・関連技術":t==="inferred"?"連動検知 (推論)":"直接検出"}function He(t){switch(t){case"framework-dependency":return"フレームワーク基盤依存";case"possible-runtime":return"実行環境の候補（静的配信等の代替構成あり）";case"runtime-dependency":return"実行時依存";case"technology-association":return"関連技術";default:return t||"連動"}}function De(t){switch(t){case"confirmed":return"稼働確認済";case"possible":return"稼働可能性あり";case"unknown":return"稼働状態未確認";case"not-applicable":return"該当なし (クライアント技術)";default:return"未確認"}}function i(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
