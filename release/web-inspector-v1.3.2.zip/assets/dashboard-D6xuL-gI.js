import{d as N,a as q}from"./json-B9bJ9Pcs.js";function F(n,e){const t=[],r=G(n,e),o=new Map(n.technologies.map(s=>[s.technology,s])),v=new Map(e.technologies.map(s=>[s.technology,s]));for(const[s,d]of v)o.has(s)||t.push({id:`tech:add:${s}`,category:"technology",target:s,diffType:"Added",diffCause:r?"unknown":"site-change",causeExplanation:r?"調査範囲の違い、またはサイト側の技術追加による可能性があります。":`サイト側で ${s} (${d.version?`v${d.version}`:"バージョン不明"}) が新たに導入されました。`,before:null,after:d.version?`v${d.version}`:"検出"});for(const[s,d]of o)v.has(s)||t.push({id:`tech:rem:${s}`,category:"technology",target:s,diffType:"Removed",diffCause:r?"inspection-difference":"site-change",causeExplanation:r?"調査権限または取得対象範囲の違いにより検出されなかった可能性があります。":`サイト側で ${s} の使用が停止または別技術へ移行されました。`,before:d.version?`v${d.version}`:"検出",after:null});for(const[s,d]of v){const c=o.get(s);if(c)if(c.version!==d.version)t.push({id:`tech:ver:${s}`,category:"technology",target:s,diffType:"Changed",diffCause:"site-change",causeExplanation:`サイト側でバージョンが ${c.version||"不明"} から ${d.version||"不明"} へ更新されました。`,before:c.version||"不明",after:d.version||"不明"});else{const m=c.advisories?.length??0,f=d.advisories?.length??0;if(m!==f){const J=f>m;t.push({id:`advisory:${s}`,category:"security",target:`${s} 既知脆弱性情報`,diffType:J?"Regressed":"Resolved",diffCause:"advisory-update",causeExplanation:`サイトのバージョンは不変ですが、オフライン脆弱性DBの更新により該当アドバイザリが ${m}件 から ${f}件 へ変化しました。`,before:`${m} 件`,after:`${f} 件`})}}}const i=new Map(n.securityChecks.map(s=>[s.checkId||s.name,s])),u=new Map(e.securityChecks.map(s=>[s.checkId||s.name,s]));for(const[s,d]of u){const c=i.get(s);if(!c)continue;const m=c.status==="warning"||c.status==="fail",f=d.status==="warning"||d.status==="fail";!m&&f?t.push({id:`sec:reg:${s}`,category:"security",target:d.name,diffType:"Regressed",diffCause:r?"unknown":"site-change",causeExplanation:r?"調査範囲の違い、またはサイト設定の変更により警告が検出されました。":"サイトの設定変更またはヘッダーの変更により、新たに指摘項目が発生しました。",before:c.observed,after:d.observed}):m&&!f&&t.push({id:`sec:res:${s}`,category:"security",target:d.name,diffType:"Resolved",diffCause:"site-change",causeExplanation:"セキュリティヘッダーまたは属性設定が修正され、問題が解消されました。",before:c.observed,after:d.observed})}let p=0,E=0,C=0,S=0,w=0;const b={"site-change":0,"advisory-update":0,"rule-update":0,"inspection-difference":0,unknown:0};for(const s of t)s.diffType==="Added"?p++:s.diffType==="Removed"?E++:s.diffType==="Changed"?C++:s.diffType==="Resolved"?S++:s.diffType==="Regressed"&&w++,b[s.diffCause]=(b[s.diffCause]||0)+1;const T=new Set(n.technologies.map(s=>s.technology)),L=new Set(e.technologies.map(s=>s.technology)),V=Array.from(L).filter(s=>!T.has(s)),_=Array.from(T).filter(s=>!L.has(s)),I=[];for(const s of e.technologies){const d=o.get(s.technology);d&&d.version!==s.version&&I.push({technology:s.technology,before:d.version,after:s.version})}const B=new Set(n.securityChecks.filter(s=>s.status==="warning"||s.status==="fail").map(s=>s.name)),k=new Set(e.securityChecks.filter(s=>s.status==="warning"||s.status==="fail").map(s=>s.name)),P=Array.from(k).filter(s=>!B.has(s)),U=Array.from(B).filter(s=>!k.has(s));return{reportA:n,reportB:e,diffItems:t,summary:{addedCount:p,removedCount:E,changedCount:C,resolvedCount:S,regressedCount:w,causes:b},addedTechnologies:V,removedTechnologies:_,versionChanges:I,newSecurityIssues:P,resolvedSecurityIssues:U}}function G(n,e){return n.coverage?.completeness!==e.coverage?.completeness||n.coverage?.sources?.dom!==e.coverage?.sources?.dom}let l=null,g=[];const X=document.getElementById("currentHostname"),Y=document.getElementById("inspectedAtTime"),K=document.getElementById("dashTotalTechs"),Q=document.getElementById("dashAttentionCount"),W=document.getElementById("dashEolCount"),Z=document.getElementById("dashVulnCount"),ee=document.getElementById("dashHttpsStatus"),te=document.getElementById("dashMixedStatus"),M=document.getElementById("overviewLibrarySecList"),A=document.getElementById("overviewSecurityList"),H=document.getElementById("librarySecurityTableContainer"),R=document.getElementById("fullTechsContainer"),ne=document.getElementById("fullSecurityContainer"),j=document.getElementById("cookiesTableBody"),D=document.getElementById("historyListContainer"),h=document.getElementById("exceptionsTableContainer"),$=document.getElementById("compareSelectA"),x=document.getElementById("compareSelectB"),se=document.getElementById("executeCompareBtn"),ae=document.getElementById("compareResultContainer"),oe=document.getElementById("themeToggleBtn"),ie=document.getElementById("exportJsonBtn"),re=document.getElementById("exportCsvBtn"),de=document.getElementById("refreshBtn"),ce=document.getElementById("clearHistoryBtn");document.addEventListener("DOMContentLoaded",async()=>{ue(),le(),ge(),ve(),await y()});function le(){const n=document.getElementById("dashboardVersion");if(n){const e=chrome.runtime?.getManifest?.()?.version||"1.3.2";n.textContent=`v${e}`}}function ue(){const n=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=n==="light"?"theme-light":"theme-dark"}function pe(){const n=document.body.classList.contains("theme-dark"),e=n?"theme-light":"theme-dark";document.body.className=e,localStorage.setItem("web_inspector_theme",n?"light":"dark")}function ge(){document.querySelectorAll(".nav-item").forEach(n=>{n.addEventListener("click",()=>{document.querySelectorAll(".nav-item").forEach(t=>t.classList.remove("active")),document.querySelectorAll(".view-panel").forEach(t=>t.classList.remove("active")),n.classList.add("active");const e=n.getAttribute("data-view");e&&(document.getElementById(e)?.classList.add("active"),e==="exceptionsView"&&z())})})}function ve(){oe.addEventListener("click",pe),de.addEventListener("click",y),ie.addEventListener("click",()=>{l&&N(l)}),re.addEventListener("click",()=>{l&&q(l)}),ce.addEventListener("click",async()=>{confirm("すべての調査履歴を完全に削除しますか？")&&(await chrome.runtime.sendMessage({type:"CLEAR_HISTORY"}),await y())}),se.addEventListener("click",Ce)}async function y(){try{const n=await chrome.runtime.sendMessage({type:"GET_ALL_REPORTS"});if(n&&n.success&&n.reports.length>0)g=n.reports,l=g[0];else{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});e&&e.success&&(l=e.report,g=[l])}l&&(O(l),Ee(g),xe(g))}catch(n){console.error("Failed to load dashboard data:",n)}}function O(n){X.textContent=n.hostname,Y.textContent=`調査日時: ${new Date(n.inspectedAt).toLocaleString("ja-JP")}`,K.textContent=String(n.technologies.length),Q.textContent=String(n.summary.requiresAttentionCount);const e=n.summary.librarySecurity?.eolCount??0,t=n.summary.librarySecurity?.vulnerableLibraryCount??0;W.textContent=String(e),Z.textContent=`既知脆弱性: ${t}件 / 不一致: ${n.summary.librarySecurity?.mismatchCount??0}件`,ee.textContent=n.summary.isHttps?"HTTPS (暗号化)":"HTTP (非暗号化)",te.textContent=`混在コンテンツ: ${n.summary.mixedContentCount}件`,me(n.technologies),fe(n.securityChecks),ye(n.technologies),he(n.technologies),be(n.securityChecks),$e(n.cookies)}function me(n){const e=n.filter(t=>t.supportStatus==="EOL"||t.advisories&&t.advisories.length>0||t.versionIntegrity?.status==="mismatch");if(e.length===0){M.innerHTML='<div style="color:var(--success-color);padding:12px 0;">ライブラリのサポート終了や既知脆弱性は検出されませんでした。</div>';return}M.innerHTML=e.map(t=>{let r=[];return t.supportStatus==="EOL"&&r.push(`EOL (${t.eolDate||"サポート終了"})`),t.advisories&&t.advisories.length>0&&r.push(`CVE ${t.advisories.length}件`),t.versionIntegrity?.status==="mismatch"&&r.push("CSS/JS不一致"),`
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border-color);">
          <div>
            <strong>${a(t.technology)}</strong>
            <span style="color:var(--text-muted);font-size:12px;margin-left:6px;">${t.version?`v${a(t.version)}`:""}</span>
            <div style="font-size:11px;color:var(--text-sub);">${a(r.join(" / "))}</div>
          </div>
          <span class="badge ${t.supportStatus==="EOL"?"badge-eol":"badge-cve"}">要確認</span>
        </div>
      `}).join("")}function fe(n){const e=n.filter(t=>t.status==="warning"||t.status==="fail");if(e.length===0){A.innerHTML='<div style="color:var(--success-color);padding:12px 0;">重大なセキュリティ設定不備は検出されませんでした。</div>';return}A.innerHTML=e.slice(0,5).map(t=>`
    <div style="padding:8px 0;border-bottom:1px solid var(--border-color);">
      <div style="display:flex;justify-content:space-between;">
        <strong>${a(t.name)}</strong>
        <span class="badge ${t.severity==="high"?"sev-high":"sev-medium"}">${t.severity.toUpperCase()}</span>
      </div>
      <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">${a(t.description)}</div>
    </div>
  `).join("")}function ye(n){if(n.length===0){H.innerHTML='<div class="empty-state">技術情報がありません</div>';return}const e=n.map(t=>{const r=t.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':t.supportStatus==="Maintenance"?'<span class="badge badge-medium">保守</span>':t.supportStatus==="Supported"?'<span class="badge badge-high">Supported</span>':'<span class="badge" style="background:var(--bg-hover);">Unknown</span>';let o='<span class="badge sev-pass">該当なし</span>';t.offlineMatchStatus==="Matched"||t.advisories&&t.advisories.length>0?o=`<span class="badge badge-cve">該当 ${t.advisories?.length??0}件 (CVSS ${t.maxCvss||"6.1"})</span>`:t.offlineMatchStatus==="Not Covered"?o='<span style="color:var(--text-muted);font-size:11px;">未登録</span>':t.offlineMatchStatus==="Unknown Version"&&(o='<span class="badge badge-medium">要確認</span>'),t.isStale&&(o+=' <span style="font-size:10px;color:var(--warning-color);">[DB古]</span>');const v=t.versionIntegrity?t.versionIntegrity.status==="match"?'<span class="badge badge-high">一致</span>':t.versionIntegrity.status==="mismatch"?'<span class="badge badge-medium">不一致</span>':'<span style="color:var(--text-muted);font-size:11px;">判定不能</span>':'<span style="color:var(--text-muted);font-size:11px;">-</span>';let i="現状維持";return t.advisories&&t.advisories.length>0?i=`脆弱性修正版（v${t.advisories[0].fixedVersion||"最新"}以上）への更新推奨`:t.supportStatus==="EOL"?i="EOLのため最新LTS系列への移行推奨":t.offlineMatchStatus==="Unknown Version"&&t.version&&(i="パッケージ固有版のため個別セキュリティ情報の確認を推奨"),`
        <tr>
          <td><strong>${a(t.technology)}</strong></td>
          <td>${t.version?`v${a(t.version)}`:'<span style="color:var(--text-muted);">不明</span>'}</td>
          <td>${a(t.versionSource||"-")}</td>
          <td>${v}</td>
          <td>${r} ${t.eolDate?`<span style="font-size:11px;color:var(--text-muted);">(${t.eolDate})</span>`:""}</td>
          <td>${o}</td>
          <td style="font-size:12px;color:var(--accent-color);">${a(i)}</td>
        </tr>
      `}).join("");H.innerHTML=`
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>技術・ライブラリ名</th>
            <th>代表バージョン</th>
            <th>取得元</th>
            <th>CSS/JS整合性</th>
            <th>サポート状態 (EOL)</th>
            <th>既知脆弱性 (CVE)</th>
            <th>推奨対応</th>
          </tr>
        </thead>
        <tbody>
          ${e}
        </tbody>
      </table>
    </div>
  `}function he(n){if(n.length===0){R.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}R.innerHTML=n.map(e=>`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:15px;">${a(e.technology)}</span>
          ${e.version?`<span class="badge" style="background:var(--bg-hover);">v${a(e.version)}</span>`:'<span style="font-size:11px;color:var(--text-muted);">バージョン不明</span>'}
          <span style="font-size:12px;color:var(--text-muted);">${a(e.category)}</span>
        </div>
        <div style="display:flex;gap:6px;">
          ${e.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':""}
          ${e.advisories&&e.advisories.length>0?`<span class="badge badge-cve">CVE ${e.advisories.length}件</span>`:""}
          <span class="badge ${e.confidenceLevel==="high"?"badge-high":"badge-medium"}">確信度 ${e.confidence}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div>${a(e.description||"")}</div>
        ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" style="color:var(--accent-color);">${e.website}</a></div>`:""}
        
        ${e.versionIntegrity?`
          <div style="margin-top:8px;padding:8px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
            <strong>CSS / JS バージョン整合性:</strong>
            <div>JavaScript: ${a(e.versionIntegrity.jsVersion||"未検出")} / CSS: ${a(e.versionIntegrity.cssVersion||"未検出")}</div>
            <div style="color:${e.versionIntegrity.status==="match"?"var(--success-color)":"var(--warning-color)"};">${a(e.versionIntegrity.detail)}</div>
          </div>
        `:""}

        ${e.advisories&&e.advisories.length>0?`
          <div style="margin-top:8px;">
            <strong style="color:var(--danger-color);">該当する既知脆弱性 (CVE / GHSA):</strong>
            <ul style="padding-left:18px;margin-top:4px;">
              ${e.advisories.map(t=>`
                <li style="margin-bottom:6px;">
                  <strong>${a(t.id)}</strong> (${t.title}) - 影響範囲: <code>${a(t.affectedRange)}</code>
                  ${t.fixedVersion?`<span style="color:var(--success-color);margin-left:6px;">修正版: v${a(t.fixedVersion)}</span>`:""}
                </li>
              `).join("")}
            </ul>
          </div>
        `:""}

        <div style="font-weight:700;margin-top:8px;">判定根拠 (Evidence):</div>
        <ul style="padding-left:18px;">
          ${e.evidence.map(t=>`
            <li>
              <strong>[${t.type}] ${a(t.name)}:</strong>
              <code>${a(t.value)}</code>
              ${t.detail?`<span style="color:var(--text-muted);margin-left:6px;">(${a(t.detail)})</span>`:""}
            </li>
          `).join("")}
        </ul>
      </div>
    </div>
  `).join("")}function be(n){ne.innerHTML=n.map(e=>{const r=e.exceptionStatus==="accepted"||e.exceptionStatus==="false-positive"||e.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:6px;">許容済</span>':"";return`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:14px;">${a(e.name)}</span>
          <span style="font-size:11px;color:var(--text-muted);">${a(e.checkId)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${r}
          <span class="badge ${e.status==="pass"?"sev-pass":e.severity==="high"?"sev-high":"sev-medium"}">${e.status==="pass"?"PASS":e.severity.toUpperCase()}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div><strong>観測値:</strong> <code>${a(e.observed)}</code></div>
        <div><strong>セキュリティ上の影響:</strong> ${a(e.description)}</div>
        <div style="color:var(--accent-color);"><strong>推奨対応:</strong> ${a(e.recommendation)}</div>
        ${e.exceptionReason?`<div style="background:rgba(59,130,246,0.1);padding:6px 10px;border-radius:4px;margin-top:6px;font-size:12px;color:var(--accent-color);"><strong>許容理由:</strong> ${a(e.exceptionReason)}</div>`:""}
        ${e.referenceUrls.length>0?`
          <div><strong>参考資料:</strong>
            ${e.referenceUrls.map(o=>`<a href="${o}" target="_blank" style="color:var(--accent-color);margin-left:8px;">${o}</a>`).join(", ")}
          </div>
        `:""}
      </div>
    </div>
  `}).join("")}function $e(n){if(!n||n.length===0){j.innerHTML='<tr><td colspan="8" class="empty-state">Cookieは検出されませんでした</td></tr>';return}j.innerHTML=n.map(e=>`
    <tr>
      <td><strong>${a(e.name)}</strong></td>
      <td>${a(e.domain)}</td>
      <td>${a(e.path)}</td>
      <td>${e.secure?"✅":"❌"}</td>
      <td>${e.httpOnly?"✅":"❌"}</td>
      <td>${a(e.sameSite)}</td>
      <td>${e.session?"セッション":"永続"}</td>
      <td style="color:${e.issues.length>0?"var(--warning-color)":"var(--text-muted)"};">${e.issues.length>0?a(e.issues.join(", ")):"なし"}</td>
    </tr>
  `).join("")}function xe(n){if(n.length===0){D.innerHTML='<div class="empty-state">保存された履歴はありません</div>';return}D.innerHTML=n.map(e=>`
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;border:1px solid var(--border-color);border-radius:var(--radius-sm);margin-bottom:8px;background:var(--bg-surface);">
      <div>
        <strong>${a(e.hostname)}</strong>
        <span style="font-size:12px;color:var(--text-muted);margin-left:8px;">${new Date(e.inspectedAt).toLocaleString("ja-JP")}</span>
        <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">
          技術: ${e.technologies.length}件 / 要確認: ${e.summary.requiresAttentionCount}件 / EOL: ${e.summary.librarySecurity?.eolCount??0}件 / ${e.summary.isHttps?"HTTPS":"HTTP"}
        </div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-secondary btn-sm" onclick="window.viewReport('${e.id}')">表示</button>
        <button class="btn btn-danger btn-sm" onclick="window.deleteReport('${e.id}')">削除</button>
      </div>
    </div>
  `).join("")}window.viewReport=n=>{const e=g.find(t=>t.id===n);e&&(l=e,O(e),document.querySelector('.nav-item[data-view="overviewView"]')?.dispatchEvent(new Event("click")))};window.deleteReport=async n=>{confirm("この調査レポートを削除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_HISTORY_ITEM",id:n}),await y())};function Ee(n){$.innerHTML="",x.innerHTML="",n.forEach((e,t)=>{const r=document.createElement("option");r.value=e.id,r.textContent=`${e.hostname} (${new Date(e.inspectedAt).toLocaleString("ja-JP")})`,$.appendChild(r);const o=document.createElement("option");o.value=e.id,o.textContent=`${e.hostname} (${new Date(e.inspectedAt).toLocaleString("ja-JP")})`,(t===1||t===0&&n.length===1)&&(o.selected=!0),x.appendChild(o)})}function Ce(){const n=$.value,e=x.value,t=g.find(i=>i.id===n),r=g.find(i=>i.id===e);if(!t||!r)return;const o=F(t,r),v=Object.entries(o.summary.causes).filter(([i,u])=>u>0).map(([i,u])=>{let p=i;return i==="site-change"?p="Site Change (サイト側変更)":i==="advisory-update"?p="Advisory Update (脆弱性DB更新)":i==="inspection-difference"?p="Inspection Diff (調査権限差)":i==="rule-update"?p="Rule Update (診断ルール更新)":i==="unknown"&&(p="Unknown (複数/不明)"),`<span class="badge badge-medium" style="margin-right:6px;display:inline-block;margin-top:4px;">${a(p)}: ${u}件</span>`}).join("");ae.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">差分分析サマリー (Rev.2.1 IMP-09)</div>
      <div style="margin-bottom:8px;">
        検出された変化: <strong>${o.diffItems.length} 件</strong>
        (新規: ${o.summary.addedCount}, 消失: ${o.summary.removedCount}, 変更: ${o.summary.changedCount}, 解消: ${o.summary.resolvedCount}, 新規警告: ${o.summary.regressedCount})
      </div>
      <div>推定要因: ${v||'<span style="color:var(--text-muted);">差分なし</span>'}</div>
    </div>

    <div class="diff-box">
      <div class="diff-title">詳細な変化と原因分析</div>
      ${o.diffItems.length===0?'<div style="color:var(--text-muted);padding:8px 0;">2つの調査結果に変化はありませんでした。</div>':`
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>種別</th>
                <th>対象</th>
                <th>推定原因</th>
                <th>Before &rarr; After</th>
                <th>解説</th>
              </tr>
            </thead>
            <tbody>
              ${o.diffItems.map(i=>{let u="badge-medium";return(i.diffType==="Resolved"||i.diffType==="Added")&&(u="badge-high"),i.diffType==="Regressed"&&(u="badge-eol"),`
                    <tr>
                      <td><span class="badge ${u}">${i.diffType}</span></td>
                      <td><strong>${a(i.target)}</strong></td>
                      <td><span class="badge" style="background:var(--bg-hover);">${a(i.diffCause)}</span></td>
                      <td>${a(i.before||"-")} &rarr; <strong>${a(i.after||"-")}</strong></td>
                      <td style="font-size:12px;color:var(--text-sub);">${a(i.causeExplanation)}</td>
                    </tr>
                  `}).join("")}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `}async function z(){if(h)try{const e=(await chrome.runtime.sendMessage({type:"GET_FINDING_EXCEPTIONS"}))?.exceptions||[];if(e.length===0){h.innerHTML='<div class="empty-state">登録されている許容・除外設定はありません。</div>';return}h.innerHTML=`
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>状態</th>
              <th>対象安定ID (FindingId)</th>
              <th>対象URL</th>
              <th>許容理由</th>
              <th>登録日</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            ${e.map(t=>`
              <tr>
                <td><span class="badge ${t.status==="accepted"?"badge-high":"badge-medium"}">${t.status==="accepted"?"リスク許容":t.status==="false-positive"?"誤検知":"通知抑制"}</span></td>
                <td><code>${a(t.findingId)}</code></td>
                <td>${a(t.targetUrl||"全体適用")}</td>
                <td>${a(t.reason)}</td>
                <td>${t.createdAt?new Date(t.createdAt).toLocaleString("ja-JP"):"-"}</td>
                <td><button class="btn btn-secondary revoke-ex-btn" data-id="${a(t.id)}" style="font-size:11px;padding:3px 8px;">解除</button></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `,document.querySelectorAll(".revoke-ex-btn").forEach(t=>{t.addEventListener("click",async r=>{const o=r.currentTarget.getAttribute("data-id");o&&confirm("この許容設定を解除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:o}),await z(),await y())})})}catch(n){h.innerHTML=`<div class="empty-state" style="color:var(--danger-color);">許容設定の取得に失敗しました: ${n}</div>`}}function a(n){return n.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
