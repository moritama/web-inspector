import{d as L,a as x}from"./json-B9bJ9Pcs.js";let r=null;const p=document.getElementById("siteHostname"),m=document.getElementById("statusIndicator"),S=document.getElementById("techCount"),B=document.getElementById("attentionCount"),h=document.getElementById("eolCount"),I=document.getElementById("tabTechCount"),w=document.getElementById("tabSecCount"),T=document.getElementById("tabCookieCount"),v=document.getElementById("techsList"),g=document.getElementById("securityList"),u=document.getElementById("cookiesList"),M=document.getElementById("rescanBtn"),k=document.getElementById("themeToggleBtn"),H=document.getElementById("openDashboardBtn"),N=document.getElementById("fullReportBtn"),U=document.getElementById("exportJsonBtn"),D=document.getElementById("exportCsvBtn"),l=document.getElementById("detailModal"),y=document.getElementById("modalTitle"),f=document.getElementById("modalBody"),O=document.getElementById("closeModalBtn");document.addEventListener("DOMContentLoaded",()=>{_(),V(),j(),E()});function V(){const e=document.getElementById("brandVersion");if(e){const t=chrome.runtime?.getManifest?.()?.version;t&&(e.textContent=`v${t}`)}}function _(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function z(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function j(){k.addEventListener("click",z),M.addEventListener("click",()=>E()),H.addEventListener("click",C),N.addEventListener("click",C),U.addEventListener("click",()=>{r&&L(r)}),D.addEventListener("click",()=>{r&&x(r)}),document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(i=>i.classList.remove("active")),document.querySelectorAll(".tab-pane").forEach(i=>i.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-tab");t&&document.getElementById(t)?.classList.add("active")})}),O.addEventListener("click",()=>{l.classList.add("hidden")}),l.addEventListener("click",e=>{e.target===l&&l.classList.add("hidden")})}function C(){const e=chrome.runtime.getURL("dashboard.html");chrome.tabs.create({url:e})}async function E(){m.className="status-indicator",p.textContent="調査中...",v.innerHTML='<div class="empty-state">技術情報を解析中...</div>',g.innerHTML='<div class="empty-state">セキュリティ設定を診断中...</div>',u.innerHTML='<div class="empty-state">Cookie属性を取得中...</div>';try{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});if(!e||!e.success)throw new Error(e?.error||"調査に失敗しました。");r=e.report,A(r)}catch(e){const t=e instanceof Error?e.message:String(e);p.textContent="調査エラー",m.className="status-indicator",m.style.backgroundColor="#EF4444",v.innerHTML=`<div class="empty-state" style="color: #EF4444;">${t}</div>`}}function A(e){m.className="status-indicator ready",p.textContent=e.hostname,S.textContent=String(e.technologies.length),B.textContent=String(e.summary.requiresAttentionCount);const t=(e.summary.librarySecurity?.eolCount??0)+(e.summary.librarySecurity?.vulnerableLibraryCount??0);h&&(h.textContent=String(t)),I.textContent=String(e.technologies.length),w.textContent=String(e.securityChecks.length),T.textContent=String(e.cookies.length),R(e.technologies),J(e.securityChecks),q(e.cookies)}function R(e){if(e.length===0){v.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}v.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const o=t.confidenceLevel==="high"?"badge-high":t.confidenceLevel==="medium"?"badge-medium":"badge-low",a=t.confidenceLevel==="high"?"高":t.confidenceLevel==="medium"?"中":"低";let d="";t.supportStatus==="EOL"?d='<span class="badge badge-eol">EOL</span>':t.supportStatus==="Maintenance"&&(d='<span class="badge badge-medium">保守</span>');let s="";t.advisories&&t.advisories.length>0&&(s=`<span class="badge badge-cve">CVE ${t.maxCvss?`CVSS ${t.maxCvss}`:`${t.advisories.length}件`}</span>`);let c="";t.versionIntegrity?.status==="mismatch"&&(c='<span class="badge badge-mismatch">不一致</span>');let $=t.version?`v${n(t.version)}`:"バージョン不明";t.versionSource==="runtime"&&($+=" (実行時)"),i.innerHTML=`
      <div class="item-main">
        <div class="tech-icon-badge">${t.technology.slice(0,2).toUpperCase()}</div>
        <div class="item-texts">
          <span class="item-name">${n(t.technology)}</span>
          <div class="item-meta">
            <span class="item-version-badge">${n($)}</span>
            <span>${n(b(t.category))}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        ${c}
        ${d}
        ${s}
        <span class="badge ${o}">${a} · ${t.confidence}</span>
      </div>
    `,i.addEventListener("click",()=>F(t)),v.appendChild(i)})}function J(e){if(e.length===0){g.innerHTML='<div class="empty-state">診断項目がありません</div>';return}g.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";let o="sev-info",a="情報";t.status==="pass"?(o="sev-pass",a="適正"):t.severity==="high"?(o="sev-high",a="危険"):t.severity==="medium"?(o="sev-medium",a="警告"):t.severity==="low"&&(o="sev-low",a="注意"),i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <span class="item-meta">${n(t.observed.substring(0,42))}</span>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${o}">${a}</span>
      </div>
    `,i.addEventListener("click",()=>W(t)),g.appendChild(i)})}function q(e){if(e.length===0){u.innerHTML='<div class="empty-state">観測されたCookieはありません</div>';return}u.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const o=t.issues&&t.issues.length>0,a=o?"sev-medium":"sev-pass",d=o?"要確認":"安全";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <div class="item-meta">
            <span>${t.secure?"🔒 Secure":"⚠️ 不保護"}</span>
            <span>${t.httpOnly?"🛡️ HttpOnly":"スクリプト可"}</span>
            <span>SameSite: ${n(t.sameSite)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${a}">${d}</span>
      </div>
    `,i.addEventListener("click",()=>G(t)),u.appendChild(i)})}function F(e){y.textContent=`${e.technology} 検出 & セキュリティ詳細`;let t="";if(e.versionIntegrity){const s=e.versionIntegrity,c=s.status==="match"?"var(--success-color)":s.status==="mismatch"?"var(--warning-color)":"var(--text-muted)";t=`
      <div>
        <div class="detail-section-title">CSS / JavaScript バージョン整合性</div>
        <div>JavaScript: <strong>${n(s.jsVersion||"未検出")}</strong> / CSS: <strong>${n(s.cssVersion||"未検出")}</strong></div>
        <div style="color:${c};font-weight:600;margin-top:2px;">判定: ${s.status==="match"?"一致 (OK)":s.status==="mismatch"?"要確認 (バージョン不一致)":"判定不能"}</div>
        <div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>
      </div>
    `}let i="";if(e.eolInfo){const s=e.eolInfo;i=`
      <div>
        <div class="detail-section-title">サポート状況 (EOL)</div>
        <div>ステータス: <strong style="color:${s.status==="EOL"?"var(--danger-color)":s.status==="Maintenance"?"var(--warning-color)":"var(--success-color)"};">${s.status}</strong> ${s.eolDate?`(EOL日: ${s.eolDate})`:""}</div>
        <div style="font-size:11px;color:var(--accent-color);">${n(s.recommendation)}</div>
        ${s.sourceUrl?`<div>出典: <a href="${s.sourceUrl}" target="_blank" class="ref-link">${s.sourceUrl}</a></div>`:""}
      </div>
    `}let o="";const a=e.offlineMatchStatus||"Not Covered",d=e.isStale?'<span style="color:var(--warning-color);margin-left:6px;font-size:11px;">⚠️ DB鮮度: 31日以上経過</span>':"";if(e.advisories&&e.advisories.length>0)o=`
      <div>
        <div class="detail-section-title" style="color:var(--danger-color);">該当する既知脆弱性 (${e.advisories.length} 件) ${d}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">照合ステータス: <strong>${a}</strong></div>
        ${e.advisories.map(s=>`
          <div class="advisory-card">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <strong>${n(s.id)}</strong>
              ${s.cvssScore?`<span class="badge sev-high">CVSS ${s.cvssScore}</span>`:""}
            </div>
            <div style="font-weight:600;margin-top:2px;">${n(s.title)}</div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">${n(s.summary)}</div>
            <div style="font-size:11px;margin-top:4px;">
              <span>影響範囲: <code>${n(s.affectedRange)}</code></span>
              ${s.fixedVersion?`<span style="margin-left:8px;color:var(--success-color);">修正版: <strong>v${n(s.fixedVersion)}</strong></span>`:""}
            </div>
            ${s.referenceUrls.length>0?`<div style="margin-top:4px;"><a href="${s.referenceUrls[0]}" target="_blank" class="ref-link">詳細情報 (NVD / GitHub)</a></div>`:""}
          </div>
        `).join("")}
      </div>
    `;else{let s="この技術のオフライン脆弱性データは未収録です。";a==="No Match"?s="オフラインDBに収録されていますが、検出されたバージョンには該当する既知脆弱性はありません。":a==="Unknown Version"&&(s="バージョン不明、またはLinuxディストリビューション固有パッケージのため脆弱性断定を保留しています。"),o=`
      <div>
        <div class="detail-section-title">脆弱性照合状況 (オフラインDB) ${d}</div>
        <div style="font-size:12px;">ステータス: <strong>${a}</strong></div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${n(s)}</div>
      </div>
    `}f.innerHTML=`
    <div>
      <div class="detail-section-title">基本情報</div>
      <div>確信度スコア: <strong>${e.confidence}</strong> (${e.confidenceLevel.toUpperCase()})</div>
      <div>代表バージョン: <strong>${e.version||"不明"}</strong> ${e.versionSource?`[取得元: ${n(e.versionSource)}]`:""}</div>
      <div>カテゴリ: ${n(b(e.category))}</div>
      ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" class="ref-link">${e.website}</a></div>`:""}
    </div>

    ${t}
    ${i}
    ${o}

    <div>
      <div class="detail-section-title">判定根拠 (エビデンス)</div>
      ${e.evidence.map(s=>`
        <div class="evidence-item">
          <div><strong>[${s.type}]</strong> ${n(s.name)}</div>
          <div class="detail-box">${n(s.value)}</div>
          ${s.detail?`<div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>`:""}
        </div>
      `).join("")}
    </div>
  `,l.classList.remove("hidden")}function W(e){y.textContent=e.name,f.innerHTML=`
    <div>
      <div class="detail-section-title">観測された値</div>
      <div class="detail-box">${n(e.observed)}</div>
    </div>

    <div>
      <div class="detail-section-title">現状・セキュリティ上の意味</div>
      <div>${n(e.description)}</div>
    </div>

    <div>
      <div class="detail-section-title">推奨される対応方法</div>
      <div style="color:var(--accent-color);">${n(e.recommendation)}</div>
    </div>

    ${e.referenceUrls&&e.referenceUrls.length>0?`
      <div>
        <div class="detail-section-title">参考資料</div>
        ${e.referenceUrls.map(t=>`<a href="${t}" target="_blank" class="ref-link">${t}</a>`).join("")}
      </div>
    `:""}
  `,l.classList.remove("hidden")}function G(e){y.textContent=`Cookie: ${e.name}`,f.innerHTML=`
    <div>
      <div class="detail-section-title">属性詳細 (※値は除外)</div>
      <div>ドメイン: <strong>${n(e.domain)}</strong></div>
      <div>パス: <strong>${n(e.path)}</strong></div>
      <div>Secure: <strong>${e.secure?"有効":"無効"}</strong></div>
      <div>HttpOnly: <strong>${e.httpOnly?"有効":"無効"}</strong></div>
      <div>SameSite: <strong>${n(e.sameSite)}</strong></div>
      <div>有効期間: <strong>${e.session?"セッションCookie":"永続Cookie"}</strong></div>
    </div>

    ${e.issues&&e.issues.length>0?`
      <div>
        <div class="detail-section-title" style="color:var(--warning-color);">検出された課題</div>
        <ul style="padding-left:16px;">
          ${e.issues.map(t=>`<li>${n(t)}</li>`).join("")}
        </ul>
      </div>
    `:'<div style="color:var(--success-color);">重大な属性設定の不備は検出されませんでした。</div>'}
  `,l.classList.remove("hidden")}function b(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF"}[e]||e}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
