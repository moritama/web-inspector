import{d as Y,a as K}from"./json-CoecK1H4.js";import{r as X}from"./advisory-ByeU5uPK.js";function Z(e,t){const n=[],s=Q(e,t),r=new Map(e.technologies.map(a=>[a.technology,a])),g=new Map(t.technologies.map(a=>[a.technology,a]));for(const[a,u]of g)r.has(a)||n.push({id:`tech:add:${a}`,category:"technology",target:a,diffType:"Added",diffCause:s?"unknown":"site-change",causeExplanation:s?"調査範囲の違い、またはサイト側の技術追加による可能性があります。":`サイト側で ${a} (${u.version?`v${u.version}`:"バージョン不明"}) が新たに導入されました。`,before:null,after:u.version?`v${u.version}`:"検出"});for(const[a,u]of r)g.has(a)||n.push({id:`tech:rem:${a}`,category:"technology",target:a,diffType:"Removed",diffCause:s?"inspection-difference":"site-change",causeExplanation:s?"調査権限または取得対象範囲の違いにより検出されなかった可能性があります。":`サイト側で ${a} の使用が停止または別技術へ移行されました。`,before:u.version?`v${u.version}`:"検出",after:null});for(const[a,u]of g){const f=r.get(a);if(f)if(f.version!==u.version)n.push({id:`tech:ver:${a}`,category:"technology",target:a,diffType:"Changed",diffCause:"site-change",causeExplanation:`サイト側でバージョンが ${f.version||"不明"} から ${u.version||"不明"} へ更新されました。`,before:f.version||"不明",after:u.version||"不明"});else{const C=f.advisories?.length??0,S=u.advisories?.length??0;if(C!==S){const W=S>C;n.push({id:`advisory:${a}`,category:"security",target:`${a} 既知脆弱性情報`,diffType:W?"Regressed":"Resolved",diffCause:"advisory-update",causeExplanation:`サイトのバージョンは不変ですが、オフライン脆弱性DBの更新により該当アドバイザリが ${C}件 から ${S}件 へ変化しました。`,before:`${C} 件`,after:`${S} 件`})}}}const d=new Map(e.securityChecks.map(a=>[a.checkId||a.name,a])),c=new Map(t.securityChecks.map(a=>[a.checkId||a.name,a]));for(const[a,u]of c){const f=d.get(a);if(!f)continue;const C=f.status==="warning"||f.status==="fail",S=u.status==="warning"||u.status==="fail";!C&&S?n.push({id:`sec:reg:${a}`,category:"security",target:u.name,diffType:"Regressed",diffCause:s?"unknown":"site-change",causeExplanation:s?"調査範囲の違い、またはサイト設定の変更により警告が検出されました。":"サイトの設定変更またはヘッダーの変更により、新たに指摘項目が発生しました。",before:f.observed,after:u.observed}):C&&!S&&n.push({id:`sec:res:${a}`,category:"security",target:u.name,diffType:"Resolved",diffCause:"site-change",causeExplanation:"セキュリティヘッダーまたは属性設定が修正され、問題が解消されました。",before:f.observed,after:u.observed})}let l=0,h=0,y=0,o=0,m=0;const $={"site-change":0,"advisory-update":0,"rule-update":0,"inspection-difference":0,unknown:0};for(const a of n)a.diffType==="Added"?l++:a.diffType==="Removed"?h++:a.diffType==="Changed"?y++:a.diffType==="Resolved"?o++:a.diffType==="Regressed"&&m++,$[a.diffCause]=($[a.diffCause]||0)+1;const E=new Set(e.technologies.map(a=>a.technology)),T=new Set(t.technologies.map(a=>a.technology)),x=Array.from(T).filter(a=>!E.has(a)),J=Array.from(E).filter(a=>!T.has(a)),M=[];for(const a of t.technologies){const u=r.get(a.technology);u&&u.version!==a.version&&M.push({technology:a.technology,before:u.version,after:a.version})}const P=new Set(e.securityChecks.filter(a=>a.status==="warning"||a.status==="fail").map(a=>a.name)),A=new Set(t.securityChecks.filter(a=>a.status==="warning"||a.status==="fail").map(a=>a.name)),G=Array.from(A).filter(a=>!P.has(a)),q=Array.from(P).filter(a=>!A.has(a));return{reportA:e,reportB:t,diffItems:n,summary:{addedCount:l,removedCount:h,changedCount:y,resolvedCount:o,regressedCount:m,causes:$},addedTechnologies:x,removedTechnologies:J,versionChanges:M,newSecurityIssues:G,resolvedSecurityIssues:q}}function Q(e,t){return e.coverage?.overallStatus!==t.coverage?.overallStatus||e.coverage?.dom!==t.coverage?.dom}function ee(e){try{const t=new URL(e),n=["token","key","auth","secret","password","passwd","sig","signature","access_token","api_key"];for(const s of Array.from(t.searchParams.keys()))n.some(r=>s.toLowerCase().includes(r))&&t.searchParams.set(s,"***MASKED***");return t.username="",t.password="",t.toString()}catch{return e}}function p(e){return e?e.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/\*/g,"\\*").replace(/_/g,"\\_").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\|/g,"\\|").replace(/\r\n|\n|\r/g," "):""}function te(e,t,n=[]){const s=ee(e.url),r=e.hostname,g=new Date(e.inspectedAt).toLocaleString("ja-JP",{timeZone:"Asia/Tokyo"}),d=e.extensionVersion||"1.3.3",c=[];c.push(`# Web Technology & Security Inspection Report

**対象ホスト:** \`${r}\`  
**調査実施日時:** ${g} (JST)  
**Inspector バージョン:** v${d} (Manifest V3)  
**解析方式:** 受動的解析 (Passive Inspection) / 完全ローカル突合  

---`),c.push(`## 1. 調査概要

| 項目 | 内容 |
|---|---|
| 対象URL | \`${s}\` |
| ホスト名 | \`${r}\` |
| プロトコル | ${e.summary.isHttps?"HTTPS (暗号化通信)":"HTTP (非暗号化)"} |
| 診断ルールバージョン | ${p(e.rulesVersion)} |
| オフライン脆弱性DBバージョン | ${p(e.advisoryDatabaseVersion||"2026.10")} |
| 要確認項目数 | **${e.summary.requiresAttentionCount} 件** |
| 検出技術スタック数 | **${e.summary.totalTechnologies} 件** |
`);const l=e.coverage,h=l?.overallStatus==="complete"?"完全 (Complete)":l?.overallStatus==="partial"?"一部制限あり (Partial)":"未取得 (Unavailable)";c.push(`## 2. 調査範囲・完全性 (Coverage)

- **完全性ステータス:** **${h}**
- **DOM / HTML解析:** ${l?.dom==="complete"?"✅ 取得成功":"⚠️ 一部または未取得"}
- **HTTPレスポンスヘッダー:** ${l?.headers==="complete"?"✅ 取得成功":"⚠️ 未取得 (キャッシュ/事前スキャンなし)"}
- **Cookie属性情報:** ${l?.cookies==="complete"?`✅ 取得成功 (${e.cookies.length} 個観測)`:"⚠️ 権限なし/未取得"}
- **ネットワーク・通信解析:** ${l?.network==="complete"?"✅ 取得成功":"⚠️ 一部制限あり"}
${l?.details?.missingPermissions&&l.details.missingPermissions.length>0?`
> [!NOTE]
> **未付与の権限:** ${l.details.missingPermissions.map(o=>`\`${o}\``).join(", ")}
`:""}
`),c.push(`## 3. 調査結果サマリー

### セキュリティ指摘レベル内訳
| 重大度 | 指摘件数 | 説明 |
|:---:|:---:|---|
| **HIGH (危険)** | **${e.summary.securityFindings.high}** | 直ちに対応・修正が推奨される設定不備・脆弱性 |
| **MEDIUM (警告)** | **${e.summary.securityFindings.medium}** | セキュリティ基準に抵触、またはサポート終了の技術 |
| **LOW (注意)** | **${e.summary.securityFindings.low}** | 改善が望ましい設定上の軽微な不備 |
| **INFO (情報)** | **${e.summary.securityFindings.info}** | 参考情報・セキュリティ良好な項目 |
`),c.push(`## 4. 検出技術スタック

> [!NOTE]
> **受動的調査の原則と推定関係:** 固有シグナルから直接検出された技術と、依存関係から連動検知された技術を明確に区分しています。外部からの受動観測ではサーバー内部の実行状態を直接観測できない技術は「稼働未確認」として記録しています。

| 技術名 | カテゴリ | バージョン | 検出方式 | 連動元 / 種別 | ランタイム状態 | 確信度 | 整合性 |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
${e.technologies.length>0?e.technologies.map(o=>{const m=o.isCandidateGroup?"いずれかの可能性":o.version?`v${o.version}`:"不明",$=o.isCandidateGroup||o.detectionMethod==="associated"?"候補・関連":o.detectionMethod==="inferred"?"連動検知":"直接検出",E=o.inferredFrom?`${o.inferredFrom} (${o.implicationType||"連動"})`:"-",T=o.runtimeStatus==="confirmed"?"稼働確認済":o.runtimeStatus==="possible"?"稼働可能性あり":o.runtimeStatus==="unknown"?"稼働未確認":"-",x=o.versionIntegrity?.status==="mismatch"?"⚠️ 不一致":o.versionIntegrity?.status==="match"?"一致":"-";return`| **${p(o.technology)}** | ${p(o.category)} | \`${p(m)}\` | ${$} | ${p(E)} | ${T} | ${o.confidenceLevel} (${o.confidence}%) | ${x} |`}).join(`
`):"| なし | - | - | - | - | - | - | - |"}
`),c.push(`## 5. セキュリティ診断結果

| 診断項目 | ステータス | 重大度 | 観測値 | 許容状態 |
|---|:---:|:---:|---|:---:|
${e.securityChecks.length>0?e.securityChecks.map(o=>{const m=o.status==="pass"?"PASS":o.status==="fail"?"**FAIL**":"**WARN**",$=o.exceptionStatus==="accepted"?"🛡️ 許容済":o.exceptionStatus==="false-positive"?"❌ 誤検知除外":"-";return`| ${p(o.name)} | ${m} | ${o.severity.toUpperCase()} | \`${p(o.observed.substring(0,60))}\` | ${$} |`}).join(`
`):"| なし | - | - | - | - |"}
`),c.push(`## 6. EOL・既知脆弱性情報 (ライブラリセキュリティ)

> [!IMPORTANT]
> オフライン脆弱性DBスナップショット (Rev.2.1) とのローカル突合結果です。未登録の技術は「安全」を意味するものではありません。

| 対象技術 | バージョン | サポート状況 (EOL) | 照合ステータス | 該当CVE | 推奨対応 |
|---|:---:|:---:|:---:|---|---|
${e.technologies.map(o=>{const m=o.supportStatus==="EOL"?`**EOL (${o.eolDate||"終了"})**`:o.supportStatus||"Unknown",$=o.offlineMatchStatus||"Not Covered",E=o.advisories&&o.advisories.length>0?o.advisories.map(x=>`[${x.id}](https://nvd.nist.gov/vuln/detail/${x.id}) (${x.severity})`).join(", "):"該当なし",T=o.advisories&&o.advisories.length>0?`修正版 (v${o.advisories[0].fixedVersion||"最新"}) への更新`:o.supportStatus==="EOL"?"最新LTS系列への移行":"現状維持";return`| **${p(o.technology)}** | \`${p(o.version||"不明")}\` | ${m} | \`${$}\` | ${E} | ${T} |`}).join(`
`)}
`),c.push(`## 7. Cookie属性診断

※ **セキュリティ保護:** Cookieの値（Value）および認証シークレットは一切収集・出力していません。

| Cookie名 | ドメイン | パス | 用途分類 | Secure | HttpOnly | SameSite | CHIPS (Partitioned) |
|---|---|---|:---:|:---:|:---:|:---:|:---:|
${e.cookies.length>0?e.cookies.map(o=>`| \`${p(o.name)}\` | \`${p(o.domain||"-")}\` | \`${p(o.path||"-")}\` | ${p(o.category||"general")} | ${o.secure?"Yes":"**No**"} | ${o.httpOnly?"Yes":"**No**"} | \`${o.sameSite||"-"}\` | ${o.partitioned?"Yes":"No"} |`).join(`
`):"| なし | - | - | - | - | - | - | - |"}
`),c.push(`## 8. CSP（Content Security Policy）診断

- **CSPポリシー保持件数:** ${e.cspPolicies?.length??0} 件
${e.cspPolicies&&e.cspPolicies.length>0?e.cspPolicies.map((o,m)=>`
#### ポリシー #${m+1} [取得元: ${o.source}, モード: ${o.mode}]
\`\`\`text
${o.rawValue}
\`\`\`
`).join(`
`):"> CSPヘッダーまたはmetaタグによるCSPは設定されていません。"}
`);const y=e.externalConnections;return c.push(`## 9. 外部通信先・サードパーティ分析 (Public Suffix List / eTLD+1)

- **総通信先ホスト数:** ${y?.totalConnections??0} 件
- **First-Party (同一組織・自社ドメイン):** ${y?.firstPartyCount??0} 件
- **Third-Party (外部サービス通信先):** ${y?.thirdPartyCount??0} 件

| 接続先ホスト名 | 登録可能ドメイン (eTLD+1) | 所属種別 | 推定カテゴリ | 観測リソース数 |
|---|---|:---:|:---:|:---:|
${y&&y.connections.length>0?y.connections.map(o=>{const m=o.partyType==="first-party"?"First-Party":o.partyType==="third-party"?"**Third-Party**":"Local";return`| \`${p(o.hostname)}\` | \`${p(o.registrableDomain)}\` | ${m} | \`${o.category}\` | ${o.resourceCount} |`}).join(`
`):"| 外部通信先は観測されませんでした | - | - | - | - |"}
`),c.push(`## 10. 前回調査との差分 (Diff)

> 前回調査レポートとの比較は実行されていません（初回調査または単一レポート出力）。
`),c.push(`## 11. 差分発生原因の推定分析

> 分析対象の有意な差分変化はありません。
`),c.push(`## 12. 診断項目の許容・除外設定 (Finding Exceptions)

${n.length>0?`
| 状態 | 対象安定ID (FindingId) | 適用スコープ | 許容理由 | 登録日 |
|:---:|---|---|---|:---:|
${n.map(o=>`| **${o.status==="accepted"?"リスク許容":o.status==="false-positive"?"誤検知":"通知抑制"}** | \`${p(o.findingId)}\` | \`${p(o.targetUrl||"全体適用")}\` | ${p(o.reason)} | ${o.createdAt?o.createdAt.slice(0,10):"-"} |`).join(`
`)}
`:"> 現在適用されている許容・除外設定はありません。"}
`),c.push("## 13. 推奨対応ロードマップ\n\n1. **至急対応 (High Severity):**\n   - 既知脆弱性（CVE）が特定されたライブラリを修正済みバージョン以降へ更新する。\n   - 暗号化通信（HTTPS）および混在コンテンツ（Mixed Content）の解消。\n2. **計画的対応 (Medium Severity):**\n   - サポート終了（EOL）を迎えたミドルウェア・ライブラリの次世代LTS系列への移行計画策定。\n   - セッションCookieに対する `Secure`、`HttpOnly`、適切な `SameSite` 属性の付与。\n   - Content-Security-Policy (CSP) の導入および `unsafe-inline` の排除。\n3. **継続的改善 (Low / Best Practices):**\n   - HSTS (`Strict-Transport-Security`) ヘッダーの `max-age=31536000; includeSubDomains` 適用。\n   - 外部サードパーティスクリプトの棚卸しと整合性検証 (SRI) の導入。\n"),c.push(`## 14. 検出根拠 (エビデンス詳細)

${e.technologies.map(o=>`
### ${o.technology} (確信度: ${o.confidenceLevel} - ${o.confidence}%)
${o.evidence.map(m=>`- **[${m.type}]** \`${p(m.name)}\`: \`${p(m.value)}\` ${m.detail?`(${p(m.detail)})`:""}`).join(`
`)}
`).join(`
`)}
`),c.push(`## 15. 調査上の制限事項・免責事項

1. **受動的解析のスコープ:**
   本拡張機能は、ブラウザが通常のWeb閲覧時に受信したHTML、CSS、JavaScript、HTTPヘッダー、Cookie属性のみを受動的に解析（Passive Inspection）しています。外部サーバーへの攻撃的なリクエスト送信や内部ソースコードの監査は行っていません。
2. **脆弱性DBの網羅性:**
   オフライン脆弱性DBに未収録のライブラリや独自フレームワークについて「脆弱性なし」と判定されていても、安全性を完全に保証するものではありません。
3. **認証後ページの扱い:**
   ログインや特定セッションを必要とする深層ページは、閲覧した範囲に限定して診断されます。
4. **機密情報の非保持:**
   Cookieの値、認証トークン、Authorizationヘッダーなどのシークレット情報はメモリ保持およびレポート出力から完全に除外されています。
`),c.join(`

`)}function ne(e,t,n=[]){const s=te(e,t,n),r=new Blob([s],{type:"text/markdown;charset=utf-8"}),g=URL.createObjectURL(r),d=e.hostname.replace(/[^a-zA-Z0-9.-]/g,"_"),c=new Date(e.inspectedAt).toISOString().slice(0,10),l=`web-inspector-report-${d}-${c}.md`,h=document.createElement("a");h.href=g,h.download=l,document.body.appendChild(h),h.click(),document.body.removeChild(h),URL.revokeObjectURL(g)}let v=null,b=[];const se=document.getElementById("currentHostname"),oe=document.getElementById("inspectedAtTime"),H=document.getElementById("dashAdvisoryDbDate"),ae=document.getElementById("dashTotalTechs"),ie=document.getElementById("dashAttentionCount"),re=document.getElementById("dashEolCount"),de=document.getElementById("dashVulnCount"),ce=document.getElementById("dashHttpsStatus"),le=document.getElementById("dashMixedStatus"),D=document.getElementById("overviewLibrarySecList"),R=document.getElementById("overviewSecurityList"),j=document.getElementById("librarySecurityTableContainer"),O=document.getElementById("fullTechsContainer"),ue=document.getElementById("fullSecurityContainer"),V=document.getElementById("cookiesTableBody"),z=document.getElementById("historyListContainer"),L=document.getElementById("exceptionsTableContainer"),I=document.getElementById("compareSelectA"),B=document.getElementById("compareSelectB"),pe=document.getElementById("executeCompareBtn"),ge=document.getElementById("compareResultContainer"),k=document.getElementById("domainsContainer"),me=document.getElementById("themeToggleBtn"),F=document.getElementById("exportMdBtn"),ve=document.getElementById("exportJsonBtn"),fe=document.getElementById("exportCsvBtn"),he=document.getElementById("refreshBtn"),ye=document.getElementById("clearHistoryBtn");document.addEventListener("DOMContentLoaded",async()=>{be(),$e(),Ce(),Se(),await w()});function $e(){const e=document.getElementById("dashboardVersion");if(e){const t=chrome.runtime?.getManifest?.()?.version||"1.6.3";e.textContent=`v${t}`}}function be(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function xe(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function Ce(){document.querySelectorAll(".nav-item").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active")),document.querySelectorAll(".view-panel").forEach(n=>n.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-view");t&&(document.getElementById(t)?.classList.add("active"),t==="exceptionsView"?N():t==="domainsView"&&_(v?.externalConnections))})})}function Se(){me.addEventListener("click",xe),he.addEventListener("click",w),F&&F.addEventListener("click",()=>{v&&ne(v)}),ve.addEventListener("click",()=>{v&&Y(v)}),fe.addEventListener("click",()=>{v&&K(v)}),ye.addEventListener("click",async()=>{confirm("すべての調査履歴を完全に削除しますか？")&&(await chrome.runtime.sendMessage({type:"CLEAR_HISTORY"}),await w())}),pe.addEventListener("click",Pe)}async function w(){try{const e=await chrome.runtime.sendMessage({type:"GET_ALL_REPORTS"});if(e&&e.success&&e.reports.length>0)b=e.reports,v=b[0];else{const t=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});t&&t.success&&(v=t.report,b=[v])}v&&(U(v),Me(b),Be(b))}catch(e){console.error("Failed to load dashboard data:",e)}}function U(e){se.textContent=e.hostname,oe.textContent=`調査日時: ${new Date(e.inspectedAt).toLocaleString("ja-JP")}`,H&&(H.textContent=`🛡️ 脆弱性DB: ${e.advisoryDatabaseVersion||"2026-10-23"}`),ae.textContent=String(e.technologies.length),ie.textContent=String(e.summary.requiresAttentionCount);const t=e.summary.librarySecurity?.eolCount??0,n=e.summary.librarySecurity?.vulnerableLibraryCount??0;re.textContent=String(t),de.textContent=`既知脆弱性: ${n}件 / 不一致: ${e.summary.librarySecurity?.mismatchCount??0}件`,ce.textContent=e.summary.isHttps?"HTTPS (暗号化)":"HTTP (非暗号化)",le.textContent=`混在コンテンツ: ${e.summary.mixedContentCount}件`,Ee(e.technologies),Te(e.securityChecks),we(e.technologies),Le(e.technologies,e.coverage),ke(e.securityChecks),Ie(e.cookies),_(e.externalConnections)}function Ee(e){const t=e.filter(n=>n.supportStatus==="EOL"||n.advisories&&n.advisories.length>0||n.versionIntegrity?.status==="mismatch");if(t.length===0){D.innerHTML='<div style="color:var(--success-color);padding:12px 0;">ライブラリのサポート終了や既知脆弱性は検出されませんでした。</div>';return}D.innerHTML=t.map(n=>{let s=[];return n.supportStatus==="EOL"&&s.push(`EOL (${n.eolDate||"サポート終了"})`),n.advisories&&n.advisories.length>0&&s.push(`CVE ${n.advisories.length}件`),n.versionIntegrity?.status==="mismatch"&&s.push("CSS/JS不一致"),`
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border-color);">
          <div>
            <strong>${i(n.technology)}</strong>
            <span style="color:var(--text-muted);font-size:12px;margin-left:6px;">${n.version?`v${i(n.version)}`:""}</span>
            <div style="font-size:11px;color:var(--text-sub);">${i(s.join(" / "))}</div>
          </div>
          <span class="badge ${n.supportStatus==="EOL"?"badge-eol":"badge-cve"}">要確認</span>
        </div>
      `}).join("")}function Te(e){const t=e.filter(n=>n.status==="warning"||n.status==="fail");if(t.length===0){R.innerHTML='<div style="color:var(--success-color);padding:12px 0;">重大なセキュリティ設定不備は検出されませんでした。</div>';return}R.innerHTML=t.slice(0,5).map(n=>`
    <div style="padding:8px 0;border-bottom:1px solid var(--border-color);">
      <div style="display:flex;justify-content:space-between;">
        <strong>${i(n.name)}</strong>
        <span class="badge ${n.severity==="high"?"sev-high":"sev-medium"}">${n.severity.toUpperCase()}</span>
      </div>
      <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">${i(n.description)}</div>
    </div>
  `).join("")}function we(e){if(e.length===0){j.innerHTML='<div class="empty-state">技術情報がありません</div>';return}const t=e.map(n=>{const s=n.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':n.supportStatus==="Maintenance"?'<span class="badge badge-medium">保守</span>':n.supportStatus==="Supported"?'<span class="badge badge-high">Supported</span>':'<span class="badge" style="background:var(--bg-hover);">Unknown</span>';let r='<span class="badge sev-pass">該当なし</span>';n.offlineMatchStatus==="Matched"||n.advisories&&n.advisories.length>0?r=`<span class="badge badge-cve">該当 ${n.advisories?.length??0}件 (CVSS ${n.maxCvss||"6.1"})</span>`:n.offlineMatchStatus==="Not Covered"?r='<span style="color:var(--text-muted);font-size:11px;">未登録</span>':n.offlineMatchStatus==="Unknown Version"&&(r='<span class="badge badge-medium">要確認</span>'),n.isStale&&(r+=' <span style="font-size:10px;color:var(--warning-color);">[DB古]</span>');const g=n.versionIntegrity?n.versionIntegrity.status==="match"?'<span class="badge badge-high">一致</span>':n.versionIntegrity.status==="mismatch"?'<span class="badge badge-medium">不一致</span>':'<span style="color:var(--text-muted);font-size:11px;">判定不能</span>':'<span style="color:var(--text-muted);font-size:11px;">-</span>';let d="現状維持";if(n.isCandidateGroup)d="稼働しているバックエンド環境の特定を推奨";else if(n.advisories&&n.advisories.length>0){const l=X(n.version,n.advisories);d=l?`脆弱性修正版（v${l}以上）への更新推奨`:"脆弱性修正版への更新推奨"}else n.supportStatus==="EOL"?d="EOLのため最新LTS系列への移行推奨":n.offlineMatchStatus==="Unknown Version"&&n.version&&(d="パッケージ固有版のため個別セキュリティ情報の確認を推奨");const c=n.isCandidateGroup?'<span class="badge" style="background:var(--bg-hover);font-size:11px;">いずれかの可能性</span>':n.version?`v${i(n.version)}`:'<span style="color:var(--text-muted);">不明</span>';return`
        <tr>
          <td><strong>${i(n.technology)}</strong></td>
          <td>${c}</td>
          <td>${i(n.isCandidateGroup?"推定候補":n.versionSource||"-")}</td>
          <td>${g}</td>
          <td>${s} ${n.eolDate?`<span style="font-size:11px;color:var(--text-muted);">(${n.eolDate})</span>`:""}</td>
          <td>${r}</td>
          <td style="font-size:12px;color:var(--accent-color);">${i(d)}</td>
        </tr>
      `}).join("");j.innerHTML=`
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>技術・ライブラリ名</th>
            <th>代表バージョン</th>
            <th>取得元</th>
            <th>CSS/JS整合性</th>
            <th>サポート状態 (EOL)</th>
            <th>既知脆弱性 (CVE)</th>
            <th>推奨対応</th>
          </tr>
        </thead>
        <tbody>
          ${t}
        </tbody>
      </table>
    </div>
  `}function Le(e,t){const n=t&&t.networkHeadersObserved===!1?`<div style="background: rgba(245, 158, 11, 0.15); border: 1px solid var(--warning-color); border-radius: 6px; padding: 10px 14px; margin-bottom: 12px; font-size: 12px; color: var(--warning-color); line-height: 1.5;">
         ⚠️ <strong>HTTPレスポンスヘッダー未取得</strong>: 拡張機能起動前またはバックグラウンドスリープ中に開かれたタブです。サーバーや言語ヘッダーを診断するには、対象ページを再読み込み（リロード）して再調査してください。
       </div>`:"";if(e.length===0){O.innerHTML=n+'<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}O.innerHTML=n+e.map(s=>{let r="";s.isCandidateGroup||s.detectionMethod==="associated"?r='<span class="badge badge-associated">候補</span>':s.detectionMethod==="inferred"?r=`<span class="badge badge-inferred">連動${s.inferredFrom?` · ${i(s.inferredFrom)}`:""}</span>`:r='<span class="badge badge-direct">直接</span>';let g="";return s.runtimeStatus==="unknown"?g='<span class="badge badge-runtime-unknown">稼働未確認</span>':s.runtimeStatus==="possible"&&(g='<span class="badge badge-runtime-possible">稼働可能性</span>'),`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:15px;">${i(s.technology)}</span>
          ${r}
          ${g}
          ${s.isCandidateGroup?'<span class="badge" style="background:var(--bg-hover);font-size:11px;">いずれかの可能性</span>':s.version?`<span class="badge" style="background:var(--bg-hover);">v${i(s.version)}</span>`:'<span style="font-size:11px;color:var(--text-muted);">バージョン不明</span>'}
          <span style="font-size:12px;color:var(--text-muted);">${i(s.isCandidateGroup?"言語・FW候補":Ae(s.category))}</span>
        </div>
        <div style="display:flex;gap:6px;">
          ${s.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':""}
          ${s.advisories&&s.advisories.length>0?`<span class="badge badge-cve">CVE ${s.advisories.length}件</span>`:""}
          <span class="badge ${s.confidenceLevel==="high"?"badge-high":"badge-medium"}">確信度 ${s.confidence}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div style="margin-bottom:8px;padding:8px 12px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
          <div style="font-size:12px;margin-bottom:4px;">
            <strong>検出方式:</strong> ${He(s.detectionMethod,s.isCandidateGroup)}
            ${s.inferredFrom?` / <strong>推論元:</strong> ${i(s.inferredFrom)} (${De(s.implicationType)})`:""}
          </div>
          ${s.inferencePath&&s.inferencePath.length>1?`<div style="font-size:12px;margin-bottom:4px;"><strong>推論経路:</strong> <code>${i(s.inferencePath.join(" → "))}</code></div>`:""}
          <div style="font-size:12px;">
            <strong>ランタイム状態:</strong> ${Re(s.runtimeStatus)}
            ${s.runtimeStatus==="unknown"?'<span style="font-size:11px;color:var(--text-muted);margin-left:6px;">(※サーバー内部の稼働状態を観測できないため断定を保留)</span>':""}
          </div>
        </div>
        ${s.isCandidateGroup&&s.candidateTechnologies?`
          <div style="margin-bottom:8px;padding:8px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
            <strong>推定候補フレームワーク:</strong>
            <div style="display:flex;gap:6px;margin-top:4px;flex-wrap:wrap;">
              ${s.candidateTechnologies.map(d=>`<span class="badge" style="background:var(--bg-hover);">${i(d)}</span>`).join("")}
            </div>
          </div>
        `:""}
        <div>${i(s.description||"")}</div>
        ${s.website?`<div>公式サイト: <a href="${s.website}" target="_blank" style="color:var(--accent-color);">${s.website}</a></div>`:""}
        
        ${s.versionIntegrity?`
          <div style="margin-top:8px;padding:8px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
            <strong>CSS / JS バージョン整合性:</strong>
            <div>JavaScript: ${i(s.versionIntegrity.jsVersion||"未検出")} / CSS: ${i(s.versionIntegrity.cssVersion||"未検出")}</div>
            <div style="color:${s.versionIntegrity.status==="match"?"var(--success-color)":"var(--warning-color)"};">${i(s.versionIntegrity.detail)}</div>
          </div>
        `:""}

        ${s.advisories&&s.advisories.length>0?`
          <div style="margin-top:8px;">
            <strong style="color:var(--danger-color);">該当する既知脆弱性 (CVE / GHSA):</strong>
            <ul style="padding-left:18px;margin-top:4px;">
              ${s.advisories.map(d=>`
                <li style="margin-bottom:6px;">
                  <strong>${i(d.id)}</strong> (${d.title}) - 影響範囲: <code>${i(d.affectedRange)}</code>
                  ${d.fixedVersion?`<span style="color:var(--success-color);margin-left:6px;">修正版: v${i(d.fixedVersion)}</span>`:""}
                </li>
              `).join("")}
            </ul>
          </div>
        `:""}

        <div style="font-weight:700;margin-top:8px;">判定根拠 (Evidence):</div>
        <ul style="padding-left:18px;">
          ${s.evidence.map(d=>`
            <li>
              <strong>[${d.type}] ${i(d.name)}:</strong>
              <code>${i(d.value)}</code>
              ${d.detail?`<span style="color:var(--text-muted);margin-left:6px;">(${i(d.detail)})</span>`:""}
            </li>
          `).join("")}
        </ul>
      </div>
    </div>
  `}).join("")}function ke(e){ue.innerHTML=e.map(t=>{const s=t.exceptionStatus==="accepted"||t.exceptionStatus==="false-positive"||t.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:6px;">許容済</span>':"";return`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:14px;">${i(t.name)}</span>
          <span style="font-size:11px;color:var(--text-muted);">${i(t.checkId)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${s}
          <span class="badge ${t.status==="pass"?"sev-pass":t.severity==="high"?"sev-high":"sev-medium"}">${t.status==="pass"?"PASS":t.severity.toUpperCase()}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div><strong>観測値:</strong> <code>${i(t.observed)}</code></div>
        <div><strong>セキュリティ上の影響:</strong> ${i(t.description)}</div>
        <div style="color:var(--accent-color);"><strong>推奨対応:</strong> ${i(t.recommendation)}</div>
        ${t.exceptionReason?`<div style="background:rgba(59,130,246,0.1);padding:6px 10px;border-radius:4px;margin-top:6px;font-size:12px;color:var(--accent-color);"><strong>許容理由:</strong> ${i(t.exceptionReason)}</div>`:""}
        ${t.referenceUrls.length>0?`
          <div><strong>参考資料:</strong>
            ${t.referenceUrls.map(r=>`<a href="${r}" target="_blank" style="color:var(--accent-color);margin-left:8px;">${r}</a>`).join(", ")}
          </div>
        `:""}
      </div>
    </div>
  `}).join("")}function Ie(e){if(!e||e.length===0){V.innerHTML='<tr><td colspan="8" class="empty-state">Cookieは検出されませんでした</td></tr>';return}V.innerHTML=e.map(t=>`
    <tr>
      <td><strong>${i(t.name)}</strong></td>
      <td>${i(t.domain)}</td>
      <td>${i(t.path)}</td>
      <td>${t.secure?"✅":"❌"}</td>
      <td>${t.httpOnly?"✅":"❌"}</td>
      <td>${i(t.sameSite)}</td>
      <td>${t.session?"セッション":"永続"}</td>
      <td style="color:${t.issues.length>0?"var(--warning-color)":"var(--text-muted)"};">${t.issues.length>0?i(t.issues.join(", ")):"なし"}</td>
    </tr>
  `).join("")}function Be(e){if(e.length===0){z.innerHTML='<div class="empty-state">保存された履歴はありません</div>';return}z.innerHTML=e.map(t=>`
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;border:1px solid var(--border-color);border-radius:var(--radius-sm);margin-bottom:8px;background:var(--bg-surface);">
      <div>
        <strong>${i(t.hostname)}</strong>
        <span style="font-size:12px;color:var(--text-muted);margin-left:8px;">${new Date(t.inspectedAt).toLocaleString("ja-JP")}</span>
        <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">
          技術: ${t.technologies.length}件 / 要確認: ${t.summary.requiresAttentionCount}件 / EOL: ${t.summary.librarySecurity?.eolCount??0}件 / ${t.summary.isHttps?"HTTPS":"HTTP"}
        </div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-secondary btn-sm" onclick="window.viewReport('${t.id}')">表示</button>
        <button class="btn btn-danger btn-sm" onclick="window.deleteReport('${t.id}')">削除</button>
      </div>
    </div>
  `).join("")}window.viewReport=e=>{const t=b.find(n=>n.id===e);t&&(v=t,U(t),document.querySelector('.nav-item[data-view="overviewView"]')?.dispatchEvent(new Event("click")))};window.deleteReport=async e=>{confirm("この調査レポートを削除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_HISTORY_ITEM",id:e}),await w())};function Me(e){I.innerHTML="",B.innerHTML="",e.forEach((t,n)=>{const s=document.createElement("option");s.value=t.id,s.textContent=`${t.hostname} (${new Date(t.inspectedAt).toLocaleString("ja-JP")})`,I.appendChild(s);const r=document.createElement("option");r.value=t.id,r.textContent=`${t.hostname} (${new Date(t.inspectedAt).toLocaleString("ja-JP")})`,(n===1||n===0&&e.length===1)&&(r.selected=!0),B.appendChild(r)})}function Pe(){const e=I.value,t=B.value,n=b.find(d=>d.id===e),s=b.find(d=>d.id===t);if(!n||!s)return;const r=Z(n,s),g=Object.entries(r.summary.causes).filter(([d,c])=>c>0).map(([d,c])=>{let l=d;return d==="site-change"?l="Site Change (サイト側変更)":d==="advisory-update"?l="Advisory Update (脆弱性DB更新)":d==="inspection-difference"?l="Inspection Diff (調査権限差)":d==="rule-update"?l="Rule Update (診断ルール更新)":d==="unknown"&&(l="Unknown (複数/不明)"),`<span class="badge badge-medium" style="margin-right:6px;display:inline-block;margin-top:4px;">${i(l)}: ${c}件</span>`}).join("");ge.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">差分分析サマリー (Rev.2.1 IMP-09)</div>
      <div style="margin-bottom:8px;">
        検出された変化: <strong>${r.diffItems.length} 件</strong>
        (新規: ${r.summary.addedCount}, 消失: ${r.summary.removedCount}, 変更: ${r.summary.changedCount}, 解消: ${r.summary.resolvedCount}, 新規警告: ${r.summary.regressedCount})
      </div>
      <div>推定要因: ${g||'<span style="color:var(--text-muted);">差分なし</span>'}</div>
    </div>

    <div class="diff-box">
      <div class="diff-title">詳細な変化と原因分析</div>
      ${r.diffItems.length===0?'<div style="color:var(--text-muted);padding:8px 0;">2つの調査結果に変化はありませんでした。</div>':`
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>種別</th>
                <th>対象</th>
                <th>推定原因</th>
                <th>Before &rarr; After</th>
                <th>解説</th>
              </tr>
            </thead>
            <tbody>
              ${r.diffItems.map(d=>{let c="badge-medium";return(d.diffType==="Resolved"||d.diffType==="Added")&&(c="badge-high"),d.diffType==="Regressed"&&(c="badge-eol"),`
                    <tr>
                      <td><span class="badge ${c}">${d.diffType}</span></td>
                      <td><strong>${i(d.target)}</strong></td>
                      <td><span class="badge" style="background:var(--bg-hover);">${i(d.diffCause)}</span></td>
                      <td>${i(d.before||"-")} &rarr; <strong>${i(d.after||"-")}</strong></td>
                      <td style="font-size:12px;color:var(--text-sub);">${i(d.causeExplanation)}</td>
                    </tr>
                  `}).join("")}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `}async function N(){if(L)try{const t=(await chrome.runtime.sendMessage({type:"GET_FINDING_EXCEPTIONS"}))?.exceptions||[];if(t.length===0){L.innerHTML='<div class="empty-state">登録されている許容・除外設定はありません。</div>';return}L.innerHTML=`
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>状態</th>
              <th>対象安定ID (FindingId)</th>
              <th>対象URL</th>
              <th>許容理由</th>
              <th>登録日</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            ${t.map(n=>`
              <tr>
                <td><span class="badge ${n.status==="accepted"?"badge-high":"badge-medium"}">${n.status==="accepted"?"リスク許容":n.status==="false-positive"?"誤検知":"通知抑制"}</span></td>
                <td><code>${i(n.findingId)}</code></td>
                <td>${i(n.targetUrl||"全体適用")}</td>
                <td>${i(n.reason)}</td>
                <td>${n.createdAt?new Date(n.createdAt).toLocaleString("ja-JP"):"-"}</td>
                <td><button class="btn btn-secondary revoke-ex-btn" data-id="${i(n.id)}" style="font-size:11px;padding:3px 8px;">解除</button></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `,document.querySelectorAll(".revoke-ex-btn").forEach(n=>{n.addEventListener("click",async s=>{const r=s.currentTarget.getAttribute("data-id");r&&confirm("この許容設定を解除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:r}),await N(),await w())})})}catch(e){L.innerHTML=`<div class="empty-state" style="color:var(--danger-color);">許容設定の取得に失敗しました: ${e}</div>`}}function _(e){if(!k)return;if(!e||!e.connections||e.connections.length===0){k.innerHTML='<div class="empty-state">外部通信先情報はまだ解析されていません。</div>';return}const t={cdn:"CDN・静的配信",analytics:"アクセス解析",advertising:"広告・マーケティング",fonts:"Webフォント",social:"SNSウィジェット",api:"外部API",other:"その他"},n=Object.entries(e.categoryBreakdown).filter(([s,r])=>r>0).map(([s,r])=>`<span class="badge badge-medium" style="margin-right:6px;display:inline-block;margin-top:4px;">${i(t[s]||s)}: ${r}件</span>`).join("");k.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">通信先ドメイン集計 (eTLD+1 / Public Suffix List 判定)</div>
      <div style="margin-bottom:8px;">
        検出ホスト数: <strong>${e.totalConnections} 件</strong>
        (自社/First-Party: <strong>${e.firstPartyCount}</strong>, 外部/Third-Party: <strong>${e.thirdPartyCount}</strong>)
      </div>
      <div>推定用途別内訳: ${n||'<span style="color:var(--text-muted);">-</span>'}</div>
    </div>

    <div class="diff-box">
      <div class="diff-title">通信先ホスト一覧</div>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>ホスト名</th>
              <th>eTLD+1 (組織ドメイン)</th>
              <th>分類</th>
              <th>用途カテゴリ</th>
              <th>リソース数</th>
              <th>サンプルURL</th>
            </tr>
          </thead>
          <tbody>
            ${e.connections.map(s=>{let r="badge-medium",g="Third-Party";s.partyType==="first-party"?(r="badge-high",g="First-Party (自社)"):s.partyType==="local"?(r="badge-low",g="Local (内部)"):(r="badge-medium",g="Third-Party (外部)");const d=s.sampleUrls.length>0?s.sampleUrls[0]:"";return`
                  <tr>
                    <td><strong>${i(s.hostname)}</strong></td>
                    <td><code>${i(s.registrableDomain||"-")}</code></td>
                    <td><span class="badge ${r}">${g}</span></td>
                    <td><span class="badge" style="background:var(--bg-hover);">${i(t[s.category]||s.category)}</span></td>
                    <td>${s.resourceCount}</td>
                    <td style="font-size:11px;color:var(--text-sub);max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${i(d)}">${i(d||"-")}</td>
                  </tr>
                `}).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `}function Ae(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF","hosting-cloud":"ホスティング / クラウド基盤","analytics-tracking":"アクセス解析 / タグ管理","security-service":"セキュリティ / 監視サービス"}[e]||e}function He(e,t){return t||e==="associated"?"実行環境候補・関連技術":e==="inferred"?"連動検知 (推論)":"直接検出"}function De(e){switch(e){case"framework-dependency":return"フレームワーク基盤依存";case"possible-runtime":return"実行環境の候補（静的配信等の代替構成あり）";case"runtime-dependency":return"実行時依存";case"technology-association":return"関連技術";default:return e||"連動"}}function Re(e){switch(e){case"confirmed":return"稼働確認済";case"possible":return"稼働可能性あり";case"unknown":return"稼働状態未確認";case"not-applicable":return"該当なし (クライアント技術)";default:return"未確認"}}function i(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
