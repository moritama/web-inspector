import{d as B,a as S}from"./json-B9bJ9Pcs.js";let c=null;const y=document.getElementById("siteHostname"),p=document.getElementById("statusIndicator"),I=document.getElementById("techCount"),w=document.getElementById("attentionCount"),$=document.getElementById("eolCount"),T=document.getElementById("tabTechCount"),M=document.getElementById("tabSecCount"),H=document.getElementById("tabCookieCount"),m=document.getElementById("techsList"),u=document.getElementById("securityList"),f=document.getElementById("cookiesList"),k=document.getElementById("rescanBtn"),D=document.getElementById("themeToggleBtn"),N=document.getElementById("openDashboardBtn"),_=document.getElementById("fullReportBtn"),A=document.getElementById("exportJsonBtn"),z=document.getElementById("exportCsvBtn"),r=document.getElementById("detailModal"),x=document.getElementById("modalTitle"),b=document.getElementById("modalBody"),O=document.getElementById("closeModalBtn");document.addEventListener("DOMContentLoaded",()=>{V(),U(),G(),g()});function U(){const e=document.getElementById("brandVersion");if(e){const t=chrome.runtime?.getManifest?.()?.version||"1.5.0";e.textContent=`v${t}`}}function V(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function F(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function G(){D.addEventListener("click",F),k.addEventListener("click",()=>g()),N.addEventListener("click",E),_.addEventListener("click",E),A.addEventListener("click",()=>{c&&B(c)}),z.addEventListener("click",()=>{c&&S(c)}),document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(i=>i.classList.remove("active")),document.querySelectorAll(".tab-pane").forEach(i=>i.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-tab");t&&document.getElementById(t)?.classList.add("active")})}),O.addEventListener("click",()=>{r.classList.add("hidden")}),r.addEventListener("click",e=>{e.target===r&&r.classList.add("hidden")})}function E(){const e=chrome.runtime.getURL("dashboard.html");chrome.tabs.create({url:e})}async function g(){p.className="status-indicator",y.textContent="調査中...",m.innerHTML='<div class="empty-state">技術情報を解析中...</div>',u.innerHTML='<div class="empty-state">セキュリティ設定を診断中...</div>',f.innerHTML='<div class="empty-state">Cookie属性を取得中...</div>';try{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});if(!e||!e.success)throw new Error(e?.error||"調査に失敗しました。");c=e.report,R(c)}catch(e){const t=e instanceof Error?e.message:String(e);y.textContent="調査エラー",p.className="status-indicator",p.style.backgroundColor="#EF4444",m.innerHTML=`<div class="empty-state" style="color: #EF4444;">${t}</div>`}}function R(e){p.className="status-indicator ready",y.textContent=e.hostname,I.textContent=String(e.technologies.length),w.textContent=String(e.summary.requiresAttentionCount);const t=(e.summary.librarySecurity?.eolCount??0)+(e.summary.librarySecurity?.vulnerableLibraryCount??0);$&&($.textContent=String(t)),T.textContent=String(e.technologies.length),M.textContent=String(e.securityChecks.length),H.textContent=String(e.cookies.length),j(e.technologies),J(e.securityChecks),P(e.cookies);const i=document.getElementById("advisoryDbBar");if(i){const a=e.advisoryDatabaseVersion||"2026-10-23";i.textContent=`🛡️ 脆弱性DB更新日: ${a}`}}function j(e){if(e.length===0){m.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}m.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.confidenceLevel==="high"?"badge-high":t.confidenceLevel==="medium"?"badge-medium":"badge-low",o=t.confidenceLevel==="high"?"高":t.confidenceLevel==="medium"?"中":"低";let l="";t.supportStatus==="EOL"?l='<span class="badge badge-eol">EOL</span>':t.supportStatus==="Maintenance"&&(l='<span class="badge badge-medium">保守</span>');let d="";t.advisories&&t.advisories.length>0&&(d=`<span class="badge badge-cve">CVE ${t.maxCvss?`CVSS ${t.maxCvss}`:`${t.advisories.length}件`}</span>`);let s="";t.versionIntegrity?.status==="mismatch"&&(s='<span class="badge badge-mismatch">不一致</span>');let v=t.isCandidateGroup?"いずれかの可能性あり":t.version?`v${n(t.version)}`:"バージョン不明";t.versionSource==="runtime"&&(v+=" (実行時)");const L=t.isCandidateGroup?"？":t.technology.slice(0,2).toUpperCase(),h=t.isCandidateGroup?"言語・FW候補":C(t.category);i.innerHTML=`
      <div class="item-main">
        <div class="tech-icon-badge">${L}</div>
        <div class="item-texts">
          <span class="item-name">${n(t.technology)}</span>
          <div class="item-meta">
            <span class="item-version-badge">${n(v)}</span>
            <span>${n(h)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        ${s}
        ${l}
        ${d}
        <span class="badge ${a}">${o} · ${t.confidence}</span>
      </div>
    `,i.addEventListener("click",()=>q(t)),m.appendChild(i)})}function J(e){if(e.length===0){u.innerHTML='<div class="empty-state">診断項目がありません</div>';return}u.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";let a="sev-info",o="情報";t.status==="pass"?(a="sev-pass",o="適正"):t.severity==="high"?(a="sev-high",o="危険"):t.severity==="medium"?(a="sev-medium",o="警告"):t.severity==="low"&&(a="sev-low",o="注意");const d=t.exceptionStatus==="accepted"||t.exceptionStatus==="false-positive"||t.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:4px;">許容済</span>':"";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <span class="item-meta">${n(t.observed.substring(0,42))}</span>
        </div>
      </div>
      <div class="item-side">
        ${d}
        <span class="badge ${a}">${o}</span>
      </div>
    `,i.addEventListener("click",()=>W(t)),u.appendChild(i)})}function P(e){if(e.length===0){f.innerHTML='<div class="empty-state">観測されたCookieはありません</div>';return}f.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.issues&&t.issues.length>0,o=a?"sev-medium":"sev-pass",l=a?"要確認":"安全";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <div class="item-meta">
            <span>${t.secure?"🔒 Secure":"⚠️ 不保護"}</span>
            <span>${t.httpOnly?"🛡️ HttpOnly":"スクリプト可"}</span>
            <span>SameSite: ${n(t.sameSite)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${o}">${l}</span>
      </div>
    `,i.addEventListener("click",()=>X(t)),f.appendChild(i)})}function q(e){x.textContent=`${e.technology} 検出 & セキュリティ詳細`;let t="";if(e.versionIntegrity){const s=e.versionIntegrity,v=s.status==="match"?"var(--success-color)":s.status==="mismatch"?"var(--warning-color)":"var(--text-muted)";t=`
      <div>
        <div class="detail-section-title">CSS / JavaScript バージョン整合性</div>
        <div>JavaScript: <strong>${n(s.jsVersion||"未検出")}</strong> / CSS: <strong>${n(s.cssVersion||"未検出")}</strong></div>
        <div style="color:${v};font-weight:600;margin-top:2px;">判定: ${s.status==="match"?"一致 (OK)":s.status==="mismatch"?"要確認 (バージョン不一致)":"判定不能"}</div>
        <div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>
      </div>
    `}let i="";if(e.eolInfo){const s=e.eolInfo;i=`
      <div>
        <div class="detail-section-title">サポート状況 (EOL)</div>
        <div>ステータス: <strong style="color:${s.status==="EOL"?"var(--danger-color)":s.status==="Maintenance"?"var(--warning-color)":"var(--success-color)"};">${s.status}</strong> ${s.eolDate?`(EOL日: ${s.eolDate})`:""}</div>
        <div style="font-size:11px;color:var(--accent-color);">${n(s.recommendation)}</div>
        ${s.sourceUrl?`<div>出典: <a href="${s.sourceUrl}" target="_blank" class="ref-link">${s.sourceUrl}</a></div>`:""}
      </div>
    `}let a="";const o=e.offlineMatchStatus||"Not Covered",l=e.isStale?'<span style="color:var(--warning-color);margin-left:6px;font-size:11px;">⚠️ DB鮮度: 31日以上経過</span>':"";if(e.advisories&&e.advisories.length>0)a=`
      <div>
        <div class="detail-section-title" style="color:var(--danger-color);">該当する既知脆弱性 (${e.advisories.length} 件) ${l}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">照合ステータス: <strong>${o}</strong></div>
        ${e.advisories.map(s=>`
          <div class="advisory-card">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <strong>${n(s.id)}</strong>
              ${s.cvssScore?`<span class="badge sev-high">CVSS ${s.cvssScore}</span>`:""}
            </div>
            <div style="font-weight:600;margin-top:2px;">${n(s.title)}</div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">${n(s.summary)}</div>
            <div style="font-size:11px;margin-top:4px;">
              <span>影響範囲: <code>${n(s.affectedRange)}</code></span>
              ${s.fixedVersion?`<span style="margin-left:8px;color:var(--success-color);">修正版: <strong>v${n(s.fixedVersion)}</strong></span>`:""}
            </div>
            ${s.referenceUrls.length>0?`<div style="margin-top:4px;"><a href="${s.referenceUrls[0]}" target="_blank" class="ref-link">詳細情報 (NVD / GitHub)</a></div>`:""}
          </div>
        `).join("")}
      </div>
    `;else{let s="この技術のオフライン脆弱性データは未収録です。";o==="No Match"?s="オフラインDBに収録されていますが、検出されたバージョンには該当する既知脆弱性はありません。":o==="Unknown Version"&&(s="バージョン不明、またはLinuxディストリビューション固有パッケージのため脆弱性断定を保留しています。"),a=`
      <div>
        <div class="detail-section-title">脆弱性照合状況 (オフラインDB) ${l}</div>
        <div style="font-size:12px;">ステータス: <strong>${o}</strong></div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${n(s)}</div>
      </div>
    `}const d=e.isCandidateGroup&&e.candidateTechnologies?`
      <div style="margin-bottom:12px;padding:10px;background:var(--bg-surface);border:1px solid var(--border-color);border-radius:6px;">
        <div style="font-weight:600;font-size:12px;color:var(--text-sub);margin-bottom:6px;">推定候補フレームワーク:</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          ${e.candidateTechnologies.map(s=>`<span class="badge" style="background:var(--bg-hover);color:var(--text-main);font-size:12px;padding:3px 8px;">${n(s)}</span>`).join("")}
        </div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:8px;">
          ${n(e.description||"")}
        </div>
      </div>
    `:"";b.innerHTML=`
    ${d}
    <div>
      <div class="detail-section-title">基本情報</div>
      <div>確信度スコア: <strong>${e.confidence}</strong> (${e.confidenceLevel.toUpperCase()})</div>
      <div>代表バージョン: <strong>${e.isCandidateGroup?"いずれかの可能性あり":e.version||"不明"}</strong> ${e.versionSource?`[取得元: ${n(e.versionSource)}]`:""}</div>
      <div>カテゴリ: ${n(e.isCandidateGroup?"言語・フレームワーク候補":C(e.category))}</div>
      ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" class="ref-link">${e.website}</a></div>`:""}
    </div>

    ${e.isCandidateGroup?"":t}
    ${e.isCandidateGroup?"":i}
    ${e.isCandidateGroup?"":a}

    <div>
      <div class="detail-section-title">判定根拠 (エビデンス)</div>
      ${e.evidence.map(s=>`
        <div class="evidence-item">
          <div><strong>[${s.type}]</strong> ${n(s.name)}</div>
          <div class="detail-box">${n(s.value)}</div>
          ${s.detail?`<div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>`:""}
        </div>
      `).join("")}
    </div>
  `,r.classList.remove("hidden")}function W(e){x.textContent=e.name;const t=e.exceptionStatus==="accepted"||e.exceptionStatus==="false-positive"||e.exceptionStatus==="muted";let i="";t?i=`
      <div style="background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.3);border-radius:6px;padding:8px 12px;margin-top:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <strong style="color:var(--accent-color);">🛡️ この指摘は許容設定済みです</strong>
            <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">理由: ${n(e.exceptionReason||"未指定")}</div>
          </div>
          <button id="modalRevokeExceptionBtn" class="action-btn" style="font-size:11px;padding:3px 8px;">許容を解除</button>
        </div>
      </div>
    `:(e.status==="warning"||e.status==="fail")&&(i=`
      <div style="margin-top:12px;display:flex;gap:8px;">
        <button id="modalAcceptFindingBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          🛡️ この指摘を許容する (リスク受容)
        </button>
        <button id="modalFalsePositiveBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          ❌ 誤検知として除外
        </button>
      </div>
    `),b.innerHTML=`
    <div>
      <div class="detail-section-title">観測された値</div>
      <div class="detail-box">${n(e.observed)}</div>
    </div>

    <div>
      <div class="detail-section-title">現状・セキュリティ上の意味</div>
      <div>${n(e.description)}</div>
    </div>

    <div>
      <div class="detail-section-title">推奨される対応方法</div>
      <div style="color:var(--accent-color);">${n(e.recommendation)}</div>
    </div>

    ${e.referenceUrls&&e.referenceUrls.length>0?`
      <div>
        <div class="detail-section-title">参考資料</div>
        ${e.referenceUrls.map(d=>`<a href="${d}" target="_blank" class="ref-link">${d}</a>`).join("")}
      </div>
    `:""}

    ${i}
  `;const a=document.getElementById("modalAcceptFindingBtn");a&&e.findingId&&a.addEventListener("click",async()=>{const d=prompt("許容する理由（社内合意、暫定運用等）を入力してください:","運用要件に基づくリスク受容")||"運用上のリスク受容";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:c?.url,status:"accepted",reason:d,createdAt:new Date().toISOString()}}),r.classList.add("hidden"),g()});const o=document.getElementById("modalFalsePositiveBtn");o&&e.findingId&&o.addEventListener("click",async()=>{const d=prompt("誤検知の理由を入力してください:","対象環境における仕様上不要")||"誤検知";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:c?.url,status:"false-positive",reason:d,createdAt:new Date().toISOString()}}),r.classList.add("hidden"),g()});const l=document.getElementById("modalRevokeExceptionBtn");l&&(e.exceptionId||e.findingId)&&l.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:e.exceptionId||e.findingId}),r.classList.add("hidden"),g()}),r.classList.remove("hidden")}function X(e){x.textContent=`Cookie: ${e.name}`,b.innerHTML=`
    <div>
      <div class="detail-section-title">属性詳細 (※値は除外)</div>
      <div>ドメイン: <strong>${n(e.domain)}</strong></div>
      <div>パス: <strong>${n(e.path)}</strong></div>
      <div>Secure: <strong>${e.secure?"有効":"無効"}</strong></div>
      <div>HttpOnly: <strong>${e.httpOnly?"有効":"無効"}</strong></div>
      <div>SameSite: <strong>${n(e.sameSite)}</strong></div>
      <div>有効期間: <strong>${e.session?"セッションCookie":"永続Cookie"}</strong></div>
    </div>

    ${e.issues&&e.issues.length>0?`
      <div>
        <div class="detail-section-title" style="color:var(--warning-color);">検出された課題</div>
        <ul style="padding-left:16px;">
          ${e.issues.map(t=>`<li>${n(t)}</li>`).join("")}
        </ul>
      </div>
    `:'<div style="color:var(--success-color);">重大な属性設定の不備は検出されませんでした。</div>'}
  `,r.classList.remove("hidden")}function C(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF"}[e]||e}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
