import{d as C,a as L}from"./json-B9bJ9Pcs.js";let r=null;const f=document.getElementById("siteHostname"),g=document.getElementById("statusIndicator"),S=document.getElementById("techCount"),B=document.getElementById("attentionCount"),E=document.getElementById("eolCount"),I=document.getElementById("tabTechCount"),w=document.getElementById("tabSecCount"),T=document.getElementById("tabCookieCount"),v=document.getElementById("techsList"),u=document.getElementById("securityList"),p=document.getElementById("cookiesList"),M=document.getElementById("rescanBtn"),H=document.getElementById("themeToggleBtn"),N=document.getElementById("openDashboardBtn"),k=document.getElementById("fullReportBtn"),D=document.getElementById("exportJsonBtn"),_=document.getElementById("exportCsvBtn"),l=document.getElementById("detailModal"),y=document.getElementById("modalTitle"),$=document.getElementById("modalBody"),A=document.getElementById("closeModalBtn");document.addEventListener("DOMContentLoaded",()=>{U(),O(),V(),m()});function O(){const e=document.getElementById("brandVersion");if(e){const t=chrome.runtime?.getManifest?.()?.version||"1.3.2";e.textContent=`v${t}`}}function U(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function z(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function V(){H.addEventListener("click",z),M.addEventListener("click",()=>m()),N.addEventListener("click",b),k.addEventListener("click",b),D.addEventListener("click",()=>{r&&C(r)}),_.addEventListener("click",()=>{r&&L(r)}),document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(i=>i.classList.remove("active")),document.querySelectorAll(".tab-pane").forEach(i=>i.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-tab");t&&document.getElementById(t)?.classList.add("active")})}),A.addEventListener("click",()=>{l.classList.add("hidden")}),l.addEventListener("click",e=>{e.target===l&&l.classList.add("hidden")})}function b(){const e=chrome.runtime.getURL("dashboard.html");chrome.tabs.create({url:e})}async function m(){g.className="status-indicator",f.textContent="調査中...",v.innerHTML='<div class="empty-state">技術情報を解析中...</div>',u.innerHTML='<div class="empty-state">セキュリティ設定を診断中...</div>',p.innerHTML='<div class="empty-state">Cookie属性を取得中...</div>';try{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});if(!e||!e.success)throw new Error(e?.error||"調査に失敗しました。");r=e.report,F(r)}catch(e){const t=e instanceof Error?e.message:String(e);f.textContent="調査エラー",g.className="status-indicator",g.style.backgroundColor="#EF4444",v.innerHTML=`<div class="empty-state" style="color: #EF4444;">${t}</div>`}}function F(e){g.className="status-indicator ready",f.textContent=e.hostname,S.textContent=String(e.technologies.length),B.textContent=String(e.summary.requiresAttentionCount);const t=(e.summary.librarySecurity?.eolCount??0)+(e.summary.librarySecurity?.vulnerableLibraryCount??0);E&&(E.textContent=String(t)),I.textContent=String(e.technologies.length),w.textContent=String(e.securityChecks.length),T.textContent=String(e.cookies.length),R(e.technologies),j(e.securityChecks),J(e.cookies)}function R(e){if(e.length===0){v.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}v.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.confidenceLevel==="high"?"badge-high":t.confidenceLevel==="medium"?"badge-medium":"badge-low",o=t.confidenceLevel==="high"?"高":t.confidenceLevel==="medium"?"中":"低";let d="";t.supportStatus==="EOL"?d='<span class="badge badge-eol">EOL</span>':t.supportStatus==="Maintenance"&&(d='<span class="badge badge-medium">保守</span>');let s="";t.advisories&&t.advisories.length>0&&(s=`<span class="badge badge-cve">CVE ${t.maxCvss?`CVSS ${t.maxCvss}`:`${t.advisories.length}件`}</span>`);let c="";t.versionIntegrity?.status==="mismatch"&&(c='<span class="badge badge-mismatch">不一致</span>');let x=t.version?`v${n(t.version)}`:"バージョン不明";t.versionSource==="runtime"&&(x+=" (実行時)"),i.innerHTML=`
      <div class="item-main">
        <div class="tech-icon-badge">${t.technology.slice(0,2).toUpperCase()}</div>
        <div class="item-texts">
          <span class="item-name">${n(t.technology)}</span>
          <div class="item-meta">
            <span class="item-version-badge">${n(x)}</span>
            <span>${n(h(t.category))}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        ${c}
        ${d}
        ${s}
        <span class="badge ${a}">${o} · ${t.confidence}</span>
      </div>
    `,i.addEventListener("click",()=>P(t)),v.appendChild(i)})}function j(e){if(e.length===0){u.innerHTML='<div class="empty-state">診断項目がありません</div>';return}u.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";let a="sev-info",o="情報";t.status==="pass"?(a="sev-pass",o="適正"):t.severity==="high"?(a="sev-high",o="危険"):t.severity==="medium"?(a="sev-medium",o="警告"):t.severity==="low"&&(a="sev-low",o="注意");const s=t.exceptionStatus==="accepted"||t.exceptionStatus==="false-positive"||t.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:4px;">許容済</span>':"";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <span class="item-meta">${n(t.observed.substring(0,42))}</span>
        </div>
      </div>
      <div class="item-side">
        ${s}
        <span class="badge ${a}">${o}</span>
      </div>
    `,i.addEventListener("click",()=>q(t)),u.appendChild(i)})}function J(e){if(e.length===0){p.innerHTML='<div class="empty-state">観測されたCookieはありません</div>';return}p.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.issues&&t.issues.length>0,o=a?"sev-medium":"sev-pass",d=a?"要確認":"安全";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <div class="item-meta">
            <span>${t.secure?"🔒 Secure":"⚠️ 不保護"}</span>
            <span>${t.httpOnly?"🛡️ HttpOnly":"スクリプト可"}</span>
            <span>SameSite: ${n(t.sameSite)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${o}">${d}</span>
      </div>
    `,i.addEventListener("click",()=>G(t)),p.appendChild(i)})}function P(e){y.textContent=`${e.technology} 検出 & セキュリティ詳細`;let t="";if(e.versionIntegrity){const s=e.versionIntegrity,c=s.status==="match"?"var(--success-color)":s.status==="mismatch"?"var(--warning-color)":"var(--text-muted)";t=`
      <div>
        <div class="detail-section-title">CSS / JavaScript バージョン整合性</div>
        <div>JavaScript: <strong>${n(s.jsVersion||"未検出")}</strong> / CSS: <strong>${n(s.cssVersion||"未検出")}</strong></div>
        <div style="color:${c};font-weight:600;margin-top:2px;">判定: ${s.status==="match"?"一致 (OK)":s.status==="mismatch"?"要確認 (バージョン不一致)":"判定不能"}</div>
        <div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>
      </div>
    `}let i="";if(e.eolInfo){const s=e.eolInfo;i=`
      <div>
        <div class="detail-section-title">サポート状況 (EOL)</div>
        <div>ステータス: <strong style="color:${s.status==="EOL"?"var(--danger-color)":s.status==="Maintenance"?"var(--warning-color)":"var(--success-color)"};">${s.status}</strong> ${s.eolDate?`(EOL日: ${s.eolDate})`:""}</div>
        <div style="font-size:11px;color:var(--accent-color);">${n(s.recommendation)}</div>
        ${s.sourceUrl?`<div>出典: <a href="${s.sourceUrl}" target="_blank" class="ref-link">${s.sourceUrl}</a></div>`:""}
      </div>
    `}let a="";const o=e.offlineMatchStatus||"Not Covered",d=e.isStale?'<span style="color:var(--warning-color);margin-left:6px;font-size:11px;">⚠️ DB鮮度: 31日以上経過</span>':"";if(e.advisories&&e.advisories.length>0)a=`
      <div>
        <div class="detail-section-title" style="color:var(--danger-color);">該当する既知脆弱性 (${e.advisories.length} 件) ${d}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">照合ステータス: <strong>${o}</strong></div>
        ${e.advisories.map(s=>`
          <div class="advisory-card">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <strong>${n(s.id)}</strong>
              ${s.cvssScore?`<span class="badge sev-high">CVSS ${s.cvssScore}</span>`:""}
            </div>
            <div style="font-weight:600;margin-top:2px;">${n(s.title)}</div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">${n(s.summary)}</div>
            <div style="font-size:11px;margin-top:4px;">
              <span>影響範囲: <code>${n(s.affectedRange)}</code></span>
              ${s.fixedVersion?`<span style="margin-left:8px;color:var(--success-color);">修正版: <strong>v${n(s.fixedVersion)}</strong></span>`:""}
            </div>
            ${s.referenceUrls.length>0?`<div style="margin-top:4px;"><a href="${s.referenceUrls[0]}" target="_blank" class="ref-link">詳細情報 (NVD / GitHub)</a></div>`:""}
          </div>
        `).join("")}
      </div>
    `;else{let s="この技術のオフライン脆弱性データは未収録です。";o==="No Match"?s="オフラインDBに収録されていますが、検出されたバージョンには該当する既知脆弱性はありません。":o==="Unknown Version"&&(s="バージョン不明、またはLinuxディストリビューション固有パッケージのため脆弱性断定を保留しています。"),a=`
      <div>
        <div class="detail-section-title">脆弱性照合状況 (オフラインDB) ${d}</div>
        <div style="font-size:12px;">ステータス: <strong>${o}</strong></div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${n(s)}</div>
      </div>
    `}$.innerHTML=`
    <div>
      <div class="detail-section-title">基本情報</div>
      <div>確信度スコア: <strong>${e.confidence}</strong> (${e.confidenceLevel.toUpperCase()})</div>
      <div>代表バージョン: <strong>${e.version||"不明"}</strong> ${e.versionSource?`[取得元: ${n(e.versionSource)}]`:""}</div>
      <div>カテゴリ: ${n(h(e.category))}</div>
      ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" class="ref-link">${e.website}</a></div>`:""}
    </div>

    ${t}
    ${i}
    ${a}

    <div>
      <div class="detail-section-title">判定根拠 (エビデンス)</div>
      ${e.evidence.map(s=>`
        <div class="evidence-item">
          <div><strong>[${s.type}]</strong> ${n(s.name)}</div>
          <div class="detail-box">${n(s.value)}</div>
          ${s.detail?`<div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>`:""}
        </div>
      `).join("")}
    </div>
  `,l.classList.remove("hidden")}function q(e){y.textContent=e.name;const t=e.exceptionStatus==="accepted"||e.exceptionStatus==="false-positive"||e.exceptionStatus==="muted";let i="";t?i=`
      <div style="background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.3);border-radius:6px;padding:8px 12px;margin-top:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <strong style="color:var(--accent-color);">🛡️ この指摘は許容設定済みです</strong>
            <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">理由: ${n(e.exceptionReason||"未指定")}</div>
          </div>
          <button id="modalRevokeExceptionBtn" class="action-btn" style="font-size:11px;padding:3px 8px;">許容を解除</button>
        </div>
      </div>
    `:(e.status==="warning"||e.status==="fail")&&(i=`
      <div style="margin-top:12px;display:flex;gap:8px;">
        <button id="modalAcceptFindingBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          🛡️ この指摘を許容する (リスク受容)
        </button>
        <button id="modalFalsePositiveBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          ❌ 誤検知として除外
        </button>
      </div>
    `),$.innerHTML=`
    <div>
      <div class="detail-section-title">観測された値</div>
      <div class="detail-box">${n(e.observed)}</div>
    </div>

    <div>
      <div class="detail-section-title">現状・セキュリティ上の意味</div>
      <div>${n(e.description)}</div>
    </div>

    <div>
      <div class="detail-section-title">推奨される対応方法</div>
      <div style="color:var(--accent-color);">${n(e.recommendation)}</div>
    </div>

    ${e.referenceUrls&&e.referenceUrls.length>0?`
      <div>
        <div class="detail-section-title">参考資料</div>
        ${e.referenceUrls.map(s=>`<a href="${s}" target="_blank" class="ref-link">${s}</a>`).join("")}
      </div>
    `:""}

    ${i}
  `;const a=document.getElementById("modalAcceptFindingBtn");a&&e.findingId&&a.addEventListener("click",async()=>{const s=prompt("許容する理由（社内合意、暫定運用等）を入力してください:","運用要件に基づくリスク受容")||"運用上のリスク受容";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:r?.url,status:"accepted",reason:s,createdAt:new Date().toISOString()}}),l.classList.add("hidden"),m()});const o=document.getElementById("modalFalsePositiveBtn");o&&e.findingId&&o.addEventListener("click",async()=>{const s=prompt("誤検知の理由を入力してください:","対象環境における仕様上不要")||"誤検知";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:r?.url,status:"false-positive",reason:s,createdAt:new Date().toISOString()}}),l.classList.add("hidden"),m()});const d=document.getElementById("modalRevokeExceptionBtn");d&&(e.exceptionId||e.findingId)&&d.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:e.exceptionId||e.findingId}),l.classList.add("hidden"),m()}),l.classList.remove("hidden")}function G(e){y.textContent=`Cookie: ${e.name}`,$.innerHTML=`
    <div>
      <div class="detail-section-title">属性詳細 (※値は除外)</div>
      <div>ドメイン: <strong>${n(e.domain)}</strong></div>
      <div>パス: <strong>${n(e.path)}</strong></div>
      <div>Secure: <strong>${e.secure?"有効":"無効"}</strong></div>
      <div>HttpOnly: <strong>${e.httpOnly?"有効":"無効"}</strong></div>
      <div>SameSite: <strong>${n(e.sameSite)}</strong></div>
      <div>有効期間: <strong>${e.session?"セッションCookie":"永続Cookie"}</strong></div>
    </div>

    ${e.issues&&e.issues.length>0?`
      <div>
        <div class="detail-section-title" style="color:var(--warning-color);">検出された課題</div>
        <ul style="padding-left:16px;">
          ${e.issues.map(t=>`<li>${n(t)}</li>`).join("")}
        </ul>
      </div>
    `:'<div style="color:var(--success-color);">重大な属性設定の不備は検出されませんでした。</div>'}
  `,l.classList.remove("hidden")}function h(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF"}[e]||e}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
