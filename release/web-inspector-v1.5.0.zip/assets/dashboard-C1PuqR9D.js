import{d as Y,a as K}from"./json-B9bJ9Pcs.js";function X(e,t){const n=[],r=Z(e,t),i=new Map(e.technologies.map(o=>[o.technology,o])),v=new Map(t.technologies.map(o=>[o.technology,o]));for(const[o,u]of v)i.has(o)||n.push({id:`tech:add:${o}`,category:"technology",target:o,diffType:"Added",diffCause:r?"unknown":"site-change",causeExplanation:r?"調査範囲の違い、またはサイト側の技術追加による可能性があります。":`サイト側で ${o} (${u.version?`v${u.version}`:"バージョン不明"}) が新たに導入されました。`,before:null,after:u.version?`v${u.version}`:"検出"});for(const[o,u]of i)v.has(o)||n.push({id:`tech:rem:${o}`,category:"technology",target:o,diffType:"Removed",diffCause:r?"inspection-difference":"site-change",causeExplanation:r?"調査権限または取得対象範囲の違いにより検出されなかった可能性があります。":`サイト側で ${o} の使用が停止または別技術へ移行されました。`,before:u.version?`v${u.version}`:"検出",after:null});for(const[o,u]of v){const h=i.get(o);if(h)if(h.version!==u.version)n.push({id:`tech:ver:${o}`,category:"technology",target:o,diffType:"Changed",diffCause:"site-change",causeExplanation:`サイト側でバージョンが ${h.version||"不明"} から ${u.version||"不明"} へ更新されました。`,before:h.version||"不明",after:u.version||"不明"});else{const x=h.advisories?.length??0,C=u.advisories?.length??0;if(x!==C){const W=C>x;n.push({id:`advisory:${o}`,category:"security",target:`${o} 既知脆弱性情報`,diffType:W?"Regressed":"Resolved",diffCause:"advisory-update",causeExplanation:`サイトのバージョンは不変ですが、オフライン脆弱性DBの更新により該当アドバイザリが ${x}件 から ${C}件 へ変化しました。`,before:`${x} 件`,after:`${C} 件`})}}}const d=new Map(e.securityChecks.map(o=>[o.checkId||o.name,o])),c=new Map(t.securityChecks.map(o=>[o.checkId||o.name,o]));for(const[o,u]of c){const h=d.get(o);if(!h)continue;const x=h.status==="warning"||h.status==="fail",C=u.status==="warning"||u.status==="fail";!x&&C?n.push({id:`sec:reg:${o}`,category:"security",target:u.name,diffType:"Regressed",diffCause:r?"unknown":"site-change",causeExplanation:r?"調査範囲の違い、またはサイト設定の変更により警告が検出されました。":"サイトの設定変更またはヘッダーの変更により、新たに指摘項目が発生しました。",before:h.observed,after:u.observed}):x&&!C&&n.push({id:`sec:res:${o}`,category:"security",target:u.name,diffType:"Resolved",diffCause:"site-change",causeExplanation:"セキュリティヘッダーまたは属性設定が修正され、問題が解消されました。",before:h.observed,after:u.observed})}let l=0,f=0,y=0,s=0,g=0;const $={"site-change":0,"advisory-update":0,"rule-update":0,"inspection-difference":0,unknown:0};for(const o of n)o.diffType==="Added"?l++:o.diffType==="Removed"?f++:o.diffType==="Changed"?y++:o.diffType==="Resolved"?s++:o.diffType==="Regressed"&&g++,$[o.diffCause]=($[o.diffCause]||0)+1;const T=new Set(e.technologies.map(o=>o.technology)),L=new Set(t.technologies.map(o=>o.technology)),S=Array.from(L).filter(o=>!T.has(o)),J=Array.from(T).filter(o=>!L.has(o)),M=[];for(const o of t.technologies){const u=i.get(o.technology);u&&u.version!==o.version&&M.push({technology:o.technology,before:u.version,after:o.version})}const A=new Set(e.securityChecks.filter(o=>o.status==="warning"||o.status==="fail").map(o=>o.name)),P=new Set(t.securityChecks.filter(o=>o.status==="warning"||o.status==="fail").map(o=>o.name)),q=Array.from(P).filter(o=>!A.has(o)),G=Array.from(A).filter(o=>!P.has(o));return{reportA:e,reportB:t,diffItems:n,summary:{addedCount:l,removedCount:f,changedCount:y,resolvedCount:s,regressedCount:g,causes:$},addedTechnologies:S,removedTechnologies:J,versionChanges:M,newSecurityIssues:q,resolvedSecurityIssues:G}}function Z(e,t){return e.coverage?.completeness!==t.coverage?.completeness||e.coverage?.sources?.dom!==t.coverage?.sources?.dom}function Q(e){try{const t=new URL(e),n=["token","key","auth","secret","password","passwd","sig","signature","access_token","api_key"];for(const r of Array.from(t.searchParams.keys()))n.some(i=>r.toLowerCase().includes(i))&&t.searchParams.set(r,"***MASKED***");return t.username="",t.password="",t.toString()}catch{return e}}function p(e){return e?e.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/\*/g,"\\*").replace(/_/g,"\\_").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/</g,"&lt;").replace(/>/g,"&gt;"):""}function ee(e,t,n=[]){const r=Q(e.url),i=e.hostname,v=new Date(e.inspectedAt).toLocaleString("ja-JP",{timeZone:"Asia/Tokyo"}),d=e.extensionVersion||"1.3.3",c=[];c.push(`# Web Technology & Security Inspection Report

**対象ホスト:** \`${i}\`  
**調査実施日時:** ${v} (JST)  
**Inspector バージョン:** v${d} (Manifest V3)  
**解析方式:** 受動的解析 (Passive Inspection) / 完全ローカル突合  

---`),c.push(`## 1. 調査概要

| 項目 | 内容 |
|---|---|
| 対象URL | \`${r}\` |
| ホスト名 | \`${i}\` |
| プロトコル | ${e.summary.isHttps?"HTTPS (暗号化通信)":"HTTP (非暗号化)"} |
| 診断ルールバージョン | ${p(e.rulesVersion)} |
| オフライン脆弱性DBバージョン | ${p(e.advisoryDatabaseVersion||"2026.10")} |
| 要確認項目数 | **${e.summary.requiresAttentionCount} 件** |
| 検出技術スタック数 | **${e.summary.totalTechnologies} 件** |
`);const l=e.coverage,f=l?.completeness==="complete"?"完全 (Complete)":l?.completeness==="partial"?"一部制限あり (Partial)":"未取得 (Failed)";c.push(`## 2. 調査範囲・完全性 (Coverage)

- **完全性ステータス:** **${f}** (調査スコア: ${l?.score??100} / 100)
- **DOM / HTML解析:** ${l?.sources?.dom?"✅ 取得成功":"⚠️ 未取得"}
- **HTTPレスポンスヘッダー:** ${l?.sources?.responseHeaders?"✅ 取得成功":"⚠️ 未取得 (キャッシュ/事前スキャンなし)"}
- **Cookie属性情報:** ${l?.sources?.cookies?`✅ 取得成功 (${e.cookies.length} 個観測)`:"⚠️ 権限なし/未取得"}
- **JavaScript実行時情報 (MAIN World):** ${l?.sources?.runtime?"✅ 取得成功":"⚠️ 未取得"}
${l?.unobservedSignals&&l.unobservedSignals.length>0?`
> [!NOTE]
> **未観測・制限項目:** ${l.unobservedSignals.map(s=>`\`${s}\``).join(", ")}
`:""}
`),c.push(`## 3. 調査結果サマリー

### セキュリティ指摘レベル内訳
| 重大度 | 指摘件数 | 説明 |
|:---:|:---:|---|
| **HIGH (危険)** | **${e.summary.securityFindings.high}** | 直ちに対応・修正が推奨される設定不備・脆弱性 |
| **MEDIUM (警告)** | **${e.summary.securityFindings.medium}** | セキュリティ基準に抵触、またはサポート終了の技術 |
| **LOW (注意)** | **${e.summary.securityFindings.low}** | 改善が望ましい設定上の軽微な不備 |
| **INFO (情報)** | **${e.summary.securityFindings.info}** | 参考情報・セキュリティ良好な項目 |
`),c.push(`## 4. 検出技術スタック

| 技術名 | カテゴリ | バージョン | 取得元 | 確信度 | 整合性 |
|---|---|:---:|:---:|:---:|:---:|
${e.technologies.length>0?e.technologies.map(s=>{const g=s.version?`v${s.version}`:"不明",$=s.versionIntegrity?.status==="mismatch"?"⚠️ 不一致":s.versionIntegrity?.status==="match"?"一致":"-";return`| **${p(s.technology)}** | ${p(s.category)} | \`${p(g)}\` | ${p(s.versionSource||"-")} | ${s.confidenceLevel} (${s.confidence}%) | ${$} |`}).join(`
`):"| なし | - | - | - | - | - |"}
`),c.push(`## 5. セキュリティ診断結果

| 診断項目 | ステータス | 重大度 | 観測値 | 許容状態 |
|---|:---:|:---:|---|:---:|
${e.securityChecks.length>0?e.securityChecks.map(s=>{const g=s.status==="pass"?"PASS":s.status==="fail"?"**FAIL**":"**WARN**",$=s.exceptionStatus==="accepted"?"🛡️ 許容済":s.exceptionStatus==="false-positive"?"❌ 誤検知除外":"-";return`| ${p(s.name)} | ${g} | ${s.severity.toUpperCase()} | \`${p(s.observed.substring(0,60))}\` | ${$} |`}).join(`
`):"| なし | - | - | - | - |"}
`),c.push(`## 6. EOL・既知脆弱性情報 (ライブラリセキュリティ)

> [!IMPORTANT]
> オフライン脆弱性DBスナップショット (Rev.2.1) とのローカル突合結果です。未登録の技術は「安全」を意味するものではありません。

| 対象技術 | バージョン | サポート状況 (EOL) | 照合ステータス | 該当CVE | 推奨対応 |
|---|:---:|:---:|:---:|---|---|
${e.technologies.map(s=>{const g=s.supportStatus==="EOL"?`**EOL (${s.eolDate||"終了"})**`:s.supportStatus||"Unknown",$=s.offlineMatchStatus||"Not Covered",T=s.advisories&&s.advisories.length>0?s.advisories.map(S=>`[${S.id}](https://nvd.nist.gov/vuln/detail/${S.id}) (${S.severity})`).join(", "):"該当なし",L=s.advisories&&s.advisories.length>0?`修正版 (v${s.advisories[0].fixedVersion||"最新"}) への更新`:s.supportStatus==="EOL"?"最新LTS系列への移行":"現状維持";return`| **${p(s.technology)}** | \`${p(s.version||"不明")}\` | ${g} | \`${$}\` | ${T} | ${L} |`}).join(`
`)}
`),c.push(`## 7. Cookie属性診断

※ **セキュリティ保護:** Cookieの値（Value）および認証シークレットは一切収集・出力していません。

| Cookie名 | ドメイン | パス | 用途分類 | Secure | HttpOnly | SameSite | CHIPS (Partitioned) |
|---|---|---|:---:|:---:|:---:|:---:|:---:|
${e.cookies.length>0?e.cookies.map(s=>`| \`${p(s.name)}\` | \`${p(s.domain)}\` | \`${p(s.path)}\` | ${p(s.purposeCategory||"general")} | ${s.secure?"Yes":"**No**"} | ${s.httpOnly?"Yes":"**No**"} | \`${s.sameSite}\` | ${s.partitioned?"Yes":"No"} |`).join(`
`):"| なし | - | - | - | - | - | - | - |"}
`),c.push(`## 8. CSP（Content Security Policy）診断

- **CSPポリシー保持件数:** ${e.cspPolicies?.length??0} 件
${e.cspPolicies&&e.cspPolicies.length>0?e.cspPolicies.map((s,g)=>`
#### ポリシー #${g+1} [取得元: ${s.source}, モード: ${s.disposition}]
\`\`\`text
${s.rawPolicy}
\`\`\`
`).join(`
`):"> CSPヘッダーまたはmetaタグによるCSPは設定されていません。"}
`);const y=e.externalConnections;return c.push(`## 9. 外部通信先・サードパーティ分析 (Public Suffix List / eTLD+1)

- **総通信先ホスト数:** ${y?.totalConnections??0} 件
- **First-Party (同一組織・自社ドメイン):** ${y?.firstPartyCount??0} 件
- **Third-Party (外部サービス通信先):** ${y?.thirdPartyCount??0} 件

| 接続先ホスト名 | 登録可能ドメイン (eTLD+1) | 所属種別 | 推定カテゴリ | 観測リソース数 |
|---|---|:---:|:---:|:---:|
${y&&y.connections.length>0?y.connections.map(s=>{const g=s.partyType==="first-party"?"First-Party":s.partyType==="third-party"?"**Third-Party**":"Local";return`| \`${p(s.hostname)}\` | \`${p(s.registrableDomain)}\` | ${g} | \`${s.category}\` | ${s.resourceCount} |`}).join(`
`):"| 外部通信先は観測されませんでした | - | - | - | - |"}
`),c.push(`## 10. 前回調査との差分 (Diff)

> 前回調査レポートとの比較は実行されていません（初回調査または単一レポート出力）。
`),c.push(`## 11. 差分発生原因の推定分析

> 分析対象の有意な差分変化はありません。
`),c.push(`## 12. 診断項目の許容・除外設定 (Finding Exceptions)

${n.length>0?`
| 状態 | 対象安定ID (FindingId) | 適用スコープ | 許容理由 | 登録日 |
|:---:|---|---|---|:---:|
${n.map(s=>`| **${s.status==="accepted"?"リスク許容":s.status==="false-positive"?"誤検知":"通知抑制"}** | \`${p(s.findingId)}\` | \`${p(s.targetUrl||"全体適用")}\` | ${p(s.reason)} | ${s.createdAt?s.createdAt.slice(0,10):"-"} |`).join(`
`)}
`:"> 現在適用されている許容・除外設定はありません。"}
`),c.push("## 13. 推奨対応ロードマップ\n\n1. **至急対応 (High Severity):**\n   - 既知脆弱性（CVE）が特定されたライブラリを修正済みバージョン以降へ更新する。\n   - 暗号化通信（HTTPS）および混在コンテンツ（Mixed Content）の解消。\n2. **計画的対応 (Medium Severity):**\n   - サポート終了（EOL）を迎えたミドルウェア・ライブラリの次世代LTS系列への移行計画策定。\n   - セッションCookieに対する `Secure`、`HttpOnly`、適切な `SameSite` 属性の付与。\n   - Content-Security-Policy (CSP) の導入および `unsafe-inline` の排除。\n3. **継続的改善 (Low / Best Practices):**\n   - HSTS (`Strict-Transport-Security`) ヘッダーの `max-age=31536000; includeSubDomains` 適用。\n   - 外部サードパーティスクリプトの棚卸しと整合性検証 (SRI) の導入。\n"),c.push(`## 14. 検出根拠 (エビデンス詳細)

${e.technologies.map(s=>`
### ${s.technology} (確信度: ${s.confidenceLevel} - ${s.confidence}%)
${s.evidence.map(g=>`- **[${g.type}]** \`${p(g.name)}\`: \`${p(g.value)}\` ${g.detail?`(${p(g.detail)})`:""}`).join(`
`)}
`).join(`
`)}
`),c.push(`## 15. 調査上の制限事項・免責事項

1. **受動的解析のスコープ:**
   本拡張機能は、ブラウザが通常のWeb閲覧時に受信したHTML、CSS、JavaScript、HTTPヘッダー、Cookie属性のみを受動的に解析（Passive Inspection）しています。外部サーバーへの攻撃的なリクエスト送信や内部ソースコードの監査は行っていません。
2. **脆弱性DBの網羅性:**
   オフライン脆弱性DBに未収録のライブラリや独自フレームワークについて「脆弱性なし」と判定されていても、安全性を完全に保証するものではありません。
3. **認証後ページの扱い:**
   ログインや特定セッションを必要とする深層ページは、閲覧した範囲に限定して診断されます。
4. **機密情報の非保持:**
   Cookieの値、認証トークン、Authorizationヘッダーなどのシークレット情報はメモリ保持およびレポート出力から完全に除外されています。
`),c.join(`

`)}function te(e,t,n=[]){const r=ee(e,t,n),i=new Blob([r],{type:"text/markdown;charset=utf-8"}),v=URL.createObjectURL(i),d=e.hostname.replace(/[^a-zA-Z0-9.-]/g,"_"),c=new Date(e.inspectedAt).toISOString().slice(0,10),l=`web-inspector-report-${d}-${c}.md`;if(typeof chrome<"u"&&chrome.downloads)chrome.downloads.download({url:v,filename:l,saveAs:!0});else{const f=document.createElement("a");f.href=v,f.download=l,document.body.appendChild(f),f.click(),document.body.removeChild(f),URL.revokeObjectURL(v)}}let m=null,b=[];const ne=document.getElementById("currentHostname"),se=document.getElementById("inspectedAtTime"),H=document.getElementById("dashAdvisoryDbDate"),oe=document.getElementById("dashTotalTechs"),ae=document.getElementById("dashAttentionCount"),ie=document.getElementById("dashEolCount"),re=document.getElementById("dashVulnCount"),de=document.getElementById("dashHttpsStatus"),ce=document.getElementById("dashMixedStatus"),D=document.getElementById("overviewLibrarySecList"),R=document.getElementById("overviewSecurityList"),j=document.getElementById("librarySecurityTableContainer"),O=document.getElementById("fullTechsContainer"),le=document.getElementById("fullSecurityContainer"),V=document.getElementById("cookiesTableBody"),U=document.getElementById("historyListContainer"),w=document.getElementById("exceptionsTableContainer"),k=document.getElementById("compareSelectA"),B=document.getElementById("compareSelectB"),ue=document.getElementById("executeCompareBtn"),pe=document.getElementById("compareResultContainer"),I=document.getElementById("domainsContainer"),ge=document.getElementById("themeToggleBtn"),z=document.getElementById("exportMdBtn"),ve=document.getElementById("exportJsonBtn"),me=document.getElementById("exportCsvBtn"),he=document.getElementById("refreshBtn"),fe=document.getElementById("clearHistoryBtn");document.addEventListener("DOMContentLoaded",async()=>{$e(),ye(),xe(),Ce(),await E()});function ye(){const e=document.getElementById("dashboardVersion");if(e){const t=chrome.runtime?.getManifest?.()?.version||"1.5.0";e.textContent=`v${t}`}}function $e(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function be(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function xe(){document.querySelectorAll(".nav-item").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active")),document.querySelectorAll(".view-panel").forEach(n=>n.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-view");t&&(document.getElementById(t)?.classList.add("active"),t==="exceptionsView"?N():t==="domainsView"&&F(m?.externalConnections))})})}function Ce(){ge.addEventListener("click",be),he.addEventListener("click",E),z&&z.addEventListener("click",()=>{m&&te(m)}),ve.addEventListener("click",()=>{m&&Y(m)}),me.addEventListener("click",()=>{m&&K(m)}),fe.addEventListener("click",async()=>{confirm("すべての調査履歴を完全に削除しますか？")&&(await chrome.runtime.sendMessage({type:"CLEAR_HISTORY"}),await E())}),ue.addEventListener("click",Me)}async function E(){try{const e=await chrome.runtime.sendMessage({type:"GET_ALL_REPORTS"});if(e&&e.success&&e.reports.length>0)b=e.reports,m=b[0];else{const t=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});t&&t.success&&(m=t.report,b=[m])}m&&(_(m),Be(b),ke(b))}catch(e){console.error("Failed to load dashboard data:",e)}}function _(e){ne.textContent=e.hostname,se.textContent=`調査日時: ${new Date(e.inspectedAt).toLocaleString("ja-JP")}`,H&&(H.textContent=`🛡️ 脆弱性DB: ${e.advisoryDatabaseVersion||"2026-10-23"}`),oe.textContent=String(e.technologies.length),ae.textContent=String(e.summary.requiresAttentionCount);const t=e.summary.librarySecurity?.eolCount??0,n=e.summary.librarySecurity?.vulnerableLibraryCount??0;ie.textContent=String(t),re.textContent=`既知脆弱性: ${n}件 / 不一致: ${e.summary.librarySecurity?.mismatchCount??0}件`,de.textContent=e.summary.isHttps?"HTTPS (暗号化)":"HTTP (非暗号化)",ce.textContent=`混在コンテンツ: ${e.summary.mixedContentCount}件`,Se(e.technologies),Ee(e.securityChecks),Te(e.technologies),Le(e.technologies),we(e.securityChecks),Ie(e.cookies),F(e.externalConnections)}function Se(e){const t=e.filter(n=>n.supportStatus==="EOL"||n.advisories&&n.advisories.length>0||n.versionIntegrity?.status==="mismatch");if(t.length===0){D.innerHTML='<div style="color:var(--success-color);padding:12px 0;">ライブラリのサポート終了や既知脆弱性は検出されませんでした。</div>';return}D.innerHTML=t.map(n=>{let r=[];return n.supportStatus==="EOL"&&r.push(`EOL (${n.eolDate||"サポート終了"})`),n.advisories&&n.advisories.length>0&&r.push(`CVE ${n.advisories.length}件`),n.versionIntegrity?.status==="mismatch"&&r.push("CSS/JS不一致"),`
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border-color);">
          <div>
            <strong>${a(n.technology)}</strong>
            <span style="color:var(--text-muted);font-size:12px;margin-left:6px;">${n.version?`v${a(n.version)}`:""}</span>
            <div style="font-size:11px;color:var(--text-sub);">${a(r.join(" / "))}</div>
          </div>
          <span class="badge ${n.supportStatus==="EOL"?"badge-eol":"badge-cve"}">要確認</span>
        </div>
      `}).join("")}function Ee(e){const t=e.filter(n=>n.status==="warning"||n.status==="fail");if(t.length===0){R.innerHTML='<div style="color:var(--success-color);padding:12px 0;">重大なセキュリティ設定不備は検出されませんでした。</div>';return}R.innerHTML=t.slice(0,5).map(n=>`
    <div style="padding:8px 0;border-bottom:1px solid var(--border-color);">
      <div style="display:flex;justify-content:space-between;">
        <strong>${a(n.name)}</strong>
        <span class="badge ${n.severity==="high"?"sev-high":"sev-medium"}">${n.severity.toUpperCase()}</span>
      </div>
      <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">${a(n.description)}</div>
    </div>
  `).join("")}function Te(e){if(e.length===0){j.innerHTML='<div class="empty-state">技術情報がありません</div>';return}const t=e.map(n=>{const r=n.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':n.supportStatus==="Maintenance"?'<span class="badge badge-medium">保守</span>':n.supportStatus==="Supported"?'<span class="badge badge-high">Supported</span>':'<span class="badge" style="background:var(--bg-hover);">Unknown</span>';let i='<span class="badge sev-pass">該当なし</span>';n.offlineMatchStatus==="Matched"||n.advisories&&n.advisories.length>0?i=`<span class="badge badge-cve">該当 ${n.advisories?.length??0}件 (CVSS ${n.maxCvss||"6.1"})</span>`:n.offlineMatchStatus==="Not Covered"?i='<span style="color:var(--text-muted);font-size:11px;">未登録</span>':n.offlineMatchStatus==="Unknown Version"&&(i='<span class="badge badge-medium">要確認</span>'),n.isStale&&(i+=' <span style="font-size:10px;color:var(--warning-color);">[DB古]</span>');const v=n.versionIntegrity?n.versionIntegrity.status==="match"?'<span class="badge badge-high">一致</span>':n.versionIntegrity.status==="mismatch"?'<span class="badge badge-medium">不一致</span>':'<span style="color:var(--text-muted);font-size:11px;">判定不能</span>':'<span style="color:var(--text-muted);font-size:11px;">-</span>';let d="現状維持";return n.advisories&&n.advisories.length>0?d=`脆弱性修正版（v${n.advisories[0].fixedVersion||"最新"}以上）への更新推奨`:n.supportStatus==="EOL"?d="EOLのため最新LTS系列への移行推奨":n.offlineMatchStatus==="Unknown Version"&&n.version&&(d="パッケージ固有版のため個別セキュリティ情報の確認を推奨"),`
        <tr>
          <td><strong>${a(n.technology)}</strong></td>
          <td>${n.version?`v${a(n.version)}`:'<span style="color:var(--text-muted);">不明</span>'}</td>
          <td>${a(n.versionSource||"-")}</td>
          <td>${v}</td>
          <td>${r} ${n.eolDate?`<span style="font-size:11px;color:var(--text-muted);">(${n.eolDate})</span>`:""}</td>
          <td>${i}</td>
          <td style="font-size:12px;color:var(--accent-color);">${a(d)}</td>
        </tr>
      `}).join("");j.innerHTML=`
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>技術・ライブラリ名</th>
            <th>代表バージョン</th>
            <th>取得元</th>
            <th>CSS/JS整合性</th>
            <th>サポート状態 (EOL)</th>
            <th>既知脆弱性 (CVE)</th>
            <th>推奨対応</th>
          </tr>
        </thead>
        <tbody>
          ${t}
        </tbody>
      </table>
    </div>
  `}function Le(e){if(e.length===0){O.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}O.innerHTML=e.map(t=>`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:15px;">${a(t.technology)}</span>
          ${t.version?`<span class="badge" style="background:var(--bg-hover);">v${a(t.version)}</span>`:'<span style="font-size:11px;color:var(--text-muted);">バージョン不明</span>'}
          <span style="font-size:12px;color:var(--text-muted);">${a(t.category)}</span>
        </div>
        <div style="display:flex;gap:6px;">
          ${t.supportStatus==="EOL"?'<span class="badge badge-eol">EOL</span>':""}
          ${t.advisories&&t.advisories.length>0?`<span class="badge badge-cve">CVE ${t.advisories.length}件</span>`:""}
          <span class="badge ${t.confidenceLevel==="high"?"badge-high":"badge-medium"}">確信度 ${t.confidence}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div>${a(t.description||"")}</div>
        ${t.website?`<div>公式サイト: <a href="${t.website}" target="_blank" style="color:var(--accent-color);">${t.website}</a></div>`:""}
        
        ${t.versionIntegrity?`
          <div style="margin-top:8px;padding:8px;border:1px solid var(--border-color);border-radius:4px;background:var(--bg-surface);">
            <strong>CSS / JS バージョン整合性:</strong>
            <div>JavaScript: ${a(t.versionIntegrity.jsVersion||"未検出")} / CSS: ${a(t.versionIntegrity.cssVersion||"未検出")}</div>
            <div style="color:${t.versionIntegrity.status==="match"?"var(--success-color)":"var(--warning-color)"};">${a(t.versionIntegrity.detail)}</div>
          </div>
        `:""}

        ${t.advisories&&t.advisories.length>0?`
          <div style="margin-top:8px;">
            <strong style="color:var(--danger-color);">該当する既知脆弱性 (CVE / GHSA):</strong>
            <ul style="padding-left:18px;margin-top:4px;">
              ${t.advisories.map(n=>`
                <li style="margin-bottom:6px;">
                  <strong>${a(n.id)}</strong> (${n.title}) - 影響範囲: <code>${a(n.affectedRange)}</code>
                  ${n.fixedVersion?`<span style="color:var(--success-color);margin-left:6px;">修正版: v${a(n.fixedVersion)}</span>`:""}
                </li>
              `).join("")}
            </ul>
          </div>
        `:""}

        <div style="font-weight:700;margin-top:8px;">判定根拠 (Evidence):</div>
        <ul style="padding-left:18px;">
          ${t.evidence.map(n=>`
            <li>
              <strong>[${n.type}] ${a(n.name)}:</strong>
              <code>${a(n.value)}</code>
              ${n.detail?`<span style="color:var(--text-muted);margin-left:6px;">(${a(n.detail)})</span>`:""}
            </li>
          `).join("")}
        </ul>
      </div>
    </div>
  `).join("")}function we(e){le.innerHTML=e.map(t=>{const r=t.exceptionStatus==="accepted"||t.exceptionStatus==="false-positive"||t.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:6px;">許容済</span>':"";return`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:14px;">${a(t.name)}</span>
          <span style="font-size:11px;color:var(--text-muted);">${a(t.checkId)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${r}
          <span class="badge ${t.status==="pass"?"sev-pass":t.severity==="high"?"sev-high":"sev-medium"}">${t.status==="pass"?"PASS":t.severity.toUpperCase()}</span>
        </div>
      </div>
      <div class="accordion-body">
        <div><strong>観測値:</strong> <code>${a(t.observed)}</code></div>
        <div><strong>セキュリティ上の影響:</strong> ${a(t.description)}</div>
        <div style="color:var(--accent-color);"><strong>推奨対応:</strong> ${a(t.recommendation)}</div>
        ${t.exceptionReason?`<div style="background:rgba(59,130,246,0.1);padding:6px 10px;border-radius:4px;margin-top:6px;font-size:12px;color:var(--accent-color);"><strong>許容理由:</strong> ${a(t.exceptionReason)}</div>`:""}
        ${t.referenceUrls.length>0?`
          <div><strong>参考資料:</strong>
            ${t.referenceUrls.map(i=>`<a href="${i}" target="_blank" style="color:var(--accent-color);margin-left:8px;">${i}</a>`).join(", ")}
          </div>
        `:""}
      </div>
    </div>
  `}).join("")}function Ie(e){if(!e||e.length===0){V.innerHTML='<tr><td colspan="8" class="empty-state">Cookieは検出されませんでした</td></tr>';return}V.innerHTML=e.map(t=>`
    <tr>
      <td><strong>${a(t.name)}</strong></td>
      <td>${a(t.domain)}</td>
      <td>${a(t.path)}</td>
      <td>${t.secure?"✅":"❌"}</td>
      <td>${t.httpOnly?"✅":"❌"}</td>
      <td>${a(t.sameSite)}</td>
      <td>${t.session?"セッション":"永続"}</td>
      <td style="color:${t.issues.length>0?"var(--warning-color)":"var(--text-muted)"};">${t.issues.length>0?a(t.issues.join(", ")):"なし"}</td>
    </tr>
  `).join("")}function ke(e){if(e.length===0){U.innerHTML='<div class="empty-state">保存された履歴はありません</div>';return}U.innerHTML=e.map(t=>`
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;border:1px solid var(--border-color);border-radius:var(--radius-sm);margin-bottom:8px;background:var(--bg-surface);">
      <div>
        <strong>${a(t.hostname)}</strong>
        <span style="font-size:12px;color:var(--text-muted);margin-left:8px;">${new Date(t.inspectedAt).toLocaleString("ja-JP")}</span>
        <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">
          技術: ${t.technologies.length}件 / 要確認: ${t.summary.requiresAttentionCount}件 / EOL: ${t.summary.librarySecurity?.eolCount??0}件 / ${t.summary.isHttps?"HTTPS":"HTTP"}
        </div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-secondary btn-sm" onclick="window.viewReport('${t.id}')">表示</button>
        <button class="btn btn-danger btn-sm" onclick="window.deleteReport('${t.id}')">削除</button>
      </div>
    </div>
  `).join("")}window.viewReport=e=>{const t=b.find(n=>n.id===e);t&&(m=t,_(t),document.querySelector('.nav-item[data-view="overviewView"]')?.dispatchEvent(new Event("click")))};window.deleteReport=async e=>{confirm("この調査レポートを削除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_HISTORY_ITEM",id:e}),await E())};function Be(e){k.innerHTML="",B.innerHTML="",e.forEach((t,n)=>{const r=document.createElement("option");r.value=t.id,r.textContent=`${t.hostname} (${new Date(t.inspectedAt).toLocaleString("ja-JP")})`,k.appendChild(r);const i=document.createElement("option");i.value=t.id,i.textContent=`${t.hostname} (${new Date(t.inspectedAt).toLocaleString("ja-JP")})`,(n===1||n===0&&e.length===1)&&(i.selected=!0),B.appendChild(i)})}function Me(){const e=k.value,t=B.value,n=b.find(d=>d.id===e),r=b.find(d=>d.id===t);if(!n||!r)return;const i=X(n,r),v=Object.entries(i.summary.causes).filter(([d,c])=>c>0).map(([d,c])=>{let l=d;return d==="site-change"?l="Site Change (サイト側変更)":d==="advisory-update"?l="Advisory Update (脆弱性DB更新)":d==="inspection-difference"?l="Inspection Diff (調査権限差)":d==="rule-update"?l="Rule Update (診断ルール更新)":d==="unknown"&&(l="Unknown (複数/不明)"),`<span class="badge badge-medium" style="margin-right:6px;display:inline-block;margin-top:4px;">${a(l)}: ${c}件</span>`}).join("");pe.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">差分分析サマリー (Rev.2.1 IMP-09)</div>
      <div style="margin-bottom:8px;">
        検出された変化: <strong>${i.diffItems.length} 件</strong>
        (新規: ${i.summary.addedCount}, 消失: ${i.summary.removedCount}, 変更: ${i.summary.changedCount}, 解消: ${i.summary.resolvedCount}, 新規警告: ${i.summary.regressedCount})
      </div>
      <div>推定要因: ${v||'<span style="color:var(--text-muted);">差分なし</span>'}</div>
    </div>

    <div class="diff-box">
      <div class="diff-title">詳細な変化と原因分析</div>
      ${i.diffItems.length===0?'<div style="color:var(--text-muted);padding:8px 0;">2つの調査結果に変化はありませんでした。</div>':`
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>種別</th>
                <th>対象</th>
                <th>推定原因</th>
                <th>Before &rarr; After</th>
                <th>解説</th>
              </tr>
            </thead>
            <tbody>
              ${i.diffItems.map(d=>{let c="badge-medium";return(d.diffType==="Resolved"||d.diffType==="Added")&&(c="badge-high"),d.diffType==="Regressed"&&(c="badge-eol"),`
                    <tr>
                      <td><span class="badge ${c}">${d.diffType}</span></td>
                      <td><strong>${a(d.target)}</strong></td>
                      <td><span class="badge" style="background:var(--bg-hover);">${a(d.diffCause)}</span></td>
                      <td>${a(d.before||"-")} &rarr; <strong>${a(d.after||"-")}</strong></td>
                      <td style="font-size:12px;color:var(--text-sub);">${a(d.causeExplanation)}</td>
                    </tr>
                  `}).join("")}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `}async function N(){if(w)try{const t=(await chrome.runtime.sendMessage({type:"GET_FINDING_EXCEPTIONS"}))?.exceptions||[];if(t.length===0){w.innerHTML='<div class="empty-state">登録されている許容・除外設定はありません。</div>';return}w.innerHTML=`
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>状態</th>
              <th>対象安定ID (FindingId)</th>
              <th>対象URL</th>
              <th>許容理由</th>
              <th>登録日</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            ${t.map(n=>`
              <tr>
                <td><span class="badge ${n.status==="accepted"?"badge-high":"badge-medium"}">${n.status==="accepted"?"リスク許容":n.status==="false-positive"?"誤検知":"通知抑制"}</span></td>
                <td><code>${a(n.findingId)}</code></td>
                <td>${a(n.targetUrl||"全体適用")}</td>
                <td>${a(n.reason)}</td>
                <td>${n.createdAt?new Date(n.createdAt).toLocaleString("ja-JP"):"-"}</td>
                <td><button class="btn btn-secondary revoke-ex-btn" data-id="${a(n.id)}" style="font-size:11px;padding:3px 8px;">解除</button></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `,document.querySelectorAll(".revoke-ex-btn").forEach(n=>{n.addEventListener("click",async r=>{const i=r.currentTarget.getAttribute("data-id");i&&confirm("この許容設定を解除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:i}),await N(),await E())})})}catch(e){w.innerHTML=`<div class="empty-state" style="color:var(--danger-color);">許容設定の取得に失敗しました: ${e}</div>`}}function F(e){if(!I)return;if(!e||!e.connections||e.connections.length===0){I.innerHTML='<div class="empty-state">外部通信先情報はまだ解析されていません。</div>';return}const t={cdn:"CDN・静的配信",analytics:"アクセス解析",advertising:"広告・マーケティング",fonts:"Webフォント",social:"SNSウィジェット",api:"外部API",other:"その他"},n=Object.entries(e.categoryBreakdown).filter(([r,i])=>i>0).map(([r,i])=>`<span class="badge badge-medium" style="margin-right:6px;display:inline-block;margin-top:4px;">${a(t[r]||r)}: ${i}件</span>`).join("");I.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">通信先ドメイン集計 (eTLD+1 / Public Suffix List 判定)</div>
      <div style="margin-bottom:8px;">
        検出ホスト数: <strong>${e.totalConnections} 件</strong>
        (自社/First-Party: <strong>${e.firstPartyCount}</strong>, 外部/Third-Party: <strong>${e.thirdPartyCount}</strong>)
      </div>
      <div>推定用途別内訳: ${n||'<span style="color:var(--text-muted);">-</span>'}</div>
    </div>

    <div class="diff-box">
      <div class="diff-title">通信先ホスト一覧</div>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>ホスト名</th>
              <th>eTLD+1 (組織ドメイン)</th>
              <th>分類</th>
              <th>用途カテゴリ</th>
              <th>リソース数</th>
              <th>サンプルURL</th>
            </tr>
          </thead>
          <tbody>
            ${e.connections.map(r=>{let i="badge-medium",v="Third-Party";r.partyType==="first-party"?(i="badge-high",v="First-Party (自社)"):r.partyType==="local"?(i="badge-low",v="Local (内部)"):(i="badge-medium",v="Third-Party (外部)");const d=r.sampleUrls.length>0?r.sampleUrls[0]:"";return`
                  <tr>
                    <td><strong>${a(r.hostname)}</strong></td>
                    <td><code>${a(r.registrableDomain||"-")}</code></td>
                    <td><span class="badge ${i}">${v}</span></td>
                    <td><span class="badge" style="background:var(--bg-hover);">${a(t[r.category]||r.category)}</span></td>
                    <td>${r.resourceCount}</td>
                    <td style="font-size:11px;color:var(--text-sub);max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${a(d)}">${a(d||"-")}</td>
                  </tr>
                `}).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `}function a(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
