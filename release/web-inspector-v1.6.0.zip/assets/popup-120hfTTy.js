import{d as I,a as w}from"./json-Dmi7KCmo.js";let c=null;const y=document.getElementById("siteHostname"),p=document.getElementById("statusIndicator"),T=document.getElementById("techCount"),M=document.getElementById("attentionCount"),C=document.getElementById("eolCount"),H=document.getElementById("tabTechCount"),k=document.getElementById("tabSecCount"),D=document.getElementById("tabCookieCount"),m=document.getElementById("techsList"),u=document.getElementById("securityList"),f=document.getElementById("cookiesList"),N=document.getElementById("rescanBtn"),_=document.getElementById("themeToggleBtn"),z=document.getElementById("openDashboardBtn"),A=document.getElementById("fullReportBtn"),F=document.getElementById("exportJsonBtn"),O=document.getElementById("exportCsvBtn"),l=document.getElementById("detailModal"),x=document.getElementById("modalTitle"),b=document.getElementById("modalBody"),U=document.getElementById("closeModalBtn");document.addEventListener("DOMContentLoaded",()=>{V(),G(),j(),g()});function G(){const e=document.getElementById("brandVersion");if(e){const t=chrome.runtime?.getManifest?.()?.version||"1.6.0";e.textContent=`v${t}`}}function V(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function R(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function j(){_.addEventListener("click",R),N.addEventListener("click",()=>g()),z.addEventListener("click",h),A.addEventListener("click",h),F.addEventListener("click",()=>{c&&I(c)}),O.addEventListener("click",()=>{c&&w(c)}),document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(i=>i.classList.remove("active")),document.querySelectorAll(".tab-pane").forEach(i=>i.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-tab");t&&document.getElementById(t)?.classList.add("active")})}),U.addEventListener("click",()=>{l.classList.add("hidden")}),l.addEventListener("click",e=>{e.target===l&&l.classList.add("hidden")})}function h(){const e=chrome.runtime.getURL("dashboard.html");chrome.tabs.create({url:e})}async function g(){p.className="status-indicator",y.textContent="調査中...",m.innerHTML='<div class="empty-state">技術情報を解析中...</div>',u.innerHTML='<div class="empty-state">セキュリティ設定を診断中...</div>',f.innerHTML='<div class="empty-state">Cookie属性を取得中...</div>';try{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});if(!e||!e.success)throw new Error(e?.error||"調査に失敗しました。");c=e.report,P(c)}catch(e){const t=e instanceof Error?e.message:String(e);y.textContent="調査エラー",p.className="status-indicator",p.style.backgroundColor="#EF4444",m.innerHTML=`<div class="empty-state" style="color: #EF4444;">${t}</div>`}}function P(e){p.className="status-indicator ready",y.textContent=e.hostname,T.textContent=String(e.technologies.length),M.textContent=String(e.summary.requiresAttentionCount);const t=(e.summary.librarySecurity?.eolCount??0)+(e.summary.librarySecurity?.vulnerableLibraryCount??0);C&&(C.textContent=String(t)),H.textContent=String(e.technologies.length),k.textContent=String(e.securityChecks.length),D.textContent=String(e.cookies.length),J(e.technologies),q(e.securityChecks),W(e.cookies);const i=document.getElementById("advisoryDbBar");if(i){const a=e.advisoryDatabaseVersion||"2026-10-23";i.textContent=`🛡️ 脆弱性DB更新日: ${a}`}}function J(e){if(e.length===0){m.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}m.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.confidenceLevel==="high"?"badge-high":t.confidenceLevel==="medium"?"badge-medium":"badge-low",o=t.confidenceLevel==="high"?"高":t.confidenceLevel==="medium"?"中":"低";let r="";t.isCandidateGroup||t.detectionMethod==="associated"?r='<span class="badge badge-associated">候補</span>':t.detectionMethod==="inferred"?r=`<span class="badge badge-inferred">連動${t.inferredFrom?` · ${s(t.inferredFrom)}`:""}</span>`:r='<span class="badge badge-direct">直接</span>';let d="";t.runtimeStatus==="unknown"?d='<span class="badge badge-runtime-unknown">稼働未確認</span>':t.runtimeStatus==="possible"&&(d='<span class="badge badge-runtime-possible">稼働可能性</span>');let n="";t.supportStatus==="EOL"?n='<span class="badge badge-eol">EOL</span>':t.supportStatus==="Maintenance"&&(n='<span class="badge badge-medium">保守</span>');let v="";t.advisories&&t.advisories.length>0&&(v=`<span class="badge badge-cve">CVE ${t.maxCvss?`CVSS ${t.maxCvss}`:`${t.advisories.length}件`}</span>`);let $="";t.versionIntegrity?.status==="mismatch"&&($='<span class="badge badge-mismatch">不一致</span>');let E=t.isCandidateGroup?"いずれかの可能性あり":t.version?`v${s(t.version)}`:"バージョン不明";t.versionSource==="runtime"&&(E+=" (実行時)");const S=t.isCandidateGroup?"？":t.technology.slice(0,2).toUpperCase(),B=t.isCandidateGroup?"言語・FW候補":L(t.category);i.innerHTML=`
      <div class="item-main">
        <div class="tech-icon-badge">${S}</div>
        <div class="item-texts">
          <div style="display:flex;align-items:center;gap:6px;">
            <span class="item-name">${s(t.technology)}</span>
            ${r}
            ${d}
          </div>
          <div class="item-meta">
            <span class="item-version-badge">${s(E)}</span>
            <span>${s(B)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        ${$}
        ${n}
        ${v}
        <span class="badge ${a}">${o} · ${t.confidence}</span>
      </div>
    `,i.addEventListener("click",()=>X(t)),m.appendChild(i)})}function q(e){if(e.length===0){u.innerHTML='<div class="empty-state">診断項目がありません</div>';return}u.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";let a="sev-info",o="情報";t.status==="pass"?(a="sev-pass",o="適正"):t.severity==="high"?(a="sev-high",o="危険"):t.severity==="medium"?(a="sev-medium",o="警告"):t.severity==="low"&&(a="sev-low",o="注意");const d=t.exceptionStatus==="accepted"||t.exceptionStatus==="false-positive"||t.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:4px;">許容済</span>':"";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${s(t.name)}</span>
          <span class="item-meta">${s(t.observed.substring(0,42))}</span>
        </div>
      </div>
      <div class="item-side">
        ${d}
        <span class="badge ${a}">${o}</span>
      </div>
    `,i.addEventListener("click",()=>K(t)),u.appendChild(i)})}function W(e){if(e.length===0){f.innerHTML='<div class="empty-state">観測されたCookieはありません</div>';return}f.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.issues&&t.issues.length>0,o=a?"sev-medium":"sev-pass",r=a?"要確認":"安全";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${s(t.name)}</span>
          <div class="item-meta">
            <span>${t.secure?"🔒 Secure":"⚠️ 不保護"}</span>
            <span>${t.httpOnly?"🛡️ HttpOnly":"スクリプト可"}</span>
            <span>SameSite: ${s(t.sameSite)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${o}">${r}</span>
      </div>
    `,i.addEventListener("click",()=>Q(t)),f.appendChild(i)})}function X(e){x.textContent=`${e.technology} 検出 & セキュリティ詳細`;let t="";if(e.versionIntegrity){const n=e.versionIntegrity,v=n.status==="match"?"var(--success-color)":n.status==="mismatch"?"var(--warning-color)":"var(--text-muted)";t=`
      <div>
        <div class="detail-section-title">CSS / JavaScript バージョン整合性</div>
        <div>JavaScript: <strong>${s(n.jsVersion||"未検出")}</strong> / CSS: <strong>${s(n.cssVersion||"未検出")}</strong></div>
        <div style="color:${v};font-weight:600;margin-top:2px;">判定: ${n.status==="match"?"一致 (OK)":n.status==="mismatch"?"要確認 (バージョン不一致)":"判定不能"}</div>
        <div style="font-size:11px;color:var(--text-muted);">${s(n.detail)}</div>
      </div>
    `}let i="";if(e.eolInfo){const n=e.eolInfo;i=`
      <div>
        <div class="detail-section-title">サポート状況 (EOL)</div>
        <div>ステータス: <strong style="color:${n.status==="EOL"?"var(--danger-color)":n.status==="Maintenance"?"var(--warning-color)":"var(--success-color)"};">${n.status}</strong> ${n.eolDate?`(EOL日: ${n.eolDate})`:""}</div>
        <div style="font-size:11px;color:var(--accent-color);">${s(n.recommendation)}</div>
        ${n.sourceUrl?`<div>出典: <a href="${n.sourceUrl}" target="_blank" class="ref-link">${n.sourceUrl}</a></div>`:""}
      </div>
    `}let a="";const o=e.offlineMatchStatus||"Not Covered",r=e.isStale?'<span style="color:var(--warning-color);margin-left:6px;font-size:11px;">⚠️ DB鮮度: 31日以上経過</span>':"";if(e.advisories&&e.advisories.length>0)a=`
      <div>
        <div class="detail-section-title" style="color:var(--danger-color);">該当する既知脆弱性 (${e.advisories.length} 件) ${r}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">照合ステータス: <strong>${o}</strong></div>
        ${e.advisories.map(n=>`
          <div class="advisory-card">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <strong>${s(n.id)}</strong>
              ${n.cvssScore?`<span class="badge sev-high">CVSS ${n.cvssScore}</span>`:""}
            </div>
            <div style="font-weight:600;margin-top:2px;">${s(n.title)}</div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">${s(n.summary)}</div>
            <div style="font-size:11px;margin-top:4px;">
              <span>影響範囲: <code>${s(n.affectedRange)}</code></span>
              ${n.fixedVersion?`<span style="margin-left:8px;color:var(--success-color);">修正版: <strong>v${s(n.fixedVersion)}</strong></span>`:""}
            </div>
            ${n.referenceUrls.length>0?`<div style="margin-top:4px;"><a href="${n.referenceUrls[0]}" target="_blank" class="ref-link">詳細情報 (NVD / GitHub)</a></div>`:""}
          </div>
        `).join("")}
      </div>
    `;else{let n="この技術のオフライン脆弱性データは未収録です。";o==="No Match"?n="オフラインDBに収録されていますが、検出されたバージョンには該当する既知脆弱性はありません。":o==="Unknown Version"&&(n="バージョン不明、またはLinuxディストリビューション固有パッケージのため脆弱性断定を保留しています。"),a=`
      <div>
        <div class="detail-section-title">脆弱性照合状況 (オフラインDB) ${r}</div>
        <div style="font-size:12px;">ステータス: <strong>${o}</strong></div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${s(n)}</div>
      </div>
    `}const d=e.isCandidateGroup&&e.candidateTechnologies?`
      <div style="margin-bottom:12px;padding:10px;background:var(--bg-surface);border:1px solid var(--border-color);border-radius:6px;">
        <div style="font-weight:600;font-size:12px;color:var(--text-sub);margin-bottom:6px;">推定候補フレームワーク:</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          ${e.candidateTechnologies.map(n=>`<span class="badge" style="background:var(--bg-hover);color:var(--text-main);font-size:12px;padding:3px 8px;">${s(n)}</span>`).join("")}
        </div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:8px;">
          ${s(e.description||"")}
        </div>
      </div>
    `:"";b.innerHTML=`
    ${d}
    <div>
      <div class="detail-section-title">基本情報</div>
      <div>確信度スコア: <strong>${e.confidence}</strong> (${e.confidenceLevel.toUpperCase()})</div>
      <div>代表バージョン: <strong>${e.isCandidateGroup?"いずれかの可能性あり":e.version||"不明"}</strong> ${e.versionSource?`[取得元: ${s(e.versionSource)}]`:""}</div>
      <div>カテゴリ: ${s(e.isCandidateGroup?"言語・フレームワーク候補":L(e.category))}</div>
      <div>検出方式: <strong>${Y(e.detectionMethod,e.isCandidateGroup)}</strong></div>
      ${e.inferredFrom?`<div>推論元技術: <strong>${s(e.inferredFrom)}</strong> ${e.implicationType?`(${Z(e.implicationType)})`:""}</div>`:""}
      ${e.inferencePath&&e.inferencePath.length>1?`<div>推論経路: <code>${s(e.inferencePath.join(" → "))}</code></div>`:""}
      <div>ランタイム状態: <strong>${ee(e.runtimeStatus)}</strong></div>
      ${e.runtimeStatus==="unknown"?'<div style="font-size:11px;color:var(--text-muted);margin-top:2px;">※受動的調査の原則に基づき、サーバー内部の稼働状態を観測できないため断定を保留しています。</div>':""}
      ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" class="ref-link">${e.website}</a></div>`:""}
    </div>

    ${e.isCandidateGroup?"":t}
    ${e.isCandidateGroup?"":i}
    ${e.isCandidateGroup?"":a}

    <div>
      <div class="detail-section-title">判定根拠 (エビデンス)</div>
      ${e.evidence.map(n=>`
        <div class="evidence-item">
          <div><strong>[${n.type}]</strong> ${s(n.name)}</div>
          <div class="detail-box">${s(n.value)}</div>
          ${n.detail?`<div style="font-size:11px;color:var(--text-muted);">${s(n.detail)}</div>`:""}
        </div>
      `).join("")}
    </div>
  `,l.classList.remove("hidden")}function K(e){x.textContent=e.name;const t=e.exceptionStatus==="accepted"||e.exceptionStatus==="false-positive"||e.exceptionStatus==="muted";let i="";t?i=`
      <div style="background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.3);border-radius:6px;padding:8px 12px;margin-top:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <strong style="color:var(--accent-color);">🛡️ この指摘は許容設定済みです</strong>
            <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">理由: ${s(e.exceptionReason||"未指定")}</div>
          </div>
          <button id="modalRevokeExceptionBtn" class="action-btn" style="font-size:11px;padding:3px 8px;">許容を解除</button>
        </div>
      </div>
    `:(e.status==="warning"||e.status==="fail")&&(i=`
      <div style="margin-top:12px;display:flex;gap:8px;">
        <button id="modalAcceptFindingBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          🛡️ この指摘を許容する (リスク受容)
        </button>
        <button id="modalFalsePositiveBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          ❌ 誤検知として除外
        </button>
      </div>
    `),b.innerHTML=`
    <div>
      <div class="detail-section-title">観測された値</div>
      <div class="detail-box">${s(e.observed)}</div>
    </div>

    <div>
      <div class="detail-section-title">現状・セキュリティ上の意味</div>
      <div>${s(e.description)}</div>
    </div>

    <div>
      <div class="detail-section-title">推奨される対応方法</div>
      <div style="color:var(--accent-color);">${s(e.recommendation)}</div>
    </div>

    ${e.referenceUrls&&e.referenceUrls.length>0?`
      <div>
        <div class="detail-section-title">参考資料</div>
        ${e.referenceUrls.map(d=>`<a href="${d}" target="_blank" class="ref-link">${d}</a>`).join("")}
      </div>
    `:""}

    ${i}
  `;const a=document.getElementById("modalAcceptFindingBtn");a&&e.findingId&&a.addEventListener("click",async()=>{const d=prompt("許容する理由（社内合意、暫定運用等）を入力してください:","運用要件に基づくリスク受容")||"運用上のリスク受容";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:c?.url,status:"accepted",reason:d,createdAt:new Date().toISOString()}}),l.classList.add("hidden"),g()});const o=document.getElementById("modalFalsePositiveBtn");o&&e.findingId&&o.addEventListener("click",async()=>{const d=prompt("誤検知の理由を入力してください:","対象環境における仕様上不要")||"誤検知";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:c?.url,status:"false-positive",reason:d,createdAt:new Date().toISOString()}}),l.classList.add("hidden"),g()});const r=document.getElementById("modalRevokeExceptionBtn");r&&(e.exceptionId||e.findingId)&&r.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:e.exceptionId||e.findingId}),l.classList.add("hidden"),g()}),l.classList.remove("hidden")}function Q(e){x.textContent=`Cookie: ${e.name}`,b.innerHTML=`
    <div>
      <div class="detail-section-title">属性詳細 (※値は除外)</div>
      <div>ドメイン: <strong>${s(e.domain)}</strong></div>
      <div>パス: <strong>${s(e.path)}</strong></div>
      <div>Secure: <strong>${e.secure?"有効":"無効"}</strong></div>
      <div>HttpOnly: <strong>${e.httpOnly?"有効":"無効"}</strong></div>
      <div>SameSite: <strong>${s(e.sameSite)}</strong></div>
      <div>有効期間: <strong>${e.session?"セッションCookie":"永続Cookie"}</strong></div>
    </div>

    ${e.issues&&e.issues.length>0?`
      <div>
        <div class="detail-section-title" style="color:var(--warning-color);">検出された課題</div>
        <ul style="padding-left:16px;">
          ${e.issues.map(t=>`<li>${s(t)}</li>`).join("")}
        </ul>
      </div>
    `:'<div style="color:var(--success-color);">重大な属性設定の不備は検出されませんでした。</div>'}
  `,l.classList.remove("hidden")}function L(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF","hosting-cloud":"ホスティング / クラウド基盤","analytics-tracking":"アクセス解析 / タグ管理","security-service":"セキュリティ / 監視サービス"}[e]||e}function Y(e,t){return t||e==="associated"?"実行環境候補・関連技術 (使用を裏付ける直接証拠なし)":e==="inferred"?"連動検知 (技術的依存関係に基づく推定)":"直接検出 (固有シグナルの観測あり)"}function Z(e){switch(e){case"framework-dependency":return"フレームワーク基盤依存";case"possible-runtime":return"実行環境の候補（静的配信等の代替構成あり）";case"runtime-dependency":return"実行時依存";case"technology-association":return"関連技術";default:return e||"連動"}}function ee(e){switch(e){case"confirmed":return"稼働確認済";case"possible":return"稼働可能性あり";case"unknown":return"稼働状態未確認";case"not-applicable":return"該当なし (クライアント技術)";default:return"未確認"}}function s(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
