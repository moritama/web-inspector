import{d as w,a as T}from"./json-CoecK1H4.js";let c=null;const y=document.getElementById("siteHostname"),p=document.getElementById("statusIndicator"),M=document.getElementById("techCount"),H=document.getElementById("attentionCount"),h=document.getElementById("eolCount"),k=document.getElementById("tabTechCount"),N=document.getElementById("tabSecCount"),D=document.getElementById("tabCookieCount"),m=document.getElementById("techsList"),u=document.getElementById("securityList"),f=document.getElementById("cookiesList"),z=document.getElementById("rescanBtn"),_=document.getElementById("themeToggleBtn"),A=document.getElementById("openDashboardBtn"),F=document.getElementById("fullReportBtn"),O=document.getElementById("exportJsonBtn"),U=document.getElementById("exportCsvBtn"),l=document.getElementById("detailModal"),x=document.getElementById("modalTitle"),b=document.getElementById("modalBody"),G=document.getElementById("closeModalBtn");document.addEventListener("DOMContentLoaded",()=>{R(),V(),P(),g()});function V(){const e=document.getElementById("brandVersion");if(e){const s=chrome.runtime?.getManifest?.()?.version||"1.6.5";e.textContent=`v${s}`}}function R(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function j(){const e=document.body.classList.contains("theme-dark"),s=e?"theme-light":"theme-dark";document.body.className=s,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function P(){_.addEventListener("click",j),z.addEventListener("click",()=>g()),A.addEventListener("click",L),F.addEventListener("click",L),O.addEventListener("click",()=>{c&&w(c)}),U.addEventListener("click",()=>{c&&T(c)}),document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(t=>t.classList.remove("active")),document.querySelectorAll(".tab-pane").forEach(t=>t.classList.remove("active")),e.classList.add("active");const s=e.getAttribute("data-tab");s&&document.getElementById(s)?.classList.add("active")})}),G.addEventListener("click",()=>{l.classList.add("hidden")}),l.addEventListener("click",e=>{e.target===l&&l.classList.add("hidden")})}function L(){const e=chrome.runtime.getURL("dashboard.html");chrome.tabs.create({url:e})}async function g(){p.className="status-indicator",y.textContent="調査中...",m.innerHTML='<div class="empty-state">技術情報を解析中...</div>',u.innerHTML='<div class="empty-state">セキュリティ設定を診断中...</div>',f.innerHTML='<div class="empty-state">Cookie属性を取得中...</div>';try{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});if(!e||!e.success)throw new Error(e?.error||"調査に失敗しました。");c=e.report,J(c)}catch(e){const s=e instanceof Error?e.message:String(e);y.textContent="調査エラー",p.className="status-indicator",p.style.backgroundColor="#EF4444",m.innerHTML=`<div class="empty-state" style="color: #EF4444;">${s}</div>`}}function J(e){p.className="status-indicator ready",y.textContent=e.hostname,M.textContent=String(e.technologies.length),H.textContent=String(e.summary.requiresAttentionCount);const s=(e.summary.librarySecurity?.eolCount??0)+(e.summary.librarySecurity?.vulnerableLibraryCount??0);h&&(h.textContent=String(s)),k.textContent=String(e.technologies.length),N.textContent=String(e.securityChecks.length),D.textContent=String(e.cookies.length),q(e.technologies,e.coverage),W(e.securityChecks),X(e.cookies);const t=document.getElementById("advisoryDbBar");if(t){const a=e.advisoryDatabaseVersion||"2026-10-23";t.textContent=`🛡️ 脆弱性DB更新日: ${a}`}}function q(e,s){if(m.innerHTML="",s&&s.networkHeadersObserved===!1){const t=document.createElement("div");t.className="notice-banner",t.style.cssText="background: rgba(245, 158, 11, 0.15); border: 1px solid var(--warning-color); border-radius: 6px; padding: 8px 10px; margin-bottom: 8px; font-size: 11px; color: var(--warning-color); line-height: 1.4;",t.innerHTML="⚠️ <strong>HTTPヘッダー未取得</strong>: 拡張機能起動前またはスリープ中に開かれたタブです。サーバーや言語ヘッダーを診断するには、ページを再読み込み（リロード）して再調査してください。",m.appendChild(t)}if(e.length===0){const t=document.createElement("div");t.className="empty-state",t.textContent="明確な固有技術シグナルは検出されませんでした",m.appendChild(t);return}e.forEach(t=>{const a=document.createElement("div");a.className="item-row";const o=t.confidenceLevel==="high"?"badge-high":t.confidenceLevel==="medium"?"badge-medium":"badge-low",r=t.confidenceLevel==="high"?"高":t.confidenceLevel==="medium"?"中":"低";let d="";t.isCandidateGroup||t.detectionMethod==="associated"?d='<span class="badge badge-associated">候補</span>':t.detectionMethod==="inferred"?d=`<span class="badge badge-inferred">連動${t.inferredFrom?` · ${i(t.inferredFrom)}`:""}</span>`:d='<span class="badge badge-direct">直接</span>';let n="";t.runtimeStatus==="unknown"?n='<span class="badge badge-runtime-unknown">稼働未確認</span>':t.runtimeStatus==="possible"&&(n='<span class="badge badge-runtime-possible">稼働可能性</span>');let v="";t.supportStatus==="EOL"?v='<span class="badge badge-eol">EOL</span>':t.supportStatus==="Maintenance"&&(v='<span class="badge badge-medium">保守</span>');let $="";t.advisories&&t.advisories.length>0&&($=`<span class="badge badge-cve">CVE ${t.maxCvss?`CVSS ${t.maxCvss}`:`${t.advisories.length}件`}</span>`);let E="";t.versionIntegrity?.status==="mismatch"&&(E='<span class="badge badge-mismatch">不一致</span>');let C=t.isCandidateGroup?"いずれかの可能性あり":t.version?`v${i(t.version)}`:"バージョン不明";t.versionSource==="runtime"&&(C+=" (実行時)");const B=t.isCandidateGroup?"？":t.technology.slice(0,2).toUpperCase(),I=t.isCandidateGroup?"言語・FW候補":S(t.category);a.innerHTML=`
      <div class="item-main">
        <div class="tech-icon-badge">${B}</div>
        <div class="item-texts">
          <div style="display:flex;align-items:center;gap:6px;">
            <span class="item-name">${i(t.technology)}</span>
            ${d}
            ${n}
          </div>
          <div class="item-meta">
            <span class="item-version-badge">${i(C)}</span>
            <span>${i(I)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        ${E}
        ${v}
        ${$}
        <span class="badge ${o}">${r} · ${t.confidence}</span>
      </div>
    `,a.addEventListener("click",()=>K(t)),m.appendChild(a)})}function W(e){if(e.length===0){u.innerHTML='<div class="empty-state">診断項目がありません</div>';return}u.innerHTML="",e.forEach(s=>{const t=document.createElement("div");t.className="item-row";let a="sev-info",o="情報";s.status==="pass"?(a="sev-pass",o="適正"):s.severity==="high"?(a="sev-high",o="危険"):s.severity==="medium"?(a="sev-medium",o="警告"):s.severity==="low"&&(a="sev-low",o="注意");const d=s.exceptionStatus==="accepted"||s.exceptionStatus==="false-positive"||s.exceptionStatus==="muted"?'<span class="badge" style="background:#4B5563;color:#E5E7EB;margin-right:4px;">許容済</span>':"";t.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${i(s.name)}</span>
          <span class="item-meta">${i(s.observed.substring(0,42))}</span>
        </div>
      </div>
      <div class="item-side">
        ${d}
        <span class="badge ${a}">${o}</span>
      </div>
    `,t.addEventListener("click",()=>Q(s)),u.appendChild(t)})}function X(e){if(e.length===0){f.innerHTML='<div class="empty-state">観測されたCookieはありません</div>';return}f.innerHTML="",e.forEach(s=>{const t=document.createElement("div");t.className="item-row";const a=s.issues&&s.issues.length>0,o=a?"sev-medium":"sev-pass",r=a?"要確認":"安全";t.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${i(s.name)}</span>
          <div class="item-meta">
            <span>${s.secure?"🔒 Secure":"⚠️ 不保護"}</span>
            <span>${s.httpOnly?"🛡️ HttpOnly":"スクリプト可"}</span>
            <span>SameSite: ${i(s.sameSite||"-")}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${o}">${r}</span>
      </div>
    `,t.addEventListener("click",()=>Y(s)),f.appendChild(t)})}function K(e){x.textContent=`${e.technology} 検出 & セキュリティ詳細`;let s="";if(e.versionIntegrity){const n=e.versionIntegrity,v=n.status==="match"?"var(--success-color)":n.status==="mismatch"?"var(--warning-color)":"var(--text-muted)";s=`
      <div>
        <div class="detail-section-title">CSS / JavaScript バージョン整合性</div>
        <div>JavaScript: <strong>${i(n.jsVersion||"未検出")}</strong> / CSS: <strong>${i(n.cssVersion||"未検出")}</strong></div>
        <div style="color:${v};font-weight:600;margin-top:2px;">判定: ${n.status==="match"?"一致 (OK)":n.status==="mismatch"?"要確認 (バージョン不一致)":"判定不能"}</div>
        <div style="font-size:11px;color:var(--text-muted);">${i(n.detail)}</div>
      </div>
    `}let t="";if(e.eolInfo){const n=e.eolInfo;t=`
      <div>
        <div class="detail-section-title">サポート状況 (EOL)</div>
        <div>ステータス: <strong style="color:${n.status==="EOL"?"var(--danger-color)":n.status==="Maintenance"?"var(--warning-color)":"var(--success-color)"};">${n.status}</strong> ${n.eolDate?`(EOL日: ${n.eolDate})`:""}</div>
        <div style="font-size:11px;color:var(--accent-color);">${i(n.recommendation)}</div>
        ${n.sourceUrl?`<div>出典: <a href="${n.sourceUrl}" target="_blank" class="ref-link">${n.sourceUrl}</a></div>`:""}
      </div>
    `}let a="";const o=e.offlineMatchStatus||"Not Covered",r=e.isStale?'<span style="color:var(--warning-color);margin-left:6px;font-size:11px;">⚠️ DB鮮度: 31日以上経過</span>':"";if(e.advisories&&e.advisories.length>0)a=`
      <div>
        <div class="detail-section-title" style="color:var(--danger-color);">該当する既知脆弱性 (${e.advisories.length} 件) ${r}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">照合ステータス: <strong>${o}</strong></div>
        ${e.advisories.map(n=>`
          <div class="advisory-card">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <strong>${i(n.id)}</strong>
              ${n.cvssScore?`<span class="badge sev-high">CVSS ${n.cvssScore}</span>`:""}
            </div>
            <div style="font-weight:600;margin-top:2px;">${i(n.title)}</div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">${i(n.summary)}</div>
            <div style="font-size:11px;margin-top:4px;">
              <span>影響範囲: <code>${i(n.affectedRange)}</code></span>
              ${n.fixedVersion?`<span style="margin-left:8px;color:var(--success-color);">修正版: <strong>v${i(n.fixedVersion)}</strong></span>`:""}
            </div>
            ${n.referenceUrls.length>0?`<div style="margin-top:4px;"><a href="${n.referenceUrls[0]}" target="_blank" class="ref-link">詳細情報 (NVD / GitHub)</a></div>`:""}
          </div>
        `).join("")}
      </div>
    `;else{let n="この技術のオフライン脆弱性データは未収録です。";o==="No Match"?n="オフラインDBに収録されていますが、検出されたバージョンには該当する既知脆弱性はありません。":o==="Unknown Version"&&(n="バージョン不明、またはLinuxディストリビューション固有パッケージのため脆弱性断定を保留しています。"),a=`
      <div>
        <div class="detail-section-title">脆弱性照合状況 (オフラインDB) ${r}</div>
        <div style="font-size:12px;">ステータス: <strong>${o}</strong></div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${i(n)}</div>
      </div>
    `}const d=e.isCandidateGroup&&e.candidateTechnologies?`
      <div style="margin-bottom:12px;padding:10px;background:var(--bg-surface);border:1px solid var(--border-color);border-radius:6px;">
        <div style="font-weight:600;font-size:12px;color:var(--text-sub);margin-bottom:6px;">推定候補フレームワーク:</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          ${e.candidateTechnologies.map(n=>`<span class="badge" style="background:var(--bg-hover);color:var(--text-main);font-size:12px;padding:3px 8px;">${i(n)}</span>`).join("")}
        </div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:8px;">
          ${i(e.description||"")}
        </div>
      </div>
    `:"";b.innerHTML=`
    ${d}
    <div>
      <div class="detail-section-title">基本情報</div>
      <div>確信度スコア: <strong>${e.confidence}</strong> (${e.confidenceLevel.toUpperCase()})</div>
      <div>代表バージョン: <strong>${e.isCandidateGroup?"いずれかの可能性あり":e.version||"不明"}</strong> ${e.versionSource?`[取得元: ${i(e.versionSource)}]`:""}</div>
      <div>カテゴリ: ${i(e.isCandidateGroup?"言語・フレームワーク候補":S(e.category))}</div>
      <div>検出方式: <strong>${Z(e.detectionMethod,e.isCandidateGroup)}</strong></div>
      ${e.inferredFrom?`<div>推論元技術: <strong>${i(e.inferredFrom)}</strong> ${e.implicationType?`(${ee(e.implicationType)})`:""}</div>`:""}
      ${e.inferencePath&&e.inferencePath.length>1?`<div>推論経路: <code>${i(e.inferencePath.join(" → "))}</code></div>`:""}
      <div>ランタイム状態: <strong>${te(e.runtimeStatus)}</strong></div>
      ${e.runtimeStatus==="unknown"?'<div style="font-size:11px;color:var(--text-muted);margin-top:2px;">※受動的調査の原則に基づき、サーバー内部の稼働状態を観測できないため断定を保留しています。</div>':""}
      ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" class="ref-link">${e.website}</a></div>`:""}
    </div>

    ${e.isCandidateGroup?"":s}
    ${e.isCandidateGroup?"":t}
    ${e.isCandidateGroup?"":a}

    <div>
      <div class="detail-section-title">判定根拠 (エビデンス)</div>
      ${e.evidence.map(n=>`
        <div class="evidence-item">
          <div><strong>[${n.type}]</strong> ${i(n.name)}</div>
          <div class="detail-box">${i(n.value)}</div>
          ${n.detail?`<div style="font-size:11px;color:var(--text-muted);">${i(n.detail)}</div>`:""}
        </div>
      `).join("")}
    </div>
  `,l.classList.remove("hidden")}function Q(e){x.textContent=e.name;const s=e.exceptionStatus==="accepted"||e.exceptionStatus==="false-positive"||e.exceptionStatus==="muted";let t="";s?t=`
      <div style="background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.3);border-radius:6px;padding:8px 12px;margin-top:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <strong style="color:var(--accent-color);">🛡️ この指摘は許容設定済みです</strong>
            <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">理由: ${i(e.exceptionReason||"未指定")}</div>
          </div>
          <button id="modalRevokeExceptionBtn" class="action-btn" style="font-size:11px;padding:3px 8px;">許容を解除</button>
        </div>
      </div>
    `:(e.status==="warning"||e.status==="fail")&&(t=`
      <div style="margin-top:12px;display:flex;gap:8px;">
        <button id="modalAcceptFindingBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          🛡️ この指摘を許容する (リスク受容)
        </button>
        <button id="modalFalsePositiveBtn" class="action-btn" style="flex:1;font-size:11px;padding:6px 10px;">
          ❌ 誤検知として除外
        </button>
      </div>
    `),b.innerHTML=`
    <div>
      <div class="detail-section-title">観測された値</div>
      <div class="detail-box">${i(e.observed)}</div>
    </div>

    <div>
      <div class="detail-section-title">現状・セキュリティ上の意味</div>
      <div>${i(e.description)}</div>
    </div>

    <div>
      <div class="detail-section-title">推奨される対応方法</div>
      <div style="color:var(--accent-color);">${i(e.recommendation)}</div>
    </div>

    ${e.referenceUrls&&e.referenceUrls.length>0?`
      <div>
        <div class="detail-section-title">参考資料</div>
        ${e.referenceUrls.map(d=>`<a href="${d}" target="_blank" class="ref-link">${d}</a>`).join("")}
      </div>
    `:""}

    ${t}
  `;const a=document.getElementById("modalAcceptFindingBtn");a&&e.findingId&&a.addEventListener("click",async()=>{const d=prompt("許容する理由（社内合意、暫定運用等）を入力してください:","運用要件に基づくリスク受容")||"運用上のリスク受容";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:c?.url,status:"accepted",reason:d,createdAt:new Date().toISOString()}}),l.classList.add("hidden"),g()});const o=document.getElementById("modalFalsePositiveBtn");o&&e.findingId&&o.addEventListener("click",async()=>{const d=prompt("誤検知の理由を入力してください:","対象環境における仕様上不要")||"誤検知";await chrome.runtime.sendMessage({type:"SAVE_FINDING_EXCEPTION",exception:{id:`ex_${Date.now()}`,findingId:e.findingId,targetUrl:c?.url,status:"false-positive",reason:d,createdAt:new Date().toISOString()}}),l.classList.add("hidden"),g()});const r=document.getElementById("modalRevokeExceptionBtn");r&&(e.exceptionId||e.findingId)&&r.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"DELETE_FINDING_EXCEPTION",id:e.exceptionId||e.findingId}),l.classList.add("hidden"),g()}),l.classList.remove("hidden")}function Y(e){x.textContent=`Cookie: ${e.name}`,b.innerHTML=`
    <div>
      <div class="detail-section-title">属性詳細 (※値は除外)</div>
      <div>ドメイン: <strong>${i(e.domain||"-")}</strong></div>
      <div>パス: <strong>${i(e.path||"-")}</strong></div>
      <div>Secure: <strong>${e.secure?"有効":"無効"}</strong></div>
      <div>HttpOnly: <strong>${e.httpOnly?"有効":"無効"}</strong></div>
      <div>SameSite: <strong>${i(e.sameSite||"-")}</strong></div>
      <div>有効期間: <strong>${e.session?"セッションCookie":"永続Cookie"}</strong></div>
    </div>

    ${e.issues&&e.issues.length>0?`
      <div>
        <div class="detail-section-title" style="color:var(--warning-color);">検出された課題</div>
        <ul style="padding-left:16px;">
          ${e.issues.map(s=>`<li>${i(s)}</li>`).join("")}
        </ul>
      </div>
    `:'<div style="color:var(--success-color);">重大な属性設定の不備は検出されませんでした。</div>'}
  `,l.classList.remove("hidden")}function S(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF","hosting-cloud":"ホスティング / クラウド基盤","analytics-tracking":"アクセス解析 / タグ管理","security-service":"セキュリティ / 監視サービス"}[e]||e}function Z(e,s){return s||e==="associated"?"実行環境候補・関連技術 (使用を裏付ける直接証拠なし)":e==="inferred"?"連動検知 (技術的依存関係に基づく推定)":"直接検出 (固有シグナルの観測あり)"}function ee(e){switch(e){case"framework-dependency":return"フレームワーク基盤依存";case"possible-runtime":return"実行環境の候補（静的配信等の代替構成あり）";case"runtime-dependency":return"実行時依存";case"technology-association":return"関連技術";default:return e||"連動"}}function te(e){switch(e){case"confirmed":return"稼働確認済";case"possible":return"稼働可能性あり";case"unknown":return"稼働状態未確認";case"not-applicable":return"該当なし (クライアント技術)";default:return"未確認"}}function i(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
