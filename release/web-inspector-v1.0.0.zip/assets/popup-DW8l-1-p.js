import{d as f,a as L}from"./json-Cn1rn-7J.js";let o=null;const v=document.getElementById("siteHostname"),c=document.getElementById("statusIndicator"),C=document.getElementById("techCount"),b=document.getElementById("attentionCount"),$=document.getElementById("checkCount"),B=document.getElementById("tabTechCount"),S=document.getElementById("tabSecCount"),T=document.getElementById("tabCookieCount"),l=document.getElementById("techsList"),r=document.getElementById("securityList"),m=document.getElementById("cookiesList"),I=document.getElementById("rescanBtn"),w=document.getElementById("themeToggleBtn"),k=document.getElementById("openDashboardBtn"),M=document.getElementById("fullReportBtn"),x=document.getElementById("exportJsonBtn"),H=document.getElementById("exportCsvBtn"),a=document.getElementById("detailModal"),g=document.getElementById("modalTitle"),u=document.getElementById("modalBody"),N=document.getElementById("closeModalBtn");document.addEventListener("DOMContentLoaded",()=>{_(),R(),p()});function _(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function A(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function R(){w.addEventListener("click",A),I.addEventListener("click",()=>{p()}),k.addEventListener("click",h),M.addEventListener("click",h),x.addEventListener("click",()=>{o&&f(o)}),H.addEventListener("click",()=>{o&&L(o)}),document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(n=>n.classList.remove("active")),document.querySelectorAll(".tab-pane").forEach(n=>n.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-tab");t&&document.getElementById(t)?.classList.add("active")})}),N.addEventListener("click",()=>{a.classList.add("hidden")}),a.addEventListener("click",e=>{e.target===a&&a.classList.add("hidden")})}function h(){const e=chrome.runtime.getURL("dashboard.html");chrome.tabs.create({url:e})}async function p(){c.className="status-indicator",v.textContent="調査中...",l.innerHTML='<div class="empty-state">技術情報を解析中...</div>',r.innerHTML='<div class="empty-state">セキュリティ設定を診断中...</div>',m.innerHTML='<div class="empty-state">Cookie属性を取得中...</div>';try{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});if(!e||!e.success)throw new Error(e?.error||"調査に失敗しました。");o=e.report,U(o)}catch(e){const t=e instanceof Error?e.message:String(e);v.textContent="調査エラー",c.className="status-indicator",c.style.backgroundColor="#EF4444",l.innerHTML=`<div class="empty-state" style="color: #EF4444;">${t}</div>`}}function U(e){c.className="status-indicator ready",v.textContent=e.hostname,C.textContent=String(e.technologies.length),b.textContent=String(e.summary.requiresAttentionCount),$.textContent=String(e.securityChecks.length),B.textContent=String(e.technologies.length),S.textContent=String(e.securityChecks.length),T.textContent=String(e.cookies.length),D(e.technologies),j(e.securityChecks),q(e.cookies)}function D(e){if(e.length===0){l.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}l.innerHTML="",e.forEach(t=>{const n=document.createElement("div");n.className="item-row";const i=t.confidenceLevel==="high"?"badge-high":t.confidenceLevel==="medium"?"badge-medium":"badge-low",d=t.confidenceLevel==="high"?"高":t.confidenceLevel==="medium"?"中":"低";n.innerHTML=`
      <div class="item-main">
        <div class="tech-icon-badge">${t.technology.slice(0,2).toUpperCase()}</div>
        <div class="item-texts">
          <span class="item-name">${s(t.technology)}</span>
          <div class="item-meta">
            ${t.version?`<span class="item-version-badge">v${s(t.version)}</span>`:'<span class="item-version-badge">バージョン不明</span>'}
            <span>${s(y(t.category))}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${i}">${d} · ${t.confidence}</span>
      </div>
    `,n.addEventListener("click",()=>F(t)),l.appendChild(n)})}function j(e){if(e.length===0){r.innerHTML='<div class="empty-state">診断項目がありません</div>';return}r.innerHTML="",e.forEach(t=>{const n=document.createElement("div");n.className="item-row";let i="sev-info",d="情報";t.status==="pass"?(i="sev-pass",d="適正"):t.severity==="high"?(i="sev-high",d="危険"):t.severity==="medium"?(i="sev-medium",d="警告"):t.severity==="low"&&(i="sev-low",d="注意"),n.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${s(t.name)}</span>
          <span class="item-meta">${s(t.observed.substring(0,40))}</span>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${i}">${d}</span>
      </div>
    `,n.addEventListener("click",()=>J(t)),r.appendChild(n)})}function q(e){if(e.length===0){m.innerHTML='<div class="empty-state">観測されたCookieはありません</div>';return}m.innerHTML="",e.forEach(t=>{const n=document.createElement("div");n.className="item-row";const i=t.issues&&t.issues.length>0,d=i?"sev-medium":"sev-pass",E=i?"要確認":"安全";n.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${s(t.name)}</span>
          <div class="item-meta">
            <span>${t.secure?"🔒 Secure":"⚠️ 不保護"}</span>
            <span>${t.httpOnly?"🛡️ HttpOnly":"スクリプト可"}</span>
            <span>SameSite: ${s(t.sameSite)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${d}">${E}</span>
      </div>
    `,n.addEventListener("click",()=>O(t)),m.appendChild(n)})}function F(e){g.textContent=`${e.technology} 検出詳細`,u.innerHTML=`
    <div>
      <div class="detail-section-title">判定情報</div>
      <div>確信度スコア: <strong>${e.confidence}</strong> (${e.confidenceLevel==="high"?"高":e.confidenceLevel==="medium"?"中":"低"})</div>
      <div>検出バージョン: <strong>${e.version||"不明（明示的なシグナルなし）"}</strong></div>
      <div>カテゴリ: ${s(y(e.category))}</div>
      ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" class="ref-link">${e.website}</a></div>`:""}
    </div>

    <div>
      <div class="detail-section-title">判定根拠 (エビデンス)</div>
      ${e.evidence.map(t=>`
        <div class="evidence-item">
          <div><strong>[${t.type}]</strong> ${s(t.name)}</div>
          <div class="detail-box">${s(t.value)}</div>
          ${t.detail?`<div style="font-size:11px;color:var(--text-muted);">${s(t.detail)}</div>`:""}
        </div>
      `).join("")}
    </div>
  `,a.classList.remove("hidden")}function J(e){g.textContent=e.name,u.innerHTML=`
    <div>
      <div class="detail-section-title">観測された値</div>
      <div class="detail-box">${s(e.observed)}</div>
    </div>

    <div>
      <div class="detail-section-title">現状・セキュリティ上の意味</div>
      <div>${s(e.description)}</div>
    </div>

    <div>
      <div class="detail-section-title">推奨される対応方法</div>
      <div style="color:var(--accent-color);">${s(e.recommendation)}</div>
    </div>

    ${e.referenceUrls&&e.referenceUrls.length>0?`
      <div>
        <div class="detail-section-title">参考資料</div>
        ${e.referenceUrls.map(t=>`<a href="${t}" target="_blank" class="ref-link">${t}</a>`).join("")}
      </div>
    `:""}
  `,a.classList.remove("hidden")}function O(e){g.textContent=`Cookie: ${e.name}`,u.innerHTML=`
    <div>
      <div class="detail-section-title">属性詳細 (※値は取得・保存しません)</div>
      <div>ドメイン: <strong>${s(e.domain)}</strong></div>
      <div>パス: <strong>${s(e.path)}</strong></div>
      <div>Secure: <strong>${e.secure?"有効":"無効"}</strong></div>
      <div>HttpOnly: <strong>${e.httpOnly?"有効":"無効"}</strong></div>
      <div>SameSite: <strong>${s(e.sameSite)}</strong></div>
      <div>有効期間: <strong>${e.session?"セッションCookie":"永続Cookie"}</strong></div>
    </div>

    ${e.issues&&e.issues.length>0?`
      <div>
        <div class="detail-section-title" style="color:var(--warning-color);">検出された課題</div>
        <ul style="padding-left:16px;">
          ${e.issues.map(t=>`<li>${s(t)}</li>`).join("")}
        </ul>
      </div>
    `:'<div style="color:var(--success-color);">重大な属性設定の不備は検出されませんでした。</div>'}
  `,a.classList.remove("hidden")}function y(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF"}[e]||e}function s(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
