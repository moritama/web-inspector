import{d as L,a as S}from"./json-BkehWN5C.js";let l=null;const g=document.getElementById("siteHostname"),c=document.getElementById("statusIndicator"),x=document.getElementById("techCount"),B=document.getElementById("attentionCount"),h=document.getElementById("eolCount"),I=document.getElementById("tabTechCount"),w=document.getElementById("tabSecCount"),T=document.getElementById("tabCookieCount"),r=document.getElementById("techsList"),v=document.getElementById("securityList"),m=document.getElementById("cookiesList"),H=document.getElementById("rescanBtn"),M=document.getElementById("themeToggleBtn"),k=document.getElementById("openDashboardBtn"),U=document.getElementById("fullReportBtn"),N=document.getElementById("exportJsonBtn"),O=document.getElementById("exportCsvBtn"),d=document.getElementById("detailModal"),u=document.getElementById("modalTitle"),p=document.getElementById("modalBody"),_=document.getElementById("closeModalBtn");document.addEventListener("DOMContentLoaded",()=>{D(),A(),E()});function D(){const e=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=e==="light"?"theme-light":"theme-dark"}function j(){const e=document.body.classList.contains("theme-dark"),t=e?"theme-light":"theme-dark";document.body.className=t,localStorage.setItem("web_inspector_theme",e?"light":"dark")}function A(){M.addEventListener("click",j),H.addEventListener("click",()=>E()),k.addEventListener("click",C),U.addEventListener("click",C),N.addEventListener("click",()=>{l&&L(l)}),O.addEventListener("click",()=>{l&&S(l)}),document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(i=>i.classList.remove("active")),document.querySelectorAll(".tab-pane").forEach(i=>i.classList.remove("active")),e.classList.add("active");const t=e.getAttribute("data-tab");t&&document.getElementById(t)?.classList.add("active")})}),_.addEventListener("click",()=>{d.classList.add("hidden")}),d.addEventListener("click",e=>{e.target===d&&d.classList.add("hidden")})}function C(){const e=chrome.runtime.getURL("dashboard.html");chrome.tabs.create({url:e})}async function E(){c.className="status-indicator",g.textContent="調査中...",r.innerHTML='<div class="empty-state">技術情報を解析中...</div>',v.innerHTML='<div class="empty-state">セキュリティ設定を診断中...</div>',m.innerHTML='<div class="empty-state">Cookie属性を取得中...</div>';try{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});if(!e||!e.success)throw new Error(e?.error||"調査に失敗しました。");l=e.report,R(l)}catch(e){const t=e instanceof Error?e.message:String(e);g.textContent="調査エラー",c.className="status-indicator",c.style.backgroundColor="#EF4444",r.innerHTML=`<div class="empty-state" style="color: #EF4444;">${t}</div>`}}function R(e){c.className="status-indicator ready",g.textContent=e.hostname,x.textContent=String(e.technologies.length),B.textContent=String(e.summary.requiresAttentionCount);const t=(e.summary.librarySecurity?.eolCount??0)+(e.summary.librarySecurity?.vulnerableLibraryCount??0);h&&(h.textContent=String(t)),I.textContent=String(e.technologies.length),w.textContent=String(e.securityChecks.length),T.textContent=String(e.cookies.length),V(e.technologies),J(e.securityChecks),q(e.cookies)}function V(e){if(e.length===0){r.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}r.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.confidenceLevel==="high"?"badge-high":t.confidenceLevel==="medium"?"badge-medium":"badge-low",s=t.confidenceLevel==="high"?"高":t.confidenceLevel==="medium"?"中":"低";let o="";t.supportStatus==="EOL"?o='<span class="badge badge-eol">EOL</span>':t.supportStatus==="Maintenance"&&(o='<span class="badge badge-medium">保守</span>');let y="";t.advisories&&t.advisories.length>0&&(y=`<span class="badge badge-cve">CVE ${t.maxCvss?`CVSS ${t.maxCvss}`:`${t.advisories.length}件`}</span>`);let f="";t.versionIntegrity?.status==="mismatch"&&(f='<span class="badge badge-mismatch">不一致</span>');let $=t.version?`v${n(t.version)}`:"バージョン不明";t.versionSource==="runtime"&&($+=" (実行時)"),i.innerHTML=`
      <div class="item-main">
        <div class="tech-icon-badge">${t.technology.slice(0,2).toUpperCase()}</div>
        <div class="item-texts">
          <span class="item-name">${n(t.technology)}</span>
          <div class="item-meta">
            <span class="item-version-badge">${n($)}</span>
            <span>${n(b(t.category))}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        ${f}
        ${o}
        ${y}
        <span class="badge ${a}">${s} · ${t.confidence}</span>
      </div>
    `,i.addEventListener("click",()=>z(t)),r.appendChild(i)})}function J(e){if(e.length===0){v.innerHTML='<div class="empty-state">診断項目がありません</div>';return}v.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";let a="sev-info",s="情報";t.status==="pass"?(a="sev-pass",s="適正"):t.severity==="high"?(a="sev-high",s="危険"):t.severity==="medium"?(a="sev-medium",s="警告"):t.severity==="low"&&(a="sev-low",s="注意"),i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <span class="item-meta">${n(t.observed.substring(0,42))}</span>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${a}">${s}</span>
      </div>
    `,i.addEventListener("click",()=>F(t)),v.appendChild(i)})}function q(e){if(e.length===0){m.innerHTML='<div class="empty-state">観測されたCookieはありません</div>';return}m.innerHTML="",e.forEach(t=>{const i=document.createElement("div");i.className="item-row";const a=t.issues&&t.issues.length>0,s=a?"sev-medium":"sev-pass",o=a?"要確認":"安全";i.innerHTML=`
      <div class="item-main">
        <div class="item-texts">
          <span class="item-name">${n(t.name)}</span>
          <div class="item-meta">
            <span>${t.secure?"🔒 Secure":"⚠️ 不保護"}</span>
            <span>${t.httpOnly?"🛡️ HttpOnly":"スクリプト可"}</span>
            <span>SameSite: ${n(t.sameSite)}</span>
          </div>
        </div>
      </div>
      <div class="item-side">
        <span class="badge ${s}">${o}</span>
      </div>
    `,i.addEventListener("click",()=>W(t)),m.appendChild(i)})}function z(e){u.textContent=`${e.technology} 検出 & セキュリティ詳細`;let t="";if(e.versionIntegrity){const s=e.versionIntegrity,o=s.status==="match"?"var(--success-color)":s.status==="mismatch"?"var(--warning-color)":"var(--text-muted)";t=`
      <div>
        <div class="detail-section-title">CSS / JavaScript バージョン整合性</div>
        <div>JavaScript: <strong>${n(s.jsVersion||"未検出")}</strong> / CSS: <strong>${n(s.cssVersion||"未検出")}</strong></div>
        <div style="color:${o};font-weight:600;margin-top:2px;">判定: ${s.status==="match"?"一致 (OK)":s.status==="mismatch"?"要確認 (バージョン不一致)":"判定不能"}</div>
        <div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>
      </div>
    `}let i="";if(e.eolInfo){const s=e.eolInfo;i=`
      <div>
        <div class="detail-section-title">サポート状況 (EOL)</div>
        <div>ステータス: <strong style="color:${s.status==="EOL"?"var(--danger-color)":s.status==="Maintenance"?"var(--warning-color)":"var(--success-color)"};">${s.status}</strong> ${s.eolDate?`(EOL日: ${s.eolDate})`:""}</div>
        <div style="font-size:11px;color:var(--accent-color);">${n(s.recommendation)}</div>
        ${s.sourceUrl?`<div>出典: <a href="${s.sourceUrl}" target="_blank" class="ref-link">${s.sourceUrl}</a></div>`:""}
      </div>
    `}let a="";e.advisories&&e.advisories.length>0&&(a=`
      <div>
        <div class="detail-section-title" style="color:var(--danger-color);">該当する既知脆弱性 (${e.advisories.length} 件)</div>
        ${e.advisories.map(s=>`
          <div class="advisory-card">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <strong>${n(s.id)}</strong>
              ${s.cvssScore?`<span class="badge sev-high">CVSS ${s.cvssScore}</span>`:""}
            </div>
            <div style="font-weight:600;margin-top:2px;">${n(s.title)}</div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">${n(s.summary)}</div>
            <div style="font-size:11px;margin-top:4px;">
              <span>影響範囲: <code>${n(s.affectedRange)}</code></span>
              ${s.fixedVersion?`<span style="margin-left:8px;color:var(--success-color);">修正版: <strong>v${n(s.fixedVersion)}</strong></span>`:""}
            </div>
            ${s.referenceUrls.length>0?`<div style="margin-top:4px;"><a href="${s.referenceUrls[0]}" target="_blank" class="ref-link">詳細情報 (NVD / GitHub)</a></div>`:""}
          </div>
        `).join("")}
      </div>
    `),p.innerHTML=`
    <div>
      <div class="detail-section-title">基本情報</div>
      <div>確信度スコア: <strong>${e.confidence}</strong> (${e.confidenceLevel.toUpperCase()})</div>
      <div>代表バージョン: <strong>${e.version||"不明"}</strong> ${e.versionSource?`[取得元: ${n(e.versionSource)}]`:""}</div>
      <div>カテゴリ: ${n(b(e.category))}</div>
      ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" class="ref-link">${e.website}</a></div>`:""}
    </div>

    ${t}
    ${i}
    ${a}

    <div>
      <div class="detail-section-title">判定根拠 (エビデンス)</div>
      ${e.evidence.map(s=>`
        <div class="evidence-item">
          <div><strong>[${s.type}]</strong> ${n(s.name)}</div>
          <div class="detail-box">${n(s.value)}</div>
          ${s.detail?`<div style="font-size:11px;color:var(--text-muted);">${n(s.detail)}</div>`:""}
        </div>
      `).join("")}
    </div>
  `,d.classList.remove("hidden")}function F(e){u.textContent=e.name,p.innerHTML=`
    <div>
      <div class="detail-section-title">観測された値</div>
      <div class="detail-box">${n(e.observed)}</div>
    </div>

    <div>
      <div class="detail-section-title">現状・セキュリティ上の意味</div>
      <div>${n(e.description)}</div>
    </div>

    <div>
      <div class="detail-section-title">推奨される対応方法</div>
      <div style="color:var(--accent-color);">${n(e.recommendation)}</div>
    </div>

    ${e.referenceUrls&&e.referenceUrls.length>0?`
      <div>
        <div class="detail-section-title">参考資料</div>
        ${e.referenceUrls.map(t=>`<a href="${t}" target="_blank" class="ref-link">${t}</a>`).join("")}
      </div>
    `:""}
  `,d.classList.remove("hidden")}function W(e){u.textContent=`Cookie: ${e.name}`,p.innerHTML=`
    <div>
      <div class="detail-section-title">属性詳細 (※値は除外)</div>
      <div>ドメイン: <strong>${n(e.domain)}</strong></div>
      <div>パス: <strong>${n(e.path)}</strong></div>
      <div>Secure: <strong>${e.secure?"有効":"無効"}</strong></div>
      <div>HttpOnly: <strong>${e.httpOnly?"有効":"無効"}</strong></div>
      <div>SameSite: <strong>${n(e.sameSite)}</strong></div>
      <div>有効期間: <strong>${e.session?"セッションCookie":"永続Cookie"}</strong></div>
    </div>

    ${e.issues&&e.issues.length>0?`
      <div>
        <div class="detail-section-title" style="color:var(--warning-color);">検出された課題</div>
        <ul style="padding-left:16px;">
          ${e.issues.map(t=>`<li>${n(t)}</li>`).join("")}
        </ul>
      </div>
    `:'<div style="color:var(--success-color);">重大な属性設定の不備は検出されませんでした。</div>'}
  `,d.classList.remove("hidden")}function b(e){return{"web-server":"Webサーバー","programming-language":"開発言語・フレームワーク",cms:"CMS","js-framework":"JSフレームワーク","js-css-library":"JS / CSSライブラリ","cdn-waf":"CDN / WAF"}[e]||e}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
