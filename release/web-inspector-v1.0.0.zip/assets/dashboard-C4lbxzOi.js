import{d as f,a as $}from"./json-Cn1rn-7J.js";import{c as x}from"./history-C4qiM2Dl.js";let i=null,a=[];const E=document.getElementById("currentHostname"),b=document.getElementById("inspectedAtTime"),T=document.getElementById("dashTotalTechs"),w=document.getElementById("dashAttentionCount"),C=document.getElementById("dashHttpsStatus"),L=document.getElementById("dashMixedStatus"),B=document.getElementById("dashCookieCount"),v=document.getElementById("overviewTechsList"),p=document.getElementById("overviewSecurityList"),u=document.getElementById("fullTechsContainer"),S=document.getElementById("fullSecurityContainer"),g=document.getElementById("cookiesTableBody"),h=document.getElementById("historyListContainer"),l=document.getElementById("compareSelectA"),m=document.getElementById("compareSelectB"),I=document.getElementById("executeCompareBtn"),H=document.getElementById("compareResultContainer"),k=document.getElementById("themeToggleBtn"),A=document.getElementById("exportJsonBtn"),M=document.getElementById("exportCsvBtn"),j=document.getElementById("refreshBtn"),R=document.getElementById("clearHistoryBtn");document.addEventListener("DOMContentLoaded",async()=>{_(),D(),z(),await c()});function _(){const t=localStorage.getItem("web_inspector_theme")||"dark";document.body.className=t==="light"?"theme-light":"theme-dark"}function P(){const t=document.body.classList.contains("theme-dark"),e=t?"theme-light":"theme-dark";document.body.className=e,localStorage.setItem("web_inspector_theme",t?"light":"dark")}function D(){document.querySelectorAll(".nav-item").forEach(t=>{t.addEventListener("click",()=>{document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active")),document.querySelectorAll(".view-panel").forEach(n=>n.classList.remove("active")),t.classList.add("active");const e=t.getAttribute("data-view");e&&document.getElementById(e)?.classList.add("active")})})}function z(){k.addEventListener("click",P),j.addEventListener("click",c),A.addEventListener("click",()=>{i&&f(i)}),M.addEventListener("click",()=>{i&&$(i)}),R.addEventListener("click",async()=>{confirm("すべての調査履歴を完全に削除しますか？")&&(await chrome.runtime.sendMessage({type:"CLEAR_HISTORY"}),await c())}),I.addEventListener("click",G)}async function c(){try{const t=await chrome.runtime.sendMessage({type:"GET_ALL_REPORTS"});if(t&&t.success&&t.reports.length>0)a=t.reports,i=a[0];else{const e=await chrome.runtime.sendMessage({type:"INSPECT_CURRENT_TAB"});e&&e.success&&(i=e.report,a=[i])}i&&(y(i),Y(a),N(a))}catch(t){console.error("Failed to load dashboard data:",t)}}function y(t){E.textContent=t.hostname,b.textContent=`調査日時: ${new Date(t.inspectedAt).toLocaleString("ja-JP")}`,T.textContent=String(t.technologies.length),w.textContent=String(t.summary.requiresAttentionCount),C.textContent=t.summary.isHttps?"HTTPS (暗号化)":"HTTP (非暗号化)",L.textContent=`混在コンテンツ: ${t.summary.mixedContentCount}件`,B.textContent=String(t.cookies.length),q(t.technologies),J(t.securityChecks),O(t.technologies),U(t.securityChecks),F(t.cookies)}function q(t){if(t.length===0){v.innerHTML='<div class="empty-state">技術シグナル未検出</div>';return}v.innerHTML=t.slice(0,5).map(e=>`
    <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-color);">
      <div>
        <strong>${s(e.technology)}</strong>
        <span style="color:var(--text-muted);font-size:12px;margin-left:6px;">${e.version?`v${s(e.version)}`:""}</span>
      </div>
      <span class="badge ${e.confidenceLevel==="high"?"badge-high":"badge-medium"}">確信度 ${e.confidence}</span>
    </div>
  `).join("")}function J(t){const e=t.filter(n=>n.status==="warning"||n.status==="fail");if(e.length===0){p.innerHTML='<div style="color:var(--success-color);padding:12px 0;">重大なセキュリティ設定不備は検出されませんでした。</div>';return}p.innerHTML=e.slice(0,5).map(n=>`
    <div style="padding:8px 0;border-bottom:1px solid var(--border-color);">
      <div style="display:flex;justify-content:space-between;">
        <strong>${s(n.name)}</strong>
        <span class="badge ${n.severity==="high"?"sev-high":"sev-medium"}">${n.severity.toUpperCase()}</span>
      </div>
      <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">${s(n.description)}</div>
    </div>
  `).join("")}function O(t){if(t.length===0){u.innerHTML='<div class="empty-state">明確な固有技術シグナルは検出されませんでした</div>';return}u.innerHTML=t.map(e=>`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:15px;">${s(e.technology)}</span>
          ${e.version?`<span class="badge" style="background:var(--bg-hover);">v${s(e.version)}</span>`:'<span style="font-size:11px;color:var(--text-muted);">バージョン不明</span>'}
          <span style="font-size:12px;color:var(--text-muted);">${s(e.category)}</span>
        </div>
        <span class="badge ${e.confidenceLevel==="high"?"badge-high":"badge-medium"}">確信度 ${e.confidence} (${e.confidenceLevel.toUpperCase()})</span>
      </div>
      <div class="accordion-body">
        <div>${s(e.description||"")}</div>
        ${e.website?`<div>公式サイト: <a href="${e.website}" target="_blank" style="color:var(--accent-color);">${e.website}</a></div>`:""}
        <div style="font-weight:700;margin-top:8px;">判定根拠 (Evidence):</div>
        <ul style="padding-left:18px;">
          ${e.evidence.map(n=>`
            <li>
              <strong>[${n.type}] ${s(n.name)}:</strong>
              <code>${s(n.value)}</code>
              ${n.detail?`<span style="color:var(--text-muted);margin-left:6px;">(${s(n.detail)})</span>`:""}
            </li>
          `).join("")}
        </ul>
      </div>
    </div>
  `).join("")}function U(t){S.innerHTML=t.map(e=>`
    <div class="accordion-item">
      <div class="accordion-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-weight:700;font-size:14px;">${s(e.name)}</span>
          <span style="font-size:11px;color:var(--text-muted);">${s(e.checkId)}</span>
        </div>
        <span class="badge ${e.status==="pass"?"sev-pass":e.severity==="high"?"sev-high":"sev-medium"}">${e.status==="pass"?"PASS":e.severity.toUpperCase()}</span>
      </div>
      <div class="accordion-body">
        <div><strong>観測値:</strong> <code>${s(e.observed)}</code></div>
        <div><strong>セキュリティ上の影響:</strong> ${s(e.description)}</div>
        <div style="color:var(--accent-color);"><strong>推奨対応:</strong> ${s(e.recommendation)}</div>
        ${e.referenceUrls.length>0?`
          <div><strong>参考資料:</strong>
            ${e.referenceUrls.map(n=>`<a href="${n}" target="_blank" style="color:var(--accent-color);margin-left:8px;">${n}</a>`).join(", ")}
          </div>
        `:""}
      </div>
    </div>
  `).join("")}function F(t){if(!t||t.length===0){g.innerHTML='<tr><td colspan="8" class="empty-state">Cookieは検出されませんでした</td></tr>';return}g.innerHTML=t.map(e=>`
    <tr>
      <td><strong>${s(e.name)}</strong></td>
      <td>${s(e.domain)}</td>
      <td>${s(e.path)}</td>
      <td>${e.secure?"✅":"❌"}</td>
      <td>${e.httpOnly?"✅":"❌"}</td>
      <td>${s(e.sameSite)}</td>
      <td>${e.session?"セッション":"永続"}</td>
      <td style="color:${e.issues.length>0?"var(--warning-color)":"var(--text-muted)"};">${e.issues.length>0?s(e.issues.join(", ")):"なし"}</td>
    </tr>
  `).join("")}function N(t){if(t.length===0){h.innerHTML='<div class="empty-state">保存された履歴はありません</div>';return}h.innerHTML=t.map(e=>`
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;border:1px solid var(--border-color);border-radius:var(--radius-sm);margin-bottom:8px;background:var(--bg-surface);">
      <div>
        <strong>${s(e.hostname)}</strong>
        <span style="font-size:12px;color:var(--text-muted);margin-left:8px;">${new Date(e.inspectedAt).toLocaleString("ja-JP")}</span>
        <div style="font-size:12px;color:var(--text-sub);margin-top:2px;">
          技術: ${e.technologies.length}件 / 要確認: ${e.summary.requiresAttentionCount}件 / ${e.summary.isHttps?"HTTPS":"HTTP"}
        </div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-secondary btn-sm" onclick="window.viewReport('${e.id}')">表示</button>
        <button class="btn btn-danger btn-sm" onclick="window.deleteReport('${e.id}')">削除</button>
      </div>
    </div>
  `).join("")}window.viewReport=t=>{const e=a.find(n=>n.id===t);e&&(i=e,y(e),document.querySelector('.nav-item[data-view="overviewView"]')?.dispatchEvent(new Event("click")))};window.deleteReport=async t=>{confirm("この調査レポートを削除しますか？")&&(await chrome.runtime.sendMessage({type:"DELETE_HISTORY_ITEM",id:t}),await c())};function Y(t){l.innerHTML="",m.innerHTML="",t.forEach((e,n)=>{const r=document.createElement("option");r.value=e.id,r.textContent=`${e.hostname} (${new Date(e.inspectedAt).toLocaleString("ja-JP")})`,l.appendChild(r);const o=document.createElement("option");o.value=e.id,o.textContent=`${e.hostname} (${new Date(e.inspectedAt).toLocaleString("ja-JP")})`,(n===1||n===0&&t.length===1)&&(o.selected=!0),m.appendChild(o)})}function G(){const t=l.value,e=m.value,n=a.find(d=>d.id===t),r=a.find(d=>d.id===e);if(!n||!r)return;const o=x(n,r);H.innerHTML=`
    <div class="diff-box">
      <div class="diff-title">技術スタックの差分</div>
      <div>新規検出された技術: <span class="diff-added">${o.addedTechnologies.length>0?o.addedTechnologies.join(", "):"なし"}</span></div>
      <div>未検出となった技術: <span class="diff-removed">${o.removedTechnologies.length>0?o.removedTechnologies.join(", "):"なし"}</span></div>
      ${o.versionChanges.length>0?`
        <div style="margin-top:6px;">バージョン変化:</div>
        <ul>
          ${o.versionChanges.map(d=>`<li>${d.technology}: ${d.before||"不明"} &rarr; <strong>${d.after||"不明"}</strong></li>`).join("")}
        </ul>
      `:"<div>バージョン変化: なし</div>"}
    </div>

    <div class="diff-box">
      <div class="diff-title">セキュリティ課題の差分</div>
      <div>新たに検出された課題: <span class="diff-removed">${o.newSecurityIssues.length>0?o.newSecurityIssues.join(", "):"なし"}</span></div>
      <div>解消された課題: <span class="diff-added">${o.resolvedSecurityIssues.length>0?o.resolvedSecurityIssues.join(", "):"なし"}</span></div>
    </div>
  `}function s(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
